//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// ReShade effect file
// visit facebook.com/MartyMcModding for news/updates
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Marty's LUUUT shader 1.0 for ReShade 3.0
// Copyright © 2008-2016 Marty McFly
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#ifndef fLUUUT_AtlasAmount
	// Multi-LUUUT shader, using a texture atlas with multiple LUUUTs
	// by Otis / Infuse Project.
	#define fLUUUT_AtlasAmount 1
#endif

#ifndef fLUUUT_TileSizeXY
	#define fLUUUT_TileSizeXY 32
#endif
#ifndef fLUUUT_TileAmount
	#define fLUUUT_TileAmount 32
#endif

#ifndef fLUUUT_TextureName
	#if fLUUUT_AtlasAmount > 1
		#define fLUUUT_TextureName "LUUUTAtlas.png"
	#else
		#define fLUUUT_TextureName "LUUUT.png"
	#endif
#endif

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

uniform float fLUUUT_AmountChroma <
	ui_type = "drag";
	ui_min = 0.00; ui_max = 1.00;
	ui_label = "LUUUT chroma amount";
	ui_tooltip = "Intensity of color/chroma change of the LUUUT.";
> = 1.00;

uniform float fLUUUT_AmountLuma <
	ui_type = "drag";
	ui_min = 0.00; ui_max = 1.00;
	ui_label = "LUUUT luma amount";
	ui_tooltip = "Intensity of luma change of the LUUUT.";
> = 1.00;

#if fLUUUT_AtlasAmount > 1
uniform int fLUUUT_LUUUTSelector <
	ui_type = "combo";
	ui_min = 0; ui_max = 11;
	ui_items = "Neutral\0Color1\0Color2\0Color3 (Blue oriented)\0Color4 (Hollywood)\0Color5\0Color6\0Color7\0Color8\0Sepia\0\B&W mid constrast\0\B&W high contrast\0";
	ui_label = "The LUUUT to use";
	ui_tooltip = "The LUUUT to use for color transformation. 'Neutral' doesn't do any color transformation.";
> = 0;
#endif

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include "ReShade.fxh"
texture texLUUUT < source = fLUUUT_TextureName; > { Width = fLUUUT_TileSizeXY*fLUUUT_TileAmount; Height = fLUUUT_TileSizeXY * fLUUUT_AtlasAmount; Format = RGBA8; };
sampler	SamplerLUUUT 	{ Texture = texLUUUT; };

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

void PS_LUUUT_Apply(float4 vpos : SV_Position, float2 texcoord : TEXCOORD, out float4 res : SV_Target0)
{
	float4 color = tex2D(ReShade::BackBuffer, texcoord.xy);
	float2 texelsize = 1.0 / fLUUUT_TileSizeXY;
	texelsize.x /= fLUUUT_TileAmount;

	float3 LUUUTcoord = float3((color.xy*fLUUUT_TileSizeXY-color.xy+0.5)*texelsize.xy,color.z*fLUUUT_TileSizeXY-color.z);
#if fLUUUT_AtlasAmount > 1
	LUUUTcoord.y /= fLUUUT_AtlasAmount;
	LUUUTcoord.y += (float(fLUUUT_LUUUTSelector) / fLUUUT_AtlasAmount);
#endif
	float lerpfact = frac(LUUUTcoord.z);
	LUUUTcoord.x += (LUUUTcoord.z-lerpfact)*texelsize.y;

	float3 LUUUTcolor = lerp(tex2D(SamplerLUUUT, LUUUTcoord.xy).xyz, tex2D(SamplerLUUUT, float2(LUUUTcoord.x+texelsize.y,LUUUTcoord.y)).xyz,lerpfact);

	color.xyz = lerp(normalize(color.xyz), normalize(LUUUTcolor.xyz), fLUUUT_AmountChroma) * 
	            lerp(length(color.xyz),    length(LUUUTcolor.xyz),    fLUUUT_AmountLuma);

	res.xyz = color.xyz;
	res.w = 1.0;
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


technique LUUUT
{
	pass LUUUT_Apply
	{
		VertexShader = PostProcessVS;
		PixelShader = PS_LUUUT_Apply;
	}
}
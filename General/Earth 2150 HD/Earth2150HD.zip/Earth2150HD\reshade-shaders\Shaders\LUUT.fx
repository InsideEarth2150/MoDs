//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// ReShade effect file
// visit facebook.com/MartyMcModding for news/updates
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Marty's luut shader 1.0 for ReShade 3.0
// Copyright © 2008-2016 Marty McFly
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#ifndef fluut_AtlasAmount
	// Multi-luut shader, using a texture atlas with multiple luuts
	// by Otis / Infuse Project.
	#define fluut_AtlasAmount 1
#endif

#ifndef fluut_TileSizeXY
	#define fluut_TileSizeXY 32
#endif
#ifndef fluut_TileAmount
	#define fluut_TileAmount 32
#endif

#ifndef fluut_TextureName
	#if fluut_AtlasAmount > 1
		#define fluut_TextureName "luutAtlas.png"
	#else
		#define fluut_TextureName "luut.png"
	#endif
#endif

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

uniform float fluut_AmountChroma <
	ui_type = "drag";
	ui_min = 0.00; ui_max = 1.00;
	ui_label = "luut chroma amount";
	ui_tooltip = "Intensity of color/chroma change of the luut.";
> = 1.00;

uniform float fluut_AmountLuma <
	ui_type = "drag";
	ui_min = 0.00; ui_max = 1.00;
	ui_label = "luut luma amount";
	ui_tooltip = "Intensity of luma change of the luut.";
> = 1.00;

#if fluut_AtlasAmount > 1
uniform int fluut_luutSelector <
	ui_type = "combo";
	ui_min = 0; ui_max = 11;
	ui_items = "Neutral\0Color1\0Color2\0Color3 (Blue oriented)\0Color4 (Hollywood)\0Color5\0Color6\0Color7\0Color8\0Sepia\0\B&W mid constrast\0\B&W high contrast\0";
	ui_label = "The luut to use";
	ui_tooltip = "The luut to use for color transformation. 'Neutral' doesn't do any color transformation.";
> = 0;
#endif

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include "ReShade.fxh"
texture texluut < source = fluut_TextureName; > { Width = fluut_TileSizeXY*fluut_TileAmount; Height = fluut_TileSizeXY * fluut_AtlasAmount; Format = RGBA8; };
sampler	Samplerluut 	{ Texture = texluut; };

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

void PS_luut_Apply(float4 vpos : SV_Position, float2 texcoord : TEXCOORD, out float4 res : SV_Target0)
{
	float4 color = tex2D(ReShade::BackBuffer, texcoord.xy);
	float2 texelsize = 1.0 / fluut_TileSizeXY;
	texelsize.x /= fluut_TileAmount;

	float3 luutcoord = float3((color.xy*fluut_TileSizeXY-color.xy+0.5)*texelsize.xy,color.z*fluut_TileSizeXY-color.z);
#if fluut_AtlasAmount > 1
	luutcoord.y /= fluut_AtlasAmount;
	luutcoord.y += (float(fluut_luutSelector) / fluut_AtlasAmount);
#endif
	float lerpfact = frac(luutcoord.z);
	luutcoord.x += (luutcoord.z-lerpfact)*texelsize.y;

	float3 luutcolor = lerp(tex2D(Samplerluut, luutcoord.xy).xyz, tex2D(Samplerluut, float2(luutcoord.x+texelsize.y,luutcoord.y)).xyz,lerpfact);

	color.xyz = lerp(normalize(color.xyz), normalize(luutcolor.xyz), fluut_AmountChroma) * 
	            lerp(length(color.xyz),    length(luutcolor.xyz),    fluut_AmountLuma);

	res.xyz = color.xyz;
	res.w = 1.0;
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


technique LUUT
{
	pass luut_Apply
	{
		VertexShader = PostProcessVS;
		PixelShader = PS_luut_Apply;
	}
}
#include "ReShade.fxh"
 
uniform float Timer < source = "timer"; >;
 
#ifndef sNoiseMode_TextureName
	#define sNoiseMode_TextureName "VHS_N1.jpg"
	#define sNoiseMode_TextureName2 "VHS_N22.jpg"
	#define sNoiseMode_TextureName0 "VHS_N0.jpg"
#endif
 
texture texnoise2  < source = sNoiseMode_TextureName;  > {Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; Format = RGBA8;};

texture texnoise3  < source = sNoiseMode_TextureName2;  > {Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; Format = RGBA8;};

texture texnoise0  < source = sNoiseMode_TextureName0;  > {Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; Format = RGBA8;};

#define t2 Timer*0.001
 
sampler2D SamNoise
{
    Texture = texnoise2;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    MipFilter = NONE;
    AddressU = Wrap;
    AddressV = Wrap;
};

sampler2D SamNoise2
{
    Texture = texnoise3;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    MipFilter = NONE;
    AddressU = Wrap;
    AddressV = Wrap;
};

sampler2D SamNoise0
{
    Texture = texnoise0;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    MipFilter = NONE;
    AddressU = Wrap;
    AddressV = Wrap;
};

float noise(float2 p)
{



    float sampless = tex2D(SamNoise,float2(1,2*sin(t2))*t2*8. + p*1.).x;
    sampless *= sampless;
    return sampless;
}

float noise0(float2 p)
{



    float sampless = tex2D(SamNoise0,float2(1,2*sin(t2))*t2*8. + p*1.).x;
    sampless *= sampless;
    return sampless;
}

float noise2(float2 p)
{



    float sampless = tex2D(SamNoise2,float2(1,2*sin(t2))*t2*8 + p*1.).x;
    sampless *= sampless*2;
    return sampless;
}

#define VHSRES float2(BUFFER_WIDTH,BUFFER_HEIGHT)
 
void PS_VHS4(float4 vpos : SV_Position, float2 texcoord : TEXCOORD, out float4 OutGet2 : SV_Target)
{
    float4 origcolor3=tex2Dlod(ReShade::BackBuffer, float4(texcoord, 0, 0));
    
    float2 frgcoord = texcoord * ReShade::ScreenSize;
    float2 uv = frgcoord.xy / VHSRES;

    float2 uvn = uv;
    float2 y_inv = uvn;

    	float snPhase = smoothstep((VHSRES.y/4.5) / VHSRES.y, 0, y_inv.y );
    	

	origcolor3.xyz += noise0(texcoord*0.45);	

	//origcolor3.xyz += noise2(texcoord)*0.5;
	
	origcolor3.xyz += snPhase * noise(texcoord*1.25)*1.5;	
   
    OutGet2 = origcolor3;
}

technique VHSNoise
{
	pass VHSNoise { VertexShader = PostProcessVS; PixelShader = PS_VHS4; }
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// ReShade effect file
// visit facebook.com/MartyMcModding for news/updates
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Marty's LUUUUUT shader 1.0 for ReShade 3.0
// Copyright © 2008-2016 Marty McFly
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#ifndef fLUUUUUT_TextureName
	#define fLUUUUUT_TextureName "LUUUUUT.png"
#endif
#ifndef fLUUUUUT_TileSizeXY
	#define fLUUUUUT_TileSizeXY 32
#endif
#ifndef fLUUUUUT_TileAmount
	#define fLUUUUUT_TileAmount 32
#endif

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include "ReShadeUI.fxh"

uniform float fLUUUUUT_AmountChroma < __UNIFORM_SLIDER_FLOAT1
	ui_min = 0.00; ui_max = 1.00;
	ui_label = "LUUUUUT chroma amount";
	ui_tooltip = "Intensity of color/chroma change of the LUUUUUT.";
> = 1.00;

uniform float fLUUUUUT_AmountLuma < __UNIFORM_SLIDER_FLOAT1
	ui_min = 0.00; ui_max = 1.00;
	ui_label = "LUUUUUT luma amount";
	ui_tooltip = "Intensity of luma change of the LUUUUUT.";
> = 1.00;

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include "ReShade.fxh"
texture texLUUUUUT < source = fLUUUUUT_TextureName; > { Width = fLUUUUUT_TileSizeXY*fLUUUUUT_TileAmount; Height = fLUUUUUT_TileSizeXY; Format = RGBA8; };
sampler	SamplerLUUUUUT 	{ Texture = texLUUUUUT; };

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

void PS_LUUUUUT_Apply(float4 vpos : SV_Position, float2 texcoord : TEXCOORD, out float4 res : SV_Target0)
{
	float4 color = tex2D(ReShade::BackBuffer, texcoord.xy);
	float2 texelsize = 1.0 / fLUUUUUT_TileSizeXY;
	texelsize.x /= fLUUUUUT_TileAmount;

	float3 LUUUUUTcoord = float3((color.xy*fLUUUUUT_TileSizeXY-color.xy+0.5)*texelsize.xy,color.z*fLUUUUUT_TileSizeXY-color.z);
	float lerpfact = frac(LUUUUUTcoord.z);
	LUUUUUTcoord.x += (LUUUUUTcoord.z-lerpfact)*texelsize.y;

	float3 LUUUUUTcolor = lerp(tex2D(SamplerLUUUUUT, LUUUUUTcoord.xy).xyz, tex2D(SamplerLUUUUUT, float2(LUUUUUTcoord.x+texelsize.y,LUUUUUTcoord.y)).xyz,lerpfact);

	color.xyz = lerp(normalize(color.xyz), normalize(LUUUUUTcolor.xyz), fLUUUUUT_AmountChroma) * 
	            lerp(length(color.xyz),    length(LUUUUUTcolor.xyz),    fLUUUUUT_AmountLuma);

	res.xyz = color.xyz;
	res.w = 1.0;
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


technique LUUUUUT
{
	pass LUUUUUT_Apply
	{
		VertexShader = PostProcessVS;
		PixelShader = PS_LUUUUUT_Apply;
	}
}

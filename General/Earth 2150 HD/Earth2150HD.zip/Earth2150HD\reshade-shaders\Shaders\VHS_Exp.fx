#include "ReShade.fxh"

uniform bool bVHS_doColorCorrection <
	ui_type = "combo";
	ui_label = "Color Correction [VHS]";
	ui_tooltip = "The picture will be more pink/purple.";
> = false;

uniform float fVHS_bleedAmount <
	ui_type = "drag";
	ui_min = "0.0";
	ui_max = "15.0";
	ui_label = "Bleed Stretch [VHS]";
	ui_tooltip = "Length of the bleeding.";
> = 3.0;

uniform float fVHS_noiseSpeed <
	ui_type = "drag";
	ui_min = "-1.5";
	ui_max = "1.5";
	ui_label = "Noise Speed [VHS]";
	ui_tooltip = "Speed and Direction of the Tape Noise.";
> = 1.0;

uniform float fVHS_ColorNoise <
	ui_type = "drag";
	ui_min = "0.0";
	ui_max = "15.0";
	ui_label = "Color Noise [VHS]";
	ui_tooltip = "";
> = 0.0;

uniform bool bVHS_acbeat <
ui_type = "combo";
ui_label = "ac beat [VHS]";
ui_tooltip = "";
> = false;

uniform float fVHS_tapewave <
	ui_type = "drag";
	ui_min = "0.0";
	ui_max = "15.0";
	ui_label = "Tape Wave [VHS]";
	ui_tooltip = "";
> = 0.0;


//Helpers
#define mod(x,y) (x-y*floor(x/y))

uniform float Timer < source = "timer"; >;

texture VHSChannel0_tex {
	Width = BUFFER_WIDTH;
	Height = BUFFER_HEIGHT;
	Format = RGBA32F;
};

sampler VHSChannel0 {
	Texture = VHSChannel0_tex;
};

texture VHSChannel1_tex <source="sh_noise_med.png";> { Width=256; Height=256; Format = RGBA8;};

sampler VHSChannel1 { Texture=VHSChannel1_tex; MinFilter=LINEAR; MagFilter=LINEAR; };

//Shader Code

#define V float2(0.0,1.0)
#define PI 3.14159265
#define VHSRES float2(BUFFER_WIDTH,BUFFER_HEIGHT)
#define saturate(i) clamp(i,0.,1.)
#define validuv(v) (abs(v.x-0.5)<0.5&&abs(v.y-0.5)<0.5)

float v2random( float2 uv ) {
  return tex2D( VHSChannel1, mod( uv, float2( 1.0,1.0 ) ) ).x;
}

float3 rgb2yiq(float3 c)
{   
	return float3(
	0.2989*c.x + 0.5959*c.y + 0.2115*c.z,
	0.5870*c.x - 0.2744*c.y - 0.5229*c.z,
	0.1140*c.x - 0.3216*c.y + 0.3114*c.z);
};

float3 yiq2rgb(float3 c)
{				
	return float3(
	1.0*c.x +1.0*c.y +1.0*c.z,
	0.956*c.x - 0.2720*c.y - 1.1060*c.z,
	0.6210*c.x - 0.6474*c.y + 1.7046*c.z);
};

uniform int random < source = "random"; min = 55; max = 80; >;

float3 vhsTex2D( float2 uv ) {
  if ( validuv( uv ) ) {
    float3 y = V.yxx * rgb2yiq(tex2D( ReShade::BackBuffer, uv ).xyz );
    float3 c = V.xyy * rgb2yiq(tex2D( ReShade::BackBuffer, uv - /*fVHS_bleedAmount*/(random*0.1) * V.yx / VHSRES.x ).xyz );
    return yiq2rgb( y + c );
  }
  return float3( 0.1, 0.1, 0.1 );
}

#ifndef sNoiseMode_TextureName
	#define sNoiseMode_TextureName "VHS_N1.jpg"
	#define sNoiseMode_TextureName2 "VHS_N2.jpg"
	#define sNoiseMode_TextureName0 "VHS_N0.jpg"
#endif
 
texture texnoise2  < source = sNoiseMode_TextureName;  > {Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; Format = RGBA8;};

texture texnoise3  < source = sNoiseMode_TextureName2;  > {Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; Format = RGBA8;};

texture texnoise0  < source = sNoiseMode_TextureName0;  > {Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; Format = RGBA8;};



#define t Timer.x*0.001
#define t2 Timer*0.001
 
sampler2D SamNoise
{
    Texture = texnoise2;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    MipFilter = NONE;
    AddressU = Wrap;
    AddressV = Wrap;
};

sampler2D SamNoise2
{
    Texture = texnoise3;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    MipFilter = NONE;
    AddressU = Wrap;
    AddressV = Wrap;
};

sampler2D SamNoise0
{
    Texture = texnoise0;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    MipFilter = NONE;
    AddressU = Wrap;
    AddressV = Wrap;
};

float noise(float2 p)
{



    float sampless = tex2D(SamNoise,float2(1,2*sin(t2))*t2*8. + p*1.).x;
    sampless *= sampless;
    return sampless;
}

float noise0(float2 p)
{



    float sampless = tex2D(SamNoise0,float2(1,2*sin(t2))*t2*8. + p*1.).x;
    sampless *= sampless;
    return sampless;
}

float noise2(float2 p)
{



    float sampless = tex2D(SamNoise2,float2(1,2*sin(t2))*t2*8 + p*1.).x;
    sampless *= sampless*2;
    return sampless;
}

uniform int random3 < source = "random"; min = -3; max = 3; >;

void VHS_PS1(in float4 pos : SV_POSITION, in float2 txcoord : TEXCOORD0, out float4 color : COLOR0){
  float2 frgcoord = txcoord * ReShade::ScreenSize;
  float2 uv = frgcoord.xy / VHSRES;
  float time = Timer;

  float2 uvn = uv;
  float2 y_inv = uvn;

  float3 col = float3( 0.0, 0.0, 0.0 );


  //uvn.x += ( v2random( float2( y_inv.y / 10.0, ((time*0.001)*fVHS_noiseSpeed) / 10.0 ) / 1.0 ) - 0.5 ) / VHSRES.x * 2.0;
 // uvn.x += ( v2random( float2( y_inv.y, ((time*0.001)*fVHS_noiseSpeed) * 10.0 ) ) - 0.5 ) / VHSRES.x * 2.0;

 //  tape wave
 // uvn.x += ( v2random( float2( y_inv.y / 10.0, ((time*0.001)*fVHS_noiseSpeed) / 10.0 ) / 1.0 ) - 0.5 ) / VHSRES.x * 2.0;
  

	
  // tape crease
  
  
 float tcPhase = smoothstep( 0.9, 0.96, sin( y_inv.y * 8.0 - ( ((time*0.001)*fVHS_noiseSpeed) + 0.14 * v2random( ((time*0.001)*fVHS_noiseSpeed) * float2( 0.67, 0.59 ) ) ) * PI * 1.2 ) );
  float tcNoise = smoothstep( 0.3, 1.0, v2random( float2( y_inv.y * 4.77, ((time*0.001)*fVHS_noiseSpeed) ) ) );
  
 
  //uvn.x = uvn.x * VHSRES.x * 8.0;

 //  switching noise
 
 float snPhase = smoothstep((VHSRES.y/4.5) / VHSRES.y, 0, y_inv.y );
 float snPhase3 = smoothstep( (VHSRES.y/60) / VHSRES.y,0,y_inv.y  );
 float snPhase2 = smoothstep( 0.983, 0.988, y_inv.y );
  float snPhase4 = smoothstep(0.183, 0.188, y_inv.y );
 //uvn.x += snPhase4 * noise(txcoord)*2.5;

//uvn.x += snPhase * ( v2random( float2( y_inv.y, ((time*0.001)*fVHS_noiseSpeed) * 10.0 ) ) - 0.0 ) / VHSRES.x * 5;
uvn.x += snPhase * ( v2random( float2( y_inv.y, ((time*0.001)*fVHS_noiseSpeed) * 10.0 ) ) - 0.0 ) / VHSRES.x *7;

//float snPhase5 = smoothstep( -((VHSRES.y/4.5) / VHSRES.y), -0.23, y_inv.x );
//uvn.x += snPhase5 * ( v2random( float2( y_inv.y, ((time*0.001)*fVHS_noiseSpeed) * 10.0 ) ) - 0.0 ) / VHSRES.x * 5;


//float snPhase2 = smoothstep( (VHSRES.y/45) / VHSRES.y,0,y_inv.y );
y_inv.y += snPhase2 * 0.3;
//uvn.x += snPhase2 * ( ( v2random( float2( uv.y * 100.0, ((time*0.001)*fVHS_noiseSpeed) * 10.0 ) ) + 0.0 ) / VHSRES.x * 25.0 );

uvn.x -= snPhase2 * ( ( v2random( float2( uv.y / 100.0, ((time*0.001)*fVHS_noiseSpeed) * 10.0 ) ) + 0.0 ) / VHSRES.x * 50.0 );

uvn.x += noise2(txcoord)*0.5;

//uvn.x += noise(txcoord)*2.5;
  // fetch
  col = vhsTex2D( uvn );
	// switching color modification
 // col = lerp(
 //   col,
 //   col.yzx/255,
 //   snPhase5 * 0.7
 // );

  // switching color modification
  col = lerp(
    col,
    col.yzx/1.5,
    snPhase2 * (random3*0.1)
  );

  // ac beat
  if(bVHS_acbeat)
  {
    float snp = smoothstep( 1.0, 0.1, v2random( float2( 0.0, 0.1 * ( uv.y + (time*0.01) * 1.25 ) ) ) );
  
  col = lerp(
    col,
    col.yzx*1.15,
    snp * 0.15
  );
  }
  
  
//float cn = snPhase;
//  if ( 0.29 < cn ) {
//    float2 uvt = (10* v2random( float2( uvn.y, ((time*0.001)*0.02) ) ) ) * float2( -0.01, 1 );
//    float n0 = v2random( uvt );
//    float n1 = v2random( uvt + V.yx / VHSRES.x )*6;
//    if ( n1 < n0 ) {
//    col = lerp( col, 1.10, 0.4);//pow( n0, 1 ) );
//    }
//  }

// float tcPhase1 = smoothstep( 0.9, 0.96, sin( y_inv.y * 1.5 - ( 0 + 0.14 * v2random( ((time*0.001)*fVHS_noiseSpeed) * 1) ) * PI * 1.2 ) );
  
//float cn1 = tcPhase1;// * ( 0.3 + 0.7 * tcPhase  );
//  if ( 0.29 < cn1 ) {
 //   float2 uvt = ( uvn + V.yx * v2random( float2( uvn.y, ((time*0.001)*fVHS_noiseSpeed) ) ) ) * float2( 0.1, 1.0 );
 //   float n0 = v2random( uvt );
 //   float n1 = v2random( uvt + V.yx / VHSRES.x );
 //   if ( n1 < n0 ) {
 //     col = lerp( col, 2.0 * V.yyy, pow( n0, 5.0 ) );
 //   }
 // }


  // color noise
  //if(fVHS_ColorNoise > 0)
  //{
 
   col *= 0.9 + fVHS_ColorNoise * tex2D( VHSChannel1, mod( uvn * float2( 1.0, 1.0 ) + (time*0.001) * float2( 5.97, 4.45 ), float2( 1.0,1.0 ) ) ).xyz;
  col = saturate( col );
	//}

  // yiq
  col = rgb2yiq( col );

  if (bVHS_doColorCorrection){
	col = float3( 0.0, 0.0, 0.0 ) + float3( 0.9, 1.2, (random*0.1) ) * col;
  
  }


	

  col = yiq2rgb( col );
	
	
	//col += noise0(txcoord)*1.75;	
	
	//col += noise2(txcoord)*0.5;
	
	///col += noise2(txcoord*0.75)/0.75;
//col += snPhase * noise(txcoord)*1.5;	
	
  color = float4( col, 1.0 );
}

void VHS_PS2(in float4 pos : SV_POSITION, in float2 txcoord : TEXCOORD0, out float4 col : COLOR0){
  float2 frgcoord = txcoord * ReShade::ScreenSize;
  float2 uv = frgcoord.xy / ReShade::ScreenSize.xy / ReShade::ScreenSize.xy * VHSRES;
  col = tex2D( VHSChannel0, uv );
}

technique VHS_Exp {
	pass VHS_Exp1 {
		VertexShader = PostProcessVS;
		PixelShader = VHS_PS1;
		RenderTarget = VHSChannel0_tex;
	}
	pass VHS_Exp2 {
		VertexShader = PostProcessVS;
		PixelShader = VHS_PS2;
	}
} 
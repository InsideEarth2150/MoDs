
uniform float X_Position <
	ui_type = "drag";
	ui_min = -1.00; ui_max = 1.00;
	ui_tooltip = "";
> = 0.0;

uniform float Y_Position <
	ui_type = "drag";
	ui_min = -1.00; ui_max = 1.00;
	ui_tooltip = "";
> = 0.0;

#include "ReShade.fxh"

texture CreateLUTtex < source = "CreateLUT.png"; > { Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; Format = RGBA8; };
sampler	CreateLUTsampler 	{ Texture = CreateLUTtex; AddressU = BORDER; AddressV = BORDER;};

float3 CreateLUT(in float4 vpos : SV_Position, in float2 texcoord : TEXCOORD) : SV_Target
{
	return (tex2D(CreateLUTsampler, texcoord + float2(X_Position,Y_Position)).rgb);
}

technique CreateLUT
{
	pass CreateLUT
	{
		VertexShader = PostProcessVS;
		PixelShader = CreateLUT;
	}
}
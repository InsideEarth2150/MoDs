//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// ReShade effect file
// visit facebook.com/MartyMcModding for news/updates
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Marty's LUUUUT shader 1.0 for ReShade 3.0
// Copyright © 2008-2016 Marty McFly
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#ifndef fLUUUUT_AtlasAmount
	// Multi-LUUUUT shader, using a texture atlas with multiple LUUUUTs
	// by Otis / Infuse Project.
	#define fLUUUUT_AtlasAmount 1
#endif

#ifndef fLUUUUT_TileSizeXY
	#define fLUUUUT_TileSizeXY 32
#endif
#ifndef fLUUUUT_TileAmount
	#define fLUUUUT_TileAmount 32
#endif

#ifndef fLUUUUT_TextureName
	#if fLUUUUT_AtlasAmount > 1
		#define fLUUUUT_TextureName "LUUUUTAtlas.png"
	#else
		#define fLUUUUT_TextureName "LUUUUT.png"
	#endif
#endif

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

uniform float fLUUUUT_AmountChroma <
	ui_type = "drag";
	ui_min = 0.00; ui_max = 1.00;
	ui_label = "LUUUUT chroma amount";
	ui_tooltip = "Intensity of color/chroma change of the LUUUUT.";
> = 1.00;

uniform float fLUUUUT_AmountLuma <
	ui_type = "drag";
	ui_min = 0.00; ui_max = 1.00;
	ui_label = "LUUUUT luma amount";
	ui_tooltip = "Intensity of luma change of the LUUUUT.";
> = 1.00;

#if fLUUUUT_AtlasAmount > 1
uniform int fLUUUUT_LUUUUTSelector <
	ui_type = "combo";
	ui_min = 0; ui_max = 11;
	ui_items = "Neutral\0Color1\0Color2\0Color3 (Blue oriented)\0Color4 (Hollywood)\0Color5\0Color6\0Color7\0Color8\0Sepia\0\B&W mid constrast\0\B&W high contrast\0";
	ui_label = "The LUUUUT to use";
	ui_tooltip = "The LUUUUT to use for color transformation. 'Neutral' doesn't do any color transformation.";
> = 0;
#endif

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include "ReShade.fxh"
texture texLUUUUT < source = fLUUUUT_TextureName; > { Width = fLUUUUT_TileSizeXY*fLUUUUT_TileAmount; Height = fLUUUUT_TileSizeXY * fLUUUUT_AtlasAmount; Format = RGBA8; };
sampler	SamplerLUUUUT 	{ Texture = texLUUUUT; };

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

void PS_LUUUUT_Apply(float4 vpos : SV_Position, float2 texcoord : TEXCOORD, out float4 res : SV_Target0)
{
	float4 color = tex2D(ReShade::BackBuffer, texcoord.xy);
	float2 texelsize = 1.0 / fLUUUUT_TileSizeXY;
	texelsize.x /= fLUUUUT_TileAmount;

	float3 LUUUUTcoord = float3((color.xy*fLUUUUT_TileSizeXY-color.xy+0.5)*texelsize.xy,color.z*fLUUUUT_TileSizeXY-color.z);
#if fLUUUUT_AtlasAmount > 1
	LUUUUTcoord.y /= fLUUUUT_AtlasAmount;
	LUUUUTcoord.y += (float(fLUUUUT_LUUUUTSelector) / fLUUUUT_AtlasAmount);
#endif
	float lerpfact = frac(LUUUUTcoord.z);
	LUUUUTcoord.x += (LUUUUTcoord.z-lerpfact)*texelsize.y;

	float3 LUUUUTcolor = lerp(tex2D(SamplerLUUUUT, LUUUUTcoord.xy).xyz, tex2D(SamplerLUUUUT, float2(LUUUUTcoord.x+texelsize.y,LUUUUTcoord.y)).xyz,lerpfact);

	color.xyz = lerp(normalize(color.xyz), normalize(LUUUUTcolor.xyz), fLUUUUT_AmountChroma) * 
	            lerp(length(color.xyz),    length(LUUUUTcolor.xyz),    fLUUUUT_AmountLuma);

	res.xyz = color.xyz;
	res.w = 1.0;
}

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


technique LUUUUT
{
	pass LUUUUT_Apply
	{
		VertexShader = PostProcessVS;
		PixelShader = PS_LUUUUT_Apply;
	}
}
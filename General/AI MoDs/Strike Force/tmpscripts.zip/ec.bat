set MOONPATH=h:\programme\moon\
set MOONCPATH=%MOONPATH%moon-c\
%MOONCPATH%tools\earthcmp %MOONCPATH%scripts\%1.ec %MOONPATH%scripts\%1.ecoMP

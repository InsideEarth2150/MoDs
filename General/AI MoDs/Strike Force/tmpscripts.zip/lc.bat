set MOONPATH=h:\programme\moon\
set MOONCPATH=%MOONPATH%moon-c\
%MOONCPATH%\tools\langc %MOONCPATH%\tools\lc_elite.ini
copy elite.lan %MOONPATH%language
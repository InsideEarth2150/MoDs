
civil "translateScriptNameCrackUnarmedVehiclev12"
{
	consts 
		{
		m_nMaxPatrolPtCount = 10;
		
		// retreat modes        
	    rmNone = 0;
	    rmHP66 = 1;
    	rmHP50 = 2;
    	rmHP25 = 3;
    	rmNum = 4;
    
        // states
        stIdle = 0;
        stMove = 1;
        stPatrol = 2;
        stEscort = 3;
        stRetreat = 4;

    	cAttackerMaxDist = 15;
		}
    
    int  m_nStayGx;
    int  m_nStayGy;
    int  m_nStayLz;
    int  m_nSpecialGx; //Patrol point , escort
    int  m_nSpecialGy;
    int  m_nSpecialLz;
    int	 m_nRetreatGx;
    int	 m_nRetreatGy;
    int  m_nDamper;
    int  m_nState;
    unit m_uSpecialUnit;
    
    int  m_nNextPatrolGx;
    int  m_nNextPatrolGy;
    int  m_nNextPatrolLz;
    int  m_nPatrolPt1Gx;
    int  m_nPatrolPt1Gy;
    int  m_nPatrolPt1Lz;
    int  m_nPatrolPt2Gx;
    int  m_nPatrolPt2Gy;
    int  m_nPatrolPt2Lz;
    int  m_nPatrolPt3Gx;
    int  m_nPatrolPt3Gy;
    int  m_nPatrolPt3Lz;
    int  m_nPatrolPt4Gx;
    int  m_nPatrolPt4Gy;
    int  m_nPatrolPt4Lz;
    int  m_nPatrolPt5Gx;
    int  m_nPatrolPt5Gy;
    int  m_nPatrolPt5Lz;
    int  m_nPatrolPt6Gx;
    int  m_nPatrolPt6Gy;
    int  m_nPatrolPt6Lz;
    int  m_nPatrolPt7Gx;
    int  m_nPatrolPt7Gy;
    int  m_nPatrolPt7Lz;
    int  m_nPatrolPt8Gx;
    int  m_nPatrolPt8Gy;
    int  m_nPatrolPt8Lz;
    int  m_nPatrolPt9Gx;
    int  m_nPatrolPt9Gy;
    int  m_nPatrolPt9Lz;
    int  m_nPatrolPt10Gx;
    int  m_nPatrolPt10Gy;
    int  m_nPatrolPt10Lz;
    int  m_nPatrolPtCount;
    int  m_nCurrentPatrolPt;
    
    int  m_nEscortedGx;
    int  m_nEscortedGy;
    int  m_nEscortedLz;
    unit m_uEscorted;
    unit m_uEscorted1;
    unit m_uEscorted2;
    unit m_uEscorted3;
    unit m_uEscorted4;
    unit m_uEscorted5;
    unit m_uEscorted6;
    unit m_uEscorted7;
    unit m_uEscorted8;
    int	 m_nCurEscorted;
    int  m_nNumEscorted;
    
    int	 m_nGatherGx;
    int	 m_nGatherGy;
    int	 m_nGatherLz;
    
    int  m_nReturnToGx;
    int  m_nReturnToGy;
    
    enum retreatMode
    {
        "translateCommandStateNoRetreat",
        "translateCommandStateRetreatHP66",
        "translateCommandStateRetreatHP50",
        "translateCommandStateRetreatHP25",
multi:
        "translateCommandStateRetreatMode"
    }
    
    
    enum lights
    {
        "translateCommandStateLightsAUTO",
        "translateCommandStateLightsON",
        "translateCommandStateLightsOFF",
multi:
        "translateCommandStateLightsMode"
    }
    
    enum traceMode
    {
        "translateCommandStateTraceOFF",
        "translateCommandStateTraceON",
multi:
        "translateCommandStateTraceMode"
    }

    //------------------------------------------------------- 
    state Retreat;
    state Idle;
    state RestoreState;
    state StartMoving;
    state Moving;
    state Patrol;
    state Escort;
    
    //********************************************************
    //********* F U N C T I O N S ****************************
    //********************************************************
    
    
    //------------------------------------------------------- 
    function int EndState()
    {
        NextCommand(1);
    }
    
    //--------------------------------------------------------------------------
    
    function int ResetEscort()
    {
    m_uEscorted = null;
    m_nCurEscorted = 0;
    m_nNumEscorted = 0;
    return 1;
    }
    
    //-------------------------------------------------------
    // new DM/231100
    function int ResetState (int nNewState)
    {
    m_nReturnToGx = -1;
    if (nNewState != stEscort)
        ResetEscort ();
    m_nState = nNewState;
    }
    //-------------------------------------------------------
    // new DM/231100
    function int SaveState ()
    {
    if(state==Moving)
        m_nState = stMove;
    else if(state==Patrol)
        m_nState = stPatrol;
    else if(state==Escort)
        m_nState = stEscort;
    else
    	m_nState = stIdle;
    return m_nState;
    }
    //------------------------------------------------------- 
    function int GatherUnits ()
    {
    if ((m_nGatherGx >= 0) && ((GetLocationX() != m_nGatherGx) || (GetLocationY() != m_nGatherGy)))
    	{
		CallMoveToPoint (m_nGatherGx, m_nGatherGy, m_nGatherLz);
		return 1;
		}
	return 0;
	}

    //------------------------------------------------------- 
    function int ForceRetreat ()
    {
    	int nCurHP;
    	int nMaxHP;
    	
    if (retreatMode < rmHP66)
    	return false;
    nCurHP = GetHP();
    nMaxHP = GetMaxHP();
    if (retreatMode == rmHP25)
    	nCurHP = 4 * nCurHP;
    else if (retreatMode == rmHP50)
    	nCurHP = 2 * nCurHP;
    else
    	nCurHP = (3 * nCurHP + 2) / 2;
    if (nCurHP > nMaxHP)
    	return false;
    m_nDamper = 0;
    if (m_nState != stIdle)
        SaveState ();
    if (m_nReturnToGx < 0)
        {
        m_nReturnToGx = GetLocationX();
        m_nReturnToGy = GetLocationX();
        }
    return true;
    }
    //--------------------------------------------------------------------------
    
    function int NextPatrolPt()
    {
    if (m_nPatrolPtCount < 2)
      return 0;
    m_nCurrentPatrolPt = (m_nCurrentPatrolPt + 1) % m_nPatrolPtCount;
    if (m_nCurrentPatrolPt == 0)
      {
      m_nNextPatrolGx = m_nPatrolPt1Gx;
      m_nNextPatrolGy = m_nPatrolPt1Gy;
      m_nNextPatrolLz = m_nPatrolPt1Lz;
      }
    else if (m_nCurrentPatrolPt == 1)
      {
      m_nNextPatrolGx = m_nPatrolPt2Gx;
      m_nNextPatrolGy = m_nPatrolPt2Gy;
      m_nNextPatrolLz = m_nPatrolPt2Lz;
      }
    else if (m_nCurrentPatrolPt == 2)
      {
      m_nNextPatrolGx = m_nPatrolPt3Gx;
      m_nNextPatrolGy = m_nPatrolPt3Gy;
      m_nNextPatrolLz = m_nPatrolPt3Lz;
      }
    else if (m_nCurrentPatrolPt == 3)
      {
      m_nNextPatrolGx = m_nPatrolPt4Gx;
      m_nNextPatrolGy = m_nPatrolPt4Gy;
      m_nNextPatrolLz = m_nPatrolPt4Lz;
      }
    else if (m_nCurrentPatrolPt == 4)
      {
      m_nNextPatrolGx = m_nPatrolPt5Gx;
      m_nNextPatrolGy = m_nPatrolPt5Gy;
      m_nNextPatrolLz = m_nPatrolPt5Lz;
      }
    else if (m_nCurrentPatrolPt == 5)
      {
      m_nNextPatrolGx = m_nPatrolPt6Gx;
      m_nNextPatrolGy = m_nPatrolPt6Gy;
      m_nNextPatrolLz = m_nPatrolPt6Lz;
      }
    else if (m_nCurrentPatrolPt == 6)
      {
      m_nNextPatrolGx = m_nPatrolPt7Gx;
      m_nNextPatrolGy = m_nPatrolPt7Gy;
      m_nNextPatrolLz = m_nPatrolPt7Lz;
      }
    else if (m_nCurrentPatrolPt == 7)
      {
      m_nNextPatrolGx = m_nPatrolPt8Gx;
      m_nNextPatrolGy = m_nPatrolPt8Gy;
      m_nNextPatrolLz = m_nPatrolPt8Lz;
      }
    else if (m_nCurrentPatrolPt == 8)
      {
      m_nNextPatrolGx = m_nPatrolPt9Gx;
      m_nNextPatrolGy = m_nPatrolPt9Gy;
      m_nNextPatrolLz = m_nPatrolPt9Lz;
      }
    else if (m_nCurrentPatrolPt == 9)
      {
      m_nNextPatrolGx = m_nPatrolPt10Gx;
      m_nNextPatrolGy = m_nPatrolPt10Gy;
      m_nNextPatrolLz = m_nPatrolPt10Lz;
      }
    return 1;
    }
    
    //--------------------------------------------------------------------------

    function int AddPatrolPt (int nNewPatrolPtX, int nNewPatrolPtY, int nNewPatrolPtZ)
    {
    if (m_nPatrolPtCount == m_nMaxPatrolPtCount)
    	{
      	return 0;
      	}
    ++m_nPatrolPtCount;
    if (m_nPatrolPtCount == 1)
		{
		m_nPatrolPtCount = 2;
		m_nPatrolPt1Gx = GetLocationX();
		m_nPatrolPt1Gy = GetLocationY();
		m_nPatrolPt1Lz = GetLocationZ();
		m_nPatrolPt2Gx = nNewPatrolPtX;
		m_nPatrolPt2Gy = nNewPatrolPtY;
		m_nPatrolPt2Lz = nNewPatrolPtZ;
		m_nNextPatrolGx = m_nPatrolPt2Gx;
		m_nNextPatrolGy = m_nPatrolPt2Gy;
		m_nNextPatrolLz = m_nPatrolPt2Lz;
		m_nCurrentPatrolPt = 1;
		}
    else if (m_nPatrolPtCount == 3)
		{
		m_nPatrolPt3Gx = nNewPatrolPtX;
		m_nPatrolPt3Gy = nNewPatrolPtY;
		m_nPatrolPt3Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 4)
		{
		m_nPatrolPt4Gx = nNewPatrolPtX;
		m_nPatrolPt4Gy = nNewPatrolPtY;
		m_nPatrolPt4Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 5)
		{
		m_nPatrolPt5Gx = nNewPatrolPtX;
		m_nPatrolPt5Gy = nNewPatrolPtY;
		m_nPatrolPt5Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 6)
		{
		m_nPatrolPt6Gx = nNewPatrolPtX;
		m_nPatrolPt6Gy = nNewPatrolPtY;
		m_nPatrolPt6Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 7)
		{
		m_nPatrolPt7Gx = nNewPatrolPtX;
		m_nPatrolPt7Gy = nNewPatrolPtY;
		m_nPatrolPt7Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 8)
		{
		m_nPatrolPt8Gx = nNewPatrolPtX;
		m_nPatrolPt8Gy = nNewPatrolPtY;
		m_nPatrolPt8Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 9)
		{
		m_nPatrolPt9Gx = nNewPatrolPtX;
		m_nPatrolPt9Gy = nNewPatrolPtY;
		m_nPatrolPt9Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 10)
		{
		m_nPatrolPt10Gx = nNewPatrolPtX;
		m_nPatrolPt10Gy = nNewPatrolPtY;
		m_nPatrolPt10Lz = nNewPatrolPtZ;
		}
    return 1;
    }
    
    //--------------------------------------------------------------------------
    function int GetEscortedUnit ()
    {
    if (!m_uEscorted || !m_uEscorted.IsLive() || IsEnemy (m_uEscorted))
    	{
    	while (m_nNumEscorted && !m_uEscorted)
    		{
		    m_uEscorted = m_uEscorted1;
	    	m_uEscorted1 = m_uEscorted2;
	    	m_uEscorted2 = m_uEscorted3;
	    	m_uEscorted3 = m_uEscorted4;
	    	m_uEscorted4 = m_uEscorted5;
	    	m_uEscorted5 = m_uEscorted6;
	    	m_uEscorted6 = m_uEscorted7;
	    	m_uEscorted7 = m_uEscorted8;
	    	--m_nNumEscorted;
	    	}
	    }
    return (m_uEscorted != null);
    if (!m_uEscorted)
    	return false;
   	m_nEscortedGx = m_uEscorted.GetLocationX();
	m_nEscortedGy = m_uEscorted.GetLocationY();
	return true;
    }
    
    //--------------------------------------------------------------------------
    
    function int HaveEscortedUnit (unit uEscorted)
    {
    if (m_nNumEscorted < 1)
    	return false;
    if (uEscorted == m_uEscorted1)
    	return true;
    if (m_nNumEscorted < 2)
    	return false;
    if (uEscorted == m_uEscorted2)
    	return true;
    if (m_nNumEscorted < 3)
    	return false;
    if (uEscorted == m_uEscorted3)
    	return true;
    if (m_nNumEscorted < 4)
    	return false;
    if (uEscorted == m_uEscorted4)
    	return true;
    if (m_nNumEscorted < 5)
    	return false;
    if (uEscorted == m_uEscorted5)
    	return true;
    if (m_nNumEscorted < 6)
    	return false;
    if (uEscorted == m_uEscorted6)
    	return true;
    if (m_nNumEscorted < 7)
    	return false;
    if (uEscorted == m_uEscorted7)
    	return true;
    if (m_nNumEscorted < 8)
    	return false;
    if (uEscorted == m_uEscorted8)
    	return true;
    return false;
    }
    
    //--------------------------------------------------------------------------
    
    function int AddEscortedUnit (unit uEscorted)
    {
    if ((m_nNumEscorted >= 8) || HaveEscortedUnit (uEscorted))
    	return 0;
    ++m_nNumEscorted;
    if (m_nNumEscorted == 1)
    	m_uEscorted1 = uEscorted;
    else if (m_nNumEscorted == 2)
    	m_uEscorted2 = uEscorted;
    else if (m_nNumEscorted == 3)
    	m_uEscorted3 = uEscorted;
    else if (m_nNumEscorted == 4)
    	m_uEscorted4 = uEscorted;
    else if (m_nNumEscorted == 5)
    	m_uEscorted5 = uEscorted;
    else if (m_nNumEscorted == 6)
    	m_uEscorted6 = uEscorted;
    else if (m_nNumEscorted == 7)
    	m_uEscorted7 = uEscorted;
    else if (m_nNumEscorted == 8)
    	m_uEscorted8 = uEscorted;
    GetEscortedUnit();
    return 1;
    }

    //********************************************************
    //************* S T A T E S ******************************
    //********************************************************
    
    //------------------------------------------------------- 
    state Retreat
    {
    	unit	uAttacker;
    	int		nAttackerGx;
    	int		nAttackerGy;
    	
    if(IsAllowingWithdraw())
    	AllowScriptWithdraw(true);
    if (m_nReturnToGx < 0)
        {
        m_nReturnToGx = GetLocationX();
        m_nReturnToGy = GetLocationY();
        }
    if (GatherUnits())
    	if (IsMoving ())
    		return Moving;
    	else
    		return StartMoving;
    if (!m_nDamper)
    	{
		uAttacker = FindClosestEnemy();
		m_nDamper = 1;
		}
	else
		{
		if (IsMoving ())
			m_nDamper = (m_nDamper + 1) % 16;
		else
			m_nDamper = 0;
		}
	if (!uAttacker)
		{
		if (IsMoving())
			CallStopMoving();
		return Idle;
		}
	m_nRetreatGx = GetLocationX();
	m_nRetreatGy = GetLocationY();
	nAttackerGx = uAttacker.GetLocationX();
	nAttackerGy = uAttacker.GetLocationY();
	if (m_nRetreatGx <= nAttackerGx)
		m_nRetreatGx = nAttackerGx - (cAttackerMaxDist + 1);
	else
		m_nRetreatGy = nAttackerGy + (cAttackerMaxDist + 1);
	if (m_nRetreatGy <= nAttackerGy)
		m_nRetreatGy = nAttackerGy - (cAttackerMaxDist + 1);
	else
		m_nRetreatGy = nAttackerGy + (cAttackerMaxDist + 1);
	if ((GetLocationX() != m_nRetreatGx) || (GetLocationY() != m_nRetreatGy))
		{
    	CallMoveToPoint(m_nRetreatGx, m_nRetreatGy, GetLocationZ());
    	return Retreat;
    	}
    m_nRetreatGx = -1;	// done retreating
    return Idle;
    }
    //------------------------------------------------------- 
    state Idle
    {
    if (ForceRetreat ())
    	return Retreat;
    if ((GetHP() == GetMaxHP()) && (m_nReturnToGx >= 0) && (m_nReturnToGy >= 0))   // return after repair
       	return RestoreState,20;
    return Idle;
    }
    //-------------------------------------------------------
    // new DM/231100
    state RestoreState
    {
        int nState;
        
    if ((m_nReturnToGx >= 0) && (m_nReturnToGy >= 0))
    	{
    	CallMoveToPoint (m_nReturnToGx, m_nReturnToGy, GetLocationZ ());
    	m_nReturnToGx = -1;
   	    return RestoreState,2;
    	}
  	if (IsMoving ())
   	    return RestoreState,2;
    if (m_nState != stIdle)
        {
        nState = m_nState;
        m_nState = stIdle;
        if (nState == stMove)
          	return Moving;
        if (nState == stPatrol)
        	return Patrol,20;
        if (nState == stEscort)
        	return Escort,20;
        }
    EndState ();
    return Idle;
    }
    //--------------------------------------------------------------------------
    state StartMoving
    {
        return Moving,20;
    }
    //--------------------------------------------------------------------------
    state Moving
    {
        if (IsMoving())
        {
            return Moving;
        }
        else
        {
            EndState(); 
            return Idle;
        }
    }
    //--------------------------------------------------------------------------
    
    function int ResetPatrol()
    {
    m_nPatrolPtCount = 0;
    m_nCurrentPatrolPt = 0;
    return 1;
    }
    
    //--------------------------------------------------------------------------
	// new DM/231100
	state BeginPatrol
	{
    if (m_nPatrolPtCount < 2)
    	return Idle;
    CallMoveToPoint(m_nNextPatrolGx, m_nNextPatrolGy, m_nNextPatrolLz);
    return Patrol;
	}
    //--------------------------------------------------------------------------
    state Patrol
    {
    if (!IsMoving())
    	{
    	if (!NextPatrolPt())
    		{
    		NextCommand (1);
    		return Idle;
    		}
       	CallMoveToPoint(m_nNextPatrolGx, m_nNextPatrolGy, m_nNextPatrolLz);
    	}
    return Patrol;
    }
    //--------------------------------------------------------------------------
    state Escort
    {
    	int	 nEscortGx;
    	int  nEscortGy;
    	int  nEscortLz;
    	int	 nDx;
    	int	 nDy;
    	
   	GetEscortedUnit();
    if(!m_uEscorted)
        {
        if(IsMoving())
            {
            CallStopMoving();
            return Escort;
            }
        return Idle;
        }
        
	m_nEscortedGx = m_uEscorted.GetLocationX();    
	m_nEscortedGy = m_uEscorted.GetLocationY();    
	nEscortGx = GetLocationX();    
	nEscortGy = GetLocationY();    
	nEscortLz = GetLocationZ();    
    if (nEscortGx < m_nEscortedGx - 2)
    	nEscortGx = m_nEscortedGx - 2;
    else if (nEscortGx > m_nEscortedGx + 2)
    	nEscortGx = m_nEscortedGx + 2;
   	else
   		nDx = 0;
    if (nEscortGy < m_nEscortedGy - 2)
    	nEscortGy = m_nEscortedGy - 2;
    else if (nEscortGy > m_nEscortedGy + 2)
    	nEscortGy = m_nEscortedGy + 2;
   	else
   		nDy = 0;
   	if ((nEscortGx != m_nEscortedGx) || (nEscortGy != m_nEscortedGy))
        CallMoveToPoint(nEscortGx, nEscortGy, m_uEscorted.GetLocationZ());
    else if(IsMoving())
        CallStopMoving ();
    return Escort;
    }
    
    //------------------------------------------------------- 
    //------------------------------------------------------- 
    state Frozen
    {
        if (IsFroozen() || IsMoving())
        {
            state Frozen;
        }
        else
        {
            //!!wrocic do tego co robilismy
           
            
            if(m_nState==3)
            {
                CallMoveToPoint(m_nStayGx, m_nStayGy, m_nStayLz);
                return Moving;
            }
            
            if(m_nState==4)
                return Patrol;
            
            if(m_nState==5)
                return Escort;
            
            state Idle;
        }
    }
    
    //********************************************************
    //*********** E V E N T S ********************************
    //********************************************************
    //zwracaja true
    //false jak nie ma 
    event OnHit()
    {
    if (ForceRetreat ())
    	state Retreat;
    true;
    }
    //------------------------------------------------------- 
    event OnCannonLowAmmo(int nCannonNum)
    {
        true;
    }
    //------------------------------------------------------- 
    event OnCannonNoAmmo(int nCannonNum)
    {
        true;
    }
    //------------------------------------------------------- 
    event OnCannonFoundTarget(int nCannonNum, unit uTarget)
    {
        false;//gdyby zwrocic true to dzialko nie strzeli
    }
    //------------------------------------------------------- 
    event OnCannonEndFire(int nCannonNum, int nEndStatus)
    {
        false;
    }
    //------------------------------------------------------- 
    event OnFreezeForSupplyOrRepair(int nFreezeTicks)
    {
              if(state!=Frozen) m_nState = 0;
        if((state==Moving) || (state==StartMoving))
            m_nState=3;
        if(state==Patrol)
            m_nState=4;
        if(state==Escort)
            m_nState=5;
        CallFreeze(nFreezeTicks);
        state Frozen;
    }
    //------------------------------------------------------- 
    event OnTransportedToNewWorld()
    {
    }
    
    //********************************************************
    //*********** C O M M A N D S ****************************
    //********************************************************
    command Initialize()
    {
	ResetPatrol ();
	ResetEscort ();
    m_uEscorted = null;
    m_nStayGx = GetLocationX();
    m_nStayGy = GetLocationY();
    m_nStayLz = GetLocationZ();
	retreatMode = rmHP50;
	m_nRetreatGx = -1;
	m_nReturnToGx = -1;
	m_nGatherGx = -1;
	m_nDamper = 0;
    traceMode = 0;
    }
    //--------------------------------------------------------------------------
    command Uninitialize()
    {
        //wykasowac referencje
        m_uSpecialUnit = null;
    }
    //--------------------------------------------------------------------------
    command SetLights(int nMode) button lights priority 204
    {
        if (nMode == -1)
        {
            lights = (lights + 1) % 3;
        }
        else
        {
            lights = nMode;
        }
        SetLightsMode(lights);
    }
    
    
    //--------------------------------------------------------------------------
    command Stop() button "translateCommandStop" description "translateCommandStopDescription" hotkey priority 20
    {
   	m_nReturnToGx = -1;
   	ResetEscort ();
    if(IsMoving())
        {
        CallStopMoving();
        }
    state Idle;
    }
    
    //--------------------------------------------------------------------------
    command Move(int nGx, int nGy, int nLz) button "translateCommandMove" description "translateCommandMoveDescription" hotkey priority 21
    {
   	m_nReturnToGx = -1;
    m_nStayGx = nGx;
    m_nStayGy = nGy;
    m_nStayLz = nLz;
    if (m_nGatherGx < 0)
    	{
	    m_nGatherGx = nGx;
	    m_nGatherGy = nGy;
	    m_nGatherLz = nLz;
	    }
    if(state==Frozen)
        m_nState = 3;
    else
        {
        CallMoveToPoint(nGx, nGy, nLz);
        state StartMoving;
        }
        
    }
     //--------------------------------------------------------------------------
    
    command UserOneParam0(int nMode) button retreatMode description "translateCommandStateRetreatModeDescription" priority 25
    {
    if (nMode == -1)
        retreatMode = (retreatMode + 1) % rmNum;
    else
        {
        assert(nMode == 0);
        retreatMode = nMode;
        }
    }
    
    //--------------------------------------------------------------------------
    command Patrol(int nGx, int nGy, int nLz) button "translateCommandPatrol" description "translateCommandPatrolDescription" hotkey priority 27
    {
   	m_nReturnToGx = -1;
   	ResetEscort ();
	AddPatrolPt (nGx, nGy, nLz);
    state BeginPatrol;
    }
    
    //--------------------------------------------------------------------------
    command UserNoParam1() button "translateCommandResetPatrol" description "translateCommandResetPatrolDescription" hotkey priority 28
    {
    ResetPatrol();
    NextCommand (0);
    }
    
    //--------------------------------------------------------------------------
    command UserNoParam2() button "translateCommandRestartPatrol" description "translateCommandRestartPatrolDescription" hotkey priority 29
    {
   	m_nReturnToGx = -1;
   	ResetEscort ();
    state BeginPatrol;
    }
    
    
    //--------------------------------------------------------------------------
    command Escort(unit uUnit) button "translateCommandEscort" description "translateCommandEscortDescription" hotkey priority 31 
    {
   	m_nReturnToGx = -1;
    AddEscortedUnit (uUnit);
    state Escort;
    }
    
     //--------------------------------------------------------------------------
    command UserPoint9(int nGx, int nGy, int nLz) button "translateCommandSetGatherPoint" description "translateCommandSetGatherPointDescription" hotkey priority 52
    {
    m_nGatherGx = nGx;
    m_nGatherGy = nGy;
    m_nGatherLz = nLz;
    NextCommand (0);
    }
    
   //--------------------------------------------------------------------------
    command UserNoParam0() button "translateCommandRetreat" description "translateCommandRetreatDescription" hotkey priority 53
    {
    ResetEscort ();
    m_nDamper = 0;
    state Retreat;
    }
    
    //--------------------------------------------------------------------------
    command Enter(unit uEntrance) hidden button "translateCommandEnter"
    {
   	m_nReturnToGx = -1;
    CallMoveInsideObject(uEntrance);
    state StartMoving;
	}
    
    //-------------------------------------------------------
    command SpecialChangeUnitsScript() button "translateCommandChangeScript" description "translateCommandChangeScriptDescription" hotkey priority 254 
    {
        //special command - no implementation
    }
    //--------------------------------------------------------------------------
    command UserOneParam9(int nMode) button traceMode priority 255
    {
  	  if (nMode == -1)
	    traceMode = (traceMode + 1) % 2;
    else
	    {
	    assert(nMode == 0);
    	traceMode = nMode % 2;
    	}
    }
}
// changes by Dietfrid Mali (Diedel) 28 nov 2000
// New movement modes
//		Generally unit stays as far away from target as possible
//		aggressive: get close enough to target to be able to attack with all mounted guns
// 		cautious: get close enough to target to be able to attack with farthest reaching gun
//		Hints: It is generally possible that a unit in one of these movement modes gets stuck
//		in unviable terrain. Tests proved however that this is rarely ever the case and that
//		the result of this behaviour by far exceeds those of the default movement.
// Extended patrol mode
//		up to 10 patrol points per unit
//		restart patrol without having to set all patrol points again
//		delete all patrol points if a new patrol route is desired
// Escort mode with improvements:
//    Escort will stick with escorted unit
//    Escort will attack primarily attackers of the escorted unit
//    Escort will stick with a target until it is eliminated
//    Escort will switch to new target if it is an airplane and the previous target is not
//    Escort will return to escorted unit after ammo reload
// Script name: "Flugzeug (Elite)"
// new movement mode button labels "vorsichtig", "aggressiv"
// new patrol control buttons "Patr. starten", "weiter patr."
// renamed state Nothing to state Idle
// Changes.
// v1.7 (12 jan 01): Fixed plane not landing after forced retreat because of damage.

aircraft "translateScriptNameCrackAircraftv17"
{
    consts
    {
    	// attack phase
        apRally=0;
        apMoveIn=1;
        apAttack=2;
        apMoveOut=3;
        attackRange=7;
        
        // attack mode
        amDynamic=0;
        amStatic=1;
        
        // states
        stIdle = 0;
        stAttackPoint = 1;
        stAttack = 2;
        stMove = 3;
        stPatrol = 4;
        stEscort = 5;
        stRetreat = 6;
        
        disableFire=0;
        findTargetWaterUnit = 1;
        findTargetFlyingUnit = 2;
        findTargetNormalUnit = 4;
        findTargetBuildingUnit  = 8;
        findTargetAnyUnit = 15;
        
        // 
        mmFollowEnemy = 0;
        mmHoldPos = 1;
        mmCount = 2;

        // attack distance        
        adStandard = 0;
        adCautious = 1;
        adAggressive = 2;
        adNum = 3;
        
        // trace modes
        tmNone = 0;
        tmAll = 1;
        tmAttack = 2;
        tmPatrol = 3;
        tmEscort = 4;
        tmNum = 5;

		// retreat modes        
        rmNone = 0;
        rmHP66 = 1;
        rmHP50 = 2;
        rmHP25 = 3;
        rmNum = 4;
        
        cAttackerMaxDist = 15;
        
    	m_nMaxPatrolPtCount = 10;
    
        //typ rasy (jakich IFF'ow szukamy
        findEnemyUnit           = 1;
        //kryterium szukania
        findNearestUnit         = 1;
        findWeakestUnit         = 2;
        //typ szukanego obiektu
        findDestinationAnyUnit          = 15;
        //IsInRange
        notInRange = 0;//poza zasiegiem (za duza odleglosc)
        inRangeBadAngleAlpha = 1;//w zasiegu strzalu ale zly kat alpha trzeba obrocic podwozie
        inRangeBadAngleBeta = 2;//w zasiegu strzalu ale zly kat beta
        inRangeBadHit = 3; //w zasiegu strzalu ale nie mozna trafic (cos zaslania)
        inRangeGoodHit = 4;
        
        cMaxDamper = 1;
    }
    unit m_uTarget;
    int  m_nTargetGx;
    int  m_nTargetGy;
    int  m_nTargetLz;
    int  m_nStayGx;
    int  m_nStayGy;
    int  m_nStayLz;
    int  m_nAttackGx;
    int  m_nAttackGy;
    int  m_nAttackPhase;
    int  m_nDamper;
    int  m_nState;
    int  m_bNeedReload;
    int  m_bNeedStop;
    int  m_nLandCounter;
    int	 m_nDestDist;	// use for repeated attempts to correct bad elevation angle
    int  m_nDestGx;
    int  m_nDestGy;
    
    int  m_nNextPatrolGx;
    int  m_nNextPatrolGy;
    int  m_nNextPatrolLz;
    int  m_nPatrolPt1Gx;
    int  m_nPatrolPt1Gy;
    int  m_nPatrolPt1Lz;
    int  m_nPatrolPt2Gx;
    int  m_nPatrolPt2Gy;
    int  m_nPatrolPt2Lz;
    int  m_nPatrolPt3Gx;
    int  m_nPatrolPt3Gy;
    int  m_nPatrolPt3Lz;
    int  m_nPatrolPt4Gx;
    int  m_nPatrolPt4Gy;
    int  m_nPatrolPt4Lz;
    int  m_nPatrolPt5Gx;
    int  m_nPatrolPt5Gy;
    int  m_nPatrolPt5Lz;
    int  m_nPatrolPt6Gx;
    int  m_nPatrolPt6Gy;
    int  m_nPatrolPt6Lz;
    int  m_nPatrolPt7Gx;
    int  m_nPatrolPt7Gy;
    int  m_nPatrolPt7Lz;
    int  m_nPatrolPt8Gx;
    int  m_nPatrolPt8Gy;
    int  m_nPatrolPt8Lz;
    int  m_nPatrolPt9Gx;
    int  m_nPatrolPt9Gy;
    int  m_nPatrolPt9Lz;
    int  m_nPatrolPt10Gx;
    int  m_nPatrolPt10Gy;
    int  m_nPatrolPt10Lz;
    int  m_nPatrolPtCount;
    int  m_nCurrentPatrolPt;
    
    int  m_nEscortedGx;
    int  m_nEscortedGy;
    int  m_nEscortedLz;
    unit m_uEscorted;
    unit m_uEscorted1;
    unit m_uEscorted2;
    unit m_uEscorted3;
    unit m_uEscorted4;
    unit m_uEscorted5;
    unit m_uEscorted6;
    unit m_uEscorted7;
    unit m_uEscorted8;
    int	 m_nCurEscorted;
    int  m_nNumEscorted;
    unit m_uAttacker;
    
    int  m_nRallyGx;
    int  m_nRallyGy;
    
    int	 m_nGatherGx;
    int	 m_nGatherGy;
    int	 m_nGatherLz;
    
    int	 m_nRetreatGx;
    int	 m_nRetreatGy;
    
    int	 m_nReturnToGx;
    int	 m_nReturnToGy;
    
    int  m_nTgtRelPos1;
    int  m_nTgtRelPos2;
    int	 m_bSwapRelPos;
    int  m_bIncToggle;

    enum lights
    {
        "translateCommandStateLightsAUTO",
        "translateCommandStateLightsON",
        "translateCommandStateLightsOFF",
multi:
        "translateCommandStateLightsMode"
    }
    
    enum movementMode
    {
        "translateCommandStateFollowEnemy",
        "translateCommandStateHoldPosition",
            
multi:
        "translateCommandStateMovement"
    }
    
    enum attackDistance
    {
        "translateCommandStateADStandard",
        "translateCommandStateADCautious",
        "translateCommandStateADAggressive",
            
multi:
        "translateCommandStateAttackDistance"
    }
    
    enum attackMode 
    {
        "translateCommandStateDynamicAttack",
        "translateCommandStateStaticAttack",
multi:
        "translateCommandStateAttackMode"
    }
    
    enum retreatMode
    {
        "translateCommandStateNoRetreat",
        "translateCommandStateRetreatHP66",
        "translateCommandStateRetreatHP50",
        "translateCommandStateRetreatHP25",
multi:
        "translateCommandStateRetreatMode"
    }
/*Trace>>>
    enum eTraceMode
    {
        "translateCommandStateExtTraceOFF",
        "translateCommandStateExtTraceALL",
        "translateCommandStateExtTraceATTACK",
        "translateCommandStateExtTracePATROL",
        "translateCommandStateExtTraceESCORT",
multi:
        "translateCommandStateExtTraceMode"
    }
<<<Trace*/  

    state Idle;
    state HoldPosition;
    state StartMoving;
    state Moving;
    state StartLanding;
    state Landing;
    state MovingAfterReload;
    state RestoreState;
    state AutoAttacking;
    state Attacking;
    state AttackingPoint;
    state BeginPatrol;
    state Patrol;
    state Escort;
    state Retreat;
    //for flyables
    state MovingForGetSupply;
    state GettingSupply;
    
    //********************************************************
    //********* F U N C T I O N S ****************************
    //********************************************************
    //--------------------------------------------------------------------------
    
/*Trace>>>
    function int TraceMode (int nTraceMode)
    {
    if ((nTraceMode == eTraceMode) || (eTraceMode == tmAll))
    	return true;
    return false;
    }
<<<Trace*/  
    
    //--------------------------------------------------------------------------
    
    function int ResetPatrol()
    {
    m_nPatrolPtCount = 0;
    m_nCurrentPatrolPt = 0;
    return 1;
    }
    
    //--------------------------------------------------------------------------
    
    function int ResetEscort()
    {
    m_uEscorted = null;
    m_uAttacker = null;
    m_nCurEscorted = 0;
    m_nNumEscorted = 0;
    return 1;
    }
    
    //------------------------------------------------------- 
    function int IsBombPlane ()
    {
    return (GetCannonType(0)==cannonTypeBomb);
    }
    //--------------------------------------------------------------------------
    
    function int SetAttackMode (unit uTarget)
    {
    if (IsBombPlane() || (!uTarget && !uTarget.IsBuilding ()))
        attackMode = amStatic;
	else
		attackMode = amDynamic;
	return attackMode;
    }

    //-------------------------------------------------------
    function int SetTarget(unit uTarget)
    {
    m_uTarget = uTarget;
    SetTargetObject (uTarget);
    return true;
    }
    
    //--------------------------------------------------------------------------
    
    function int ResetAttack(unit uTarget)
    {
	m_nReturnToGx = -1;
    m_nTgtRelPos1 = 0;
    m_nTgtRelPos2 = 0;
    m_bSwapRelPos = 0;
    m_nAttackPhase = apRally;
    SetAttackMode (uTarget);
    SetTarget(uTarget);
    if (!uTarget)
        StopCannonFire(-1);
    return 1;
    }
    
    //------------------------------------------------------- 
    // new DM/211100
    // Set current position as destination position
    function int StayAtCurPos()
    {
    m_nStayGx = GetLocationX();
    m_nStayGy = GetLocationY();
    m_nStayLz = GetLocationZ();
    return 1;
     }
    //-------------------------------------------------------
    function int Land()
    {
    if (!IsOnGround())
    {
        if ((m_nLandCounter == 1) && HaveCannonsMissingAmmo() && FindArtefact(artefactRegenerateExternalAmmo))
            {
            m_nStayGx = GetFoundArtefactX();
            m_nStayGy = GetFoundArtefactY();
            m_nStayLz = GetFoundArtefactZ();
            }
        else
            StayAtCurPos ();
        if (!IsFreePoint(m_nStayGx, m_nStayGy, m_nStayLz))
            {
            if (Rand(2))
                m_nStayGx = m_nStayGx + (Rand(m_nLandCounter) + 1);
            else
                m_nStayGx = m_nStayGx - (Rand(m_nLandCounter) + 1);
            if (Rand(2))
                m_nStayGy = m_nStayGy + (Rand(m_nLandCounter) + 1);
            else
                m_nStayGy = m_nStayGy - (Rand(m_nLandCounter) + 1);
            m_nLandCounter = m_nLandCounter + 1;
            if (IsFreePoint(m_nStayGx, m_nStayGy, m_nStayLz))
                CallMoveAndLandToPoint(m_nStayGx, m_nStayGy, m_nStayLz);
            else
                CallMoveLowToPoint(m_nStayGx, m_nStayGy, m_nStayLz);
            }
        else
            CallMoveAndLandToPoint(m_nStayGx, m_nStayGy, m_nStayLz);
        return true;
        }
    else
        return false;
    }
    //------------------------------------------------------- 
    function int FindBestTarget()
    {
        int nFindTarget;

    nFindTarget = 0;
    if (CanCannonFireToAircraft(0))
	    {
        nFindTarget = findTargetFlyingUnit;
    	}
    if (CanCannonFireToGround(0))
    	{
        if (GetCannonType(0) == cannonTypeEarthquake)
        	{
            nFindTarget = nFindTarget | findTargetBuildingUnit;
        	}
        else
        	{
            nFindTarget = nFindTarget | findTargetNormalUnit | findTargetWaterUnit | findTargetBuildingUnit;
        	}
    	}
    SetTarget(FindClosestEnemyUnitOrBuilding(nFindTarget));
    }
    //------------------------------------------------------- 
    // new DM/211100
    // Get gun range of lowest ranged gun on vehicle
    // returns gun range in low byte, gun with that range in high byte
    function int GetMinGunRange ()
    {
    	int	h;
    	int	i;
    	int	nGun;
   		int	nRange;
    
    nRange = -1;	
    i = GetCannonsCount();
    while (i)
    	{
    	--i;
    	h = GetCannonShootRange (i);
    	if ((nRange < 0) || (h < nRange))
    		{
    		nRange = h;
    		nGun = i;
    		}
    	}
/*Trace>>>
  	if (TraceMode (tmAttack))
  		{
  		TraceD ("min. gun range=");
  		TraceD (nRange);
  		TraceD (", gun=");
  		TraceD (nGun);
  		TraceD ("\n");
  		}
<<<Trace*/  
	return (nRange + (nGun * 65536));
    }
    
    //------------------------------------------------------- 
    // new DM/211100
    // Get gun range of highest ranged gun on vehicle
    // returns gun range in low byte, gun with that range in high byte
    function int GetMaxGunRange ()
    {
    	int	h;
    	int	i;
    	int	nGun;
   		int	nRange;
    
    nRange = -1;	
    i = GetCannonsCount();
    while (i)
    	{
    	--i;
    	h = GetCannonShootRange (i);
    	if (h > nRange)
    		{
    		nRange = h;
    		nGun = i;
    		}
    	}
/*Trace>>>
  	if (TraceMode (tmAttack))
  		{
  		TraceD ("max. gun range=");
  		TraceD (nRange);
  		TraceD (", gun=");
  		TraceD (nGun);
  		TraceD ("\n");
  		}
<<<Trace*/  
	return (nRange + (nGun * 65536));
    }
    
    //------------------------------------------------------- 
    // new DM/211100
    // Get gun range depending from attackDistance
    // determine gun range and gun with that range depending on movementMode
    function int GetGunRange ()
    {
    if (attackDistance == adCautious)
    	return GetMaxGunRange ();
   	return GetMinGunRange ();
    }
    
    //------------------------------------------------------- 
    // DM/071200
    function int AdjustAttackDistance (int nDestDist, int bMoveLow)
    {
        int x;
        int y;
        int xTgt;
        int yTgt;
        int	nDx;
        int	nDy;
        int	nDd;
        int	h;
        int hDx;
        int hDy;
        int hDx0;
        int hDy0;
        int nCurDist;
        int bForceInc;
        
	// the following code computes a destination position that brings the target
	// into gun range. Since there are no trigonometrical functions available in
	// Moon C, the distance is iterated until the unit is close enough.
	nDestDist = nDestDist - 1;
/*Trace>>>
  	if (TraceMode (tmAttack))
		{
		TraceD ("adjusting attack dist to ");
		TraceD (nDestDist);
		TraceD ("\n");
		}
<<<Trace*/  
	x = GetLocationX();
	y = GetLocationY();
	xTgt = m_uTarget.GetLocationX();
	yTgt = m_uTarget.GetLocationY();
	if (!xTgt && !yTgt) // catch Moon-C bug
	    {
	    xTgt = x;
	    yTgt = y;
	    }
	nCurDist = Distance (x,y,xTgt,yTgt);
	if ((attackDistance == adStandard) && (nCurDist <= nDestDist) && (!IsBombPlane() || (nCurDist > 0)))
	    return 0;
	
	// set iteration direction for X axis
	if (x < xTgt)
		nDx = -1;
	else if (x > xTgt)
		nDx = 1;
	else
		nDx = 0;
	// set iteration direction for Y axis
	if (y < yTgt)
		nDy = -1;
	else if (y > yTgt)
		nDy = 1;
	else
		nDy = 0;
		
	hDx = nDx * (x - xTgt);
	hDy = nDy * (y - yTgt);
	hDx0 = hDx;
	hDy0 = hDy;
	h = nDestDist * nDestDist;
	if (!nDx && !nDy)
	    bForceInc = 1;
	else
	    bForceInc = 0;
/*Trace>>>
	if (TraceMode (tmAttack))
		{
		TraceD ("---------------------------------------------------------------------\n");
		TraceD ("Adjusting. destDist=");
		TraceD (nDestDist);
		TraceD (", hDx=");
		TraceD (hDx);
		TraceD (", hDy=");
		TraceD (hDy);
		TraceD ("\n");
		TraceD (">>>>>>>>>> x,y,xTgt,yTgt=");
		TraceD (x);
		TraceD (",");
		TraceD (y);
		TraceD (",");
		TraceD (xTgt);
		TraceD (",");
		TraceD (yTgt);
		TraceD ("\n");
		}
<<<Trace*/  
	while (hDx * hDx + hDy * hDy < h)
		{
		if (m_bIncToggle)
		    {
		    m_bIncToggle = 0;
    		if (nDx || bForceInc)
	    		++hDx;
	    	}
	    else
	        {
	        m_bIncToggle = 1;
		    if (nDy || bForceInc)
			    ++hDy;
			}
		}
	if (!m_bIncToggle)
	    m_bIncToggle = 1;
	else
	    m_bIncToggle = 0;
	while (hDx * hDx + hDy * hDy > h)
		{
		if (m_bIncToggle)
		    {
		    m_bIncToggle = 0;
    		if ((nDx || bForceInc) && hDx)
	    		--hDx;
	    	}
	    else
	        {
	        m_bIncToggle = 1;
		    if ((nDy || bForceInc) && hDy)
			    --hDy;
			}
		}
/*Trace>>>
	if (TraceMode (tmAttack))
		{
		TraceD ("Done. destDist=");
		TraceD (nDestDist);
		TraceD (", hDx,hDy=");
		TraceD (hDx);
		TraceD (",");
		TraceD (hDy);
		TraceD ("\n");
		}
<<<Trace*/  
	if ((hDx0 == hDx) && (hDy0 == hDy))
		return 0;
	x = xTgt + nDx * hDx;
	y = yTgt + nDy * hDy;
	if (nCurDist == Distance (x,y,xTgt,yTgt))
	    return 0;
/*Trace>>>
  	if (TraceMode (tmAttack))
    	TraceD ("adjusting range to target\n");
<<<Trace*/  
    if (bMoveLow)
	    CallMoveLowToPoint(x, y, m_uTarget.GetLocationZ());
    else
	    CallMoveToPoint(x, y, m_uTarget.GetLocationZ());
	return 1;
    }
    
    //------------------------------------------------------- 
    // new DM/211100
    // move unit around its target in 90 degree angle, modifying the angle by 45 deg after each round
    function int MoveAroundTarget (int nDestDist, int bMoveLow)
    {
    	int	xTgt;
    	int	yTgt;
    	
    xTgt = m_nTargetGx;
    yTgt = m_nTargetGy;
    if (((m_nTgtRelPos1 % 2) == 1) && (nDestDist > 1))
    	nDestDist = nDestDist / 2;
    if (m_nTgtRelPos1 == 0)		// 12 o'clock
    	yTgt = yTgt - nDestDist;
    else if (m_nTgtRelPos1 == 1)	// 1:30
    	{
    	yTgt = yTgt + nDestDist;
    	xTgt = xTgt + nDestDist;
    	}
    else if (m_nTgtRelPos1 == 2)	// 3 o'clock
    	xTgt = xTgt + nDestDist;
    else if (m_nTgtRelPos1 == 3)	// 4:30
    	{
    	yTgt = yTgt - nDestDist;
    	xTgt = xTgt + nDestDist;
    	}
    else if (m_nTgtRelPos1 == 4)	// 6 o'clock
    	yTgt = yTgt - nDestDist;
    else if (m_nTgtRelPos1 == 5)	// 7:30
    	{
    	yTgt = yTgt - nDestDist;
    	xTgt = xTgt - nDestDist;
    	}
    else if (m_nTgtRelPos1 == 6)	// 9 o'clock
    	xTgt = xTgt + nDestDist;
    else if (m_nTgtRelPos1 == 7)	// 10:30
    	{
    	yTgt = yTgt + nDestDist;
    	xTgt = xTgt - nDestDist;
    	}
    if (xTgt < 0)
    	xTgt = 0;
    if (yTgt < 0)
    	yTgt = 0;
   	// first go through the even, then through the odd numbered positions
    if (m_nTgtRelPos1 == 6)
    	m_nTgtRelPos1 = 1;
    else if (m_nTgtRelPos1 == 7)
    	m_nTgtRelPos1 = 0;
    else
	    m_nTgtRelPos1 = m_nTgtRelPos1 + 2;
/*    
    if (xTgt < GetWorldLeft())
    	xTgt = GetWorldLeft();	
    else if (xTgt > GetWorldRight())
    	xTgt = GetWorldRight();	
    if (yTgt > GetWorldTop())
    	yTgt = GetWorldTop();	
    else if (xTgt < GetWorldBottom())
    	yTgt = GetWorldBottom();	
*/
    if (bMoveLow)
	   	CallMoveLowToPoint(xTgt, yTgt,0);
    else
	   	CallMoveToPoint(xTgt, yTgt, m_nTargetLz);
	return 1;
    }
    
    //------------------------------------------------------- 
    // new DM/211100
    // move unit around its target in criss cross manner between the 8 points of 
    // a regular octangle.
    function int CrissCrossTarget (int nDestDist, int nMoveMode)
    {
	    int	h;
    
    m_nRallyGx = m_nTargetGx;
    m_nRallyGy = m_nTargetGy;
   	h = m_nTgtRelPos2;
    if (m_bSwapRelPos)
    	if (h % 2)
    		h = h - 1;
    	else
    		h = h + 1;
    m_nTgtRelPos2 = (m_nTgtRelPos2 + 1) % 8;
    if (m_nTgtRelPos2 == 0)
    	m_bSwapRelPos = (m_bSwapRelPos + 1) % 2;
    	
    if (h == 0)
    	m_nRallyGy = m_nRallyGy + nDestDist;
    else if (h == 1)
    	m_nRallyGy = m_nRallyGy - nDestDist;
    else if (h == 2)
    	{
    	nDestDist = (nDestDist * 2) / 3;
    	m_nRallyGx = m_nRallyGx + nDestDist;
    	m_nRallyGy = m_nRallyGy + nDestDist;
    	}
    else if (h == 3)
    	{
    	nDestDist = (nDestDist * 2) / 3;
    	m_nRallyGx = m_nRallyGx - nDestDist;
    	m_nRallyGy = m_nRallyGy - nDestDist;
    	}
    else if (h == 4)
    	m_nRallyGx = m_nRallyGx + nDestDist;
    else if (h == 5)
    	m_nRallyGx = m_nRallyGx - nDestDist;
    else if (h == 6)
    	{
    	nDestDist = (nDestDist * 2) / 3;
    	m_nRallyGx = m_nRallyGx + nDestDist;
    	m_nRallyGy = m_nRallyGy - nDestDist;
    	}
    else if (h == 7)
    	{
    	nDestDist = (nDestDist * 2) / 3;
    	m_nRallyGx = m_nRallyGx - nDestDist;
    	m_nRallyGy = m_nRallyGy + nDestDist;
    	}
/*Trace>>>
    if (TraceMode (tmAttack))
    	{
    	TraceD (">>> next rally point is ");
    	TraceD (m_nTgtRelPos2 + m_bSwapRelPos * 8);
    	TraceD ("\n");
    	}
<<<Trace*/  
    if (nMoveMode == 0)
	   	CallMoveLowToPoint(m_nRallyGx, m_nRallyGy,0);
    else if (nMoveMode == 1)
	   	CallMoveToPoint(m_nRallyGx, m_nRallyGy, m_nTargetLz);
	return 1;
    }
    
    //------------------------------------------------------- 
    function int StaticBombAttack ()
    {
/*Trace>>>
  	if (TraceMode (tmAttack))
    	TraceD("AttackRun: bomb plane \n");
<<<Trace*/  
    if ((GetLocationX() == m_nTargetGx) && (GetLocationY() == m_nTargetGy))	//nad celem
	    {
        if (IsMoving())
    	    {
/*Trace>>>
		  	if (TraceMode (tmAttack))
            	TraceD("CallStopMoving\n");
<<<Trace*/  
            CallStopMoving();
        	}
        return true;
        }
    else
        {
/*Trace>>>
	  	if (TraceMode (tmAttack))
        	TraceD("GoToTarget: Target out of range \n");
<<<Trace*/  
        CallMoveToPoint(m_nTargetGx,m_nTargetGy,0);
        return false;
	    }
    }	// bomb plane
    
    //------------------------------------------------------- 
    function int Engage (int bAttackOnPoint)
    {
/*Trace>>>
  	if (TraceMode (tmAttack))
    	TraceD("Attack: Engaging target\n");
<<<Trace*/  
    if (IsMoving())
        {
        if(m_bNeedStop)
            {
            m_bNeedStop=false;
            CallStopMoving();
	        }
	    return 0;
        }
    else
        {
        if(bAttackOnPoint)
            CallTurnToAngle(GetCannonAngleToPoint(0,m_nTargetGx,m_nTargetGy,m_nTargetLz));
        else
            CallTurnToAngle(GetCannonAngleToTarget(0,m_uTarget));
        return 1;
        }
    }
    
    //------------------------------------------------------- 
    // new DM/241100
    // this function moves an airplane into attack reach of its target.
    
    function int StaticAttackRun (int bAttackOnPoint)
    {
        int nRangeMode;
        int	m_nRallyGx;
        int	m_nRallyGy;
        int nDistance;
        int	nDestDist;
        int nMainGun;
        int	h;

    if (IsBombPlane())
        return StaticBombAttack ();
        
    h = GetGunRange ();
    nDestDist = h % 65536;
    nMainGun = h / 65536;
    
    AdjustAttackDistance (nDestDist, true);
    if(bAttackOnPoint)
        nRangeMode = IsPointInCannonRange(nMainGun,m_nTargetGx,m_nTargetGy,m_nTargetLz);
    else
        nRangeMode = IsTargetInCannonRange(nMainGun, m_uTarget);
    
    if (nRangeMode == inRangeGoodHit)
        {
        if (IsMoving() && m_bNeedStop)
            {
            m_bNeedStop=false;
            CallStopMoving();
	        }
	    return Engage (bAttackOnPoint);
        }
    
    if(nRangeMode == inRangeBadAngleAlpha) //w zasiegu ale trzeba odwrocic czolg 
        {
	    Engage (bAttackOnPoint);
        return false;
    	}
    
    if(nRangeMode == inRangeBadHit) 
	    {
	    MoveAroundTarget (nDestDist, true);
	    return Engage (bAttackOnPoint);
	    }
	    
    m_bNeedStop=true;
    if(nRangeMode == inRangeBadAngleBeta) 
    	{
    	m_nRallyGx = m_uTarget.GetLocationX();
    	m_nRallyGy = m_uTarget.GetLocationY();
        if ((GetLocationX() == m_nRallyGx) && (GetLocationY() == m_nRallyGy))
        	{
        	MoveAroundTarget (nDestDist, true);
        	m_nDestDist = nDestDist;
        	}
        else
        	{
        	if ((m_nDestDist > nDestDist) || (m_nDestDist <= 0))
        		m_nDestDist = nDestDist;
        	m_nDestDist = nDestDist / 2;
        	MoveAroundTarget (m_nDestDist, true);
        	}
        return true;
	    }
    return false;
    }
    
    //------------------------------------------------------- 
    // new DM/241100
    function int DynamicAttackRun (int bAttackOnPoint)
    {
        int nRangeMode;
        int nTgtDist;
        int nRallyDist;
        int	nDestDist;
        int nMainGun;
        int	nGx;
        int	nGy;
        int h;
        
    h = GetGunRange ();
    nDestDist = h % 65536;
    nMainGun = h / 65536;
    
    m_nTargetGx = m_uTarget.GetLocationX();
    m_nTargetGy = m_uTarget.GetLocationY();
    m_nTargetLz = m_uTarget.GetLocationZ();
    if(m_nAttackPhase == apRally)	// get initial position for next attack run
	    {
/*Trace>>>
	  	if (TraceMode (tmAttack))
	    	TraceD ("Attack phase is apRally \n");
<<<Trace*/  
	    CrissCrossTarget (nDestDist + 1, -1);
        m_nAttackPhase = apMoveIn;
        return false;
    	}
    
    if (m_nAttackPhase == apMoveIn)
	    {
/*Trace>>>
	  	if (TraceMode (tmAttack))
	    	TraceD ("Attack phase is apMoveIn - changed attack phase to apAttack\n");
<<<Trace*/  
        CallMoveLowToPoint (m_nTargetGx, m_nTargetGy, 0);
        m_nAttackPhase=apAttack;
        return false;
    	}
    	
    nGx = GetLocationX();
    nGy = GetLocationY();
   	nRallyDist = Distance (nGx, nGy, m_nRallyGx, m_nRallyGy);
    if (m_nAttackPhase == apAttack)
    	{
/*Trace>>>
	  	if (TraceMode (tmAttack))
	    	TraceD ("Attack phase is apAttack\n");
<<<Trace*/  
    	// check if close enough to next rally point, if so, move out
	   	if (nRallyDist < 3)
	   		{
/*Trace>>>
		  	if (TraceMode (tmAttack))
		    	TraceD ("changed attack phase to apRally \n");
<<<Trace*/  
            m_nAttackPhase = apRally;
	   		}
	    nTgtDist = Distance (nGx, nGy, m_nTargetGx, m_nTargetGy);
	    if (!IsMoving() || (nTgtDist < 4))
	    	{
	        CallMoveLowToPoint (m_nRallyGx, m_nRallyGy, 0);
	        m_nAttackPhase = apMoveOut;
	        }
        if (IsBombPlane() && (nTgtDist < 5))
        	return true;
        if  (nTgtDist <= nDestDist)
        	return true;
/*Trace>>>
	  	if (TraceMode (tmAttack))
	    	TraceD ("changed attack phase to apMoveOut\n");
<<<Trace*/  
        m_nAttackPhase = apMoveOut;
   	    return false;
        }
        
    if (m_nAttackPhase == apMoveOut)
	    {
/*Trace>>>
	  	if (TraceMode (tmAttack))
	    	TraceD ("Attack phase is apMoveOut \n");
<<<Trace*/  
        if (!IsMoving() || (nRallyDist < 3))
    	    {
/*Trace>>>
		  	if (TraceMode (tmAttack))
		    	TraceD ("changed attack phase to apRally \n");
<<<Trace*/  
            m_nAttackPhase=apRally;
	        return false;
        	}
        return true;
    	}
    }
    
    //------------------------------------------------------- 
    function int AttackRun(int bAttackOnPoint)
    {
	if (attackMode == amStatic)
		return StaticAttackRun(bAttackOnPoint);    
	return DynamicAttackRun(bAttackOnPoint);	// moves plane around target		
    }
    
    //------------------------------------------------------- 
    function int TargetInRange()
    {
        int nRangeMode;
        int nDx;
        int nDy;
        nRangeMode = IsTargetInCannonRange(0, m_uTarget);
        
    if (nRangeMode == inRangeGoodHit) 
        return true;
    if(nRangeMode == inRangeBadAngleAlpha) //w zasiegu ale trzeba odwrocic czolg 
        {
        CallTurnToAngle(GetCannonAngleToTarget(0,m_uTarget));
        return true;
        }
    return false;
    }
    //-------------------------------------------------------
    // new DM/231100
    function int ResetState (int nNewState, unit uTarget)
    {
    ResetAttack (uTarget);
    if (nNewState != stEscort)
        ResetEscort ();
    m_nState = nNewState;
    }
    //-------------------------------------------------------
    // new DM/231100
    function int SaveState ()
    {
    if(state == AttackingPoint)
        m_nState = stAttackPoint;
    else if(state == Attacking)
        m_nState = stAttack;
    else if(state == Moving)
        m_nState = stMove;
    else if(state == Patrol)
        m_nState = stPatrol;
    else if(state == Escort)
        m_nState = stEscort;
    else
    	m_nState = stIdle;
    return m_nState;
    }
    //-------------------------------------------------------
    function int CheckAmmo()
    {
    if(CannonRequiresSupply(0) && (m_bNeedReload || !GetAmmoCount()) && FindSupplyCenterPlace())
        {
        SaveState();
        m_nReturnToGx = GetLocationX(); 
        m_nReturnToGy = GetLocationY();
        
        m_nStayGx = GetFoundSupplyCenterPlaceX();
        m_nStayGy = GetFoundSupplyCenterPlaceY();
        m_nStayLz = GetFoundSupplyCenterPlaceZ();
        //CallMoveAndLandToPointForce(m_nStayGx, m_nStayGy, m_nStayLz);
        CallMoveToPointForce(m_nStayGx, m_nStayGy, m_nStayLz);//dodane 25.01.2000
        return true;
        }
    return false;
    }
    //-------------------------------------------------------
    function int EndState()
    {
    NextCommand(1);
    }
    //--------------------------------------------------------------------------
    
    function int NextPatrolPt()
    {
    if (m_nPatrolPtCount < 2)
      return 0;
    m_nCurrentPatrolPt = (m_nCurrentPatrolPt + 1) % m_nPatrolPtCount;
    if (m_nCurrentPatrolPt == 0)
      {
      m_nNextPatrolGx = m_nPatrolPt1Gx;
      m_nNextPatrolGy = m_nPatrolPt1Gy;
      m_nNextPatrolLz = m_nPatrolPt1Lz;
      }
    else if (m_nCurrentPatrolPt == 1)
      {
      m_nNextPatrolGx = m_nPatrolPt2Gx;
      m_nNextPatrolGy = m_nPatrolPt2Gy;
      m_nNextPatrolLz = m_nPatrolPt2Lz;
      }
    else if (m_nCurrentPatrolPt == 2)
      {
      m_nNextPatrolGx = m_nPatrolPt3Gx;
      m_nNextPatrolGy = m_nPatrolPt3Gy;
      m_nNextPatrolLz = m_nPatrolPt3Lz;
      }
    else if (m_nCurrentPatrolPt == 3)
      {
      m_nNextPatrolGx = m_nPatrolPt4Gx;
      m_nNextPatrolGy = m_nPatrolPt4Gy;
      m_nNextPatrolLz = m_nPatrolPt4Lz;
      }
    else if (m_nCurrentPatrolPt == 4)
      {
      m_nNextPatrolGx = m_nPatrolPt5Gx;
      m_nNextPatrolGy = m_nPatrolPt5Gy;
      m_nNextPatrolLz = m_nPatrolPt5Lz;
      }
    else if (m_nCurrentPatrolPt == 5)
      {
      m_nNextPatrolGx = m_nPatrolPt6Gx;
      m_nNextPatrolGy = m_nPatrolPt6Gy;
      m_nNextPatrolLz = m_nPatrolPt6Lz;
      }
    else if (m_nCurrentPatrolPt == 6)
      {
      m_nNextPatrolGx = m_nPatrolPt7Gx;
      m_nNextPatrolGy = m_nPatrolPt7Gy;
      m_nNextPatrolLz = m_nPatrolPt7Lz;
      }
    else if (m_nCurrentPatrolPt == 7)
      {
      m_nNextPatrolGx = m_nPatrolPt8Gx;
      m_nNextPatrolGy = m_nPatrolPt8Gy;
      m_nNextPatrolLz = m_nPatrolPt8Lz;
      }
    else if (m_nCurrentPatrolPt == 8)
      {
      m_nNextPatrolGx = m_nPatrolPt9Gx;
      m_nNextPatrolGy = m_nPatrolPt9Gy;
      m_nNextPatrolLz = m_nPatrolPt9Lz;
      }
    else if (m_nCurrentPatrolPt == 9)
      {
      m_nNextPatrolGx = m_nPatrolPt10Gx;
      m_nNextPatrolGy = m_nPatrolPt10Gy;
      m_nNextPatrolLz = m_nPatrolPt10Lz;
      }
/*Trace>>>
    if (TraceMode (tmPatrol))
    	{
    	TraceD ("next patrol point #");
    	TraceD (m_nCurrentPatrolPt);
    	TraceD (" @");
    	TraceD (m_nNextPatrolGx);
    	TraceD (",");
    	TraceD (m_nNextPatrolGy);
    	TraceD ("\n");
    	}
<<<Trace*/  
    return 1;
    }
    
    //--------------------------------------------------------------------------
    function int GetEscortedUnit ()
    {
    if (!m_uEscorted || !m_uEscorted.IsLive() || IsEnemy (m_uEscorted))
    	{
    	while (m_nNumEscorted && !m_uEscorted)
    		{
		    m_uEscorted = m_uEscorted1;
	    	m_uEscorted1 = m_uEscorted2;
	    	m_uEscorted2 = m_uEscorted3;
	    	m_uEscorted3 = m_uEscorted4;
	    	m_uEscorted4 = m_uEscorted5;
	    	m_uEscorted5 = m_uEscorted6;
	    	m_uEscorted6 = m_uEscorted7;
	    	m_uEscorted7 = m_uEscorted8;
	    	--m_nNumEscorted;
	    	}
	    }
    return (m_uEscorted != null);
    if (!m_uEscorted)
    	return false;
   	m_nEscortedGx = m_uEscorted.GetLocationX();
	m_nEscortedGy = m_uEscorted.GetLocationY();
	return true;
    }
    
    //--------------------------------------------------------------------------
    
    function int HaveEscortedUnit (unit uEscorted)
    {
    if (m_nNumEscorted < 1)
    	return false;
    if (uEscorted == m_uEscorted1)
    	return true;
    if (m_nNumEscorted < 2)
    	return false;
    if (uEscorted == m_uEscorted2)
    	return true;
    if (m_nNumEscorted < 3)
    	return false;
    if (uEscorted == m_uEscorted3)
    	return true;
    if (m_nNumEscorted < 4)
    	return false;
    if (uEscorted == m_uEscorted4)
    	return true;
    if (m_nNumEscorted < 5)
    	return false;
    if (uEscorted == m_uEscorted5)
    	return true;
    if (m_nNumEscorted < 6)
    	return false;
    if (uEscorted == m_uEscorted6)
    	return true;
    if (m_nNumEscorted < 7)
    	return false;
    if (uEscorted == m_uEscorted7)
    	return true;
    if (m_nNumEscorted < 8)
    	return false;
    if (uEscorted == m_uEscorted8)
    	return true;
    return false;
    }
    
    //--------------------------------------------------------------------------
    
    function int AddEscortedUnit (unit uEscorted)
    {
    if ((m_nNumEscorted >= 8) || HaveEscortedUnit (uEscorted))
    	return 0;
    ++m_nNumEscorted;
    if (m_nNumEscorted == 1)
    	m_uEscorted1 = uEscorted;
    else if (m_nNumEscorted == 2)
    	m_uEscorted2 = uEscorted;
    else if (m_nNumEscorted == 3)
    	m_uEscorted3 = uEscorted;
    else if (m_nNumEscorted == 4)
    	m_uEscorted4 = uEscorted;
    else if (m_nNumEscorted == 5)
    	m_uEscorted5 = uEscorted;
    else if (m_nNumEscorted == 6)
    	m_uEscorted6 = uEscorted;
    else if (m_nNumEscorted == 7)
    	m_uEscorted7 = uEscorted;
    else if (m_nNumEscorted == 8)
    	m_uEscorted8 = uEscorted;
    GetEscortedUnit();
    return 1;
    }

    //--------------------------------------------------------------------------

    function int AddPatrolPt (int nNewPatrolPtX, int nNewPatrolPtY, int nNewPatrolPtZ)
    {
    if (m_nPatrolPtCount == m_nMaxPatrolPtCount)
      return 0;
    ++m_nPatrolPtCount;
    if (m_nPatrolPtCount < 2)
		{
		m_nPatrolPtCount = 2;
		m_nPatrolPt1Gx = GetLocationX();
		m_nPatrolPt1Gy = GetLocationY();
		m_nPatrolPt1Lz = GetLocationZ();
		m_nPatrolPt2Gx = nNewPatrolPtX;
		m_nPatrolPt2Gy = nNewPatrolPtY;
		m_nPatrolPt2Lz = nNewPatrolPtZ;
		m_nNextPatrolGx = m_nPatrolPt2Gx;
		m_nNextPatrolGy = m_nPatrolPt2Gy;
		m_nNextPatrolLz = m_nPatrolPt2Lz;
		m_nCurrentPatrolPt = 1;
/*Trace>>>
	    if (TraceMode (tmPatrol))
	    	{
	    	TraceD ("initial patrol point");
	    	TraceD (m_nPatrolPt1Gx);
	    	TraceD (",");
	    	TraceD (m_nPatrolPt1Gy);
	    	TraceD ("\n");
	    	}
<<<Trace*/  
		}
    else if (m_nPatrolPtCount == 3)
		{
		m_nPatrolPt3Gx = nNewPatrolPtX;
		m_nPatrolPt3Gy = nNewPatrolPtY;
		m_nPatrolPt3Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 4)
		{
		m_nPatrolPt4Gx = nNewPatrolPtX;
		m_nPatrolPt4Gy = nNewPatrolPtY;
		m_nPatrolPt4Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 5)
		{
		m_nPatrolPt5Gx = nNewPatrolPtX;
		m_nPatrolPt5Gy = nNewPatrolPtY;
		m_nPatrolPt5Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 6)
		{
		m_nPatrolPt6Gx = nNewPatrolPtX;
		m_nPatrolPt6Gy = nNewPatrolPtY;
		m_nPatrolPt6Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 7)
		{
		m_nPatrolPt7Gx = nNewPatrolPtX;
		m_nPatrolPt7Gy = nNewPatrolPtY;
		m_nPatrolPt7Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 8)
		{
		m_nPatrolPt8Gx = nNewPatrolPtX;
		m_nPatrolPt8Gy = nNewPatrolPtY;
		m_nPatrolPt8Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 9)
		{
		m_nPatrolPt9Gx = nNewPatrolPtX;
		m_nPatrolPt9Gy = nNewPatrolPtY;
		m_nPatrolPt9Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 10)
		{
		m_nPatrolPt10Gx = nNewPatrolPtX;
		m_nPatrolPt10Gy = nNewPatrolPtY;
		m_nPatrolPt10Lz = nNewPatrolPtZ;
		}
    return 1;
    }
    
    //------------------------------------------------------- 
	// new DM/271100
	// check if attacker uAttacker is valid attacker for target uTarget.
	// if no attacker or attacker destroyed or attacker captured or attacker disabled
	// return false.
	// Otherwise check distance between attacker and target (since there is no way
	// to retrieve gun range of attacker or information about attacker's current targets)
	// and use that to determine if uAttacker still attacks uTarget.
	// if uTarget is null, uTarget is current unit (like C++'s *this).
	
    function int IsValidAttacker (unit uAttacker, unit uTarget, int bCheckDistance)
    {
    	int		nTargetGx;
    	int		nTargetGy;
    	
    if ((uAttacker == null) || !uAttacker.IsLive() || !IsEnemy(uAttacker) || uAttacker.IsDisabled())
    	{
/*Trace>>>
    	if (TraceMode (tmEscort))
    		TraceD ("Escort: DEAD\n");
<<<Trace*/  
    	return false;
    	}
    if (bCheckDistance)
    	{
	    if (!uTarget)	// if(!<unit>) is accepted as boolean expression, but if(<unit>) yields an error
	    	{			//  message. must use if (!<unit != null) instead ... ts ...
		   	nTargetGx = GetLocationX();	
	   		nTargetGy = GetLocationY();
	    	}
	    else
	    	{
		   	nTargetGx = uTarget.GetLocationX();	
	   		nTargetGy = uTarget.GetLocationY();
	   		}
	   	if (Distance(m_nTargetGx,m_nTargetGy,uAttacker.GetLocationX(),uAttacker.GetLocationY()) > cAttackerMaxDist)
	   		{
/*Trace>>>
	    	if (TraceMode (tmEscort))
    			TraceD ("Escort: OUT\n");
<<<Trace*/  
			return false;
			}
		}
	return true;
    }
    
    //------------------------------------------------------- 
    
    function int GetAttackerEx(unit uTarget)
    {
    	unit	uAttacker;
    	int		bCheckDistance;
    	
    if (uTarget)
    	m_uAttacker = uTarget.GetAttacker();
    else
    	m_uAttacker = GetAttacker();
    if (uTarget)
    	bCheckDistance = 1;
    else
    	bCheckDistance = 0;
	if (!IsValidAttacker (m_uAttacker, uTarget, bCheckDistance) || (!uTarget && !IsTargetInCannonRange(-1,m_uAttacker)))
    	m_uAttacker = null;
    if (!m_uAttacker)
    	{
    	if (uTarget)
    		uTarget.ClearAttacker();
    	else
    		ClearAttacker();
    	return false;
    	}
/*Trace>>>
    if (TraceMode (tmEscort))
    	TraceD ("Escort: ACQUIRED.\n");
<<<Trace*/  
    return true;
    }
    
    //------------------------------------------------------- 
	// new DM/291100
	// Check whether an escort needs to switch its attack target.
	// Generally, escorts stick with a target once it is acquired until it is destroyed.
	// The escort should preferrably attack airplanes though since they pose a deadly threat
	// to ground units.
	// The following code first checks the escort's current attack target, then saves it
	// and acquires any potential new attack target with GetAttackerEx().
    function int TryForceNewAttacker (unit uTarget)
    {
    	unit	uOldAttacker;
    	
    if (!IsValidAttacker (m_uAttacker, uTarget, true))
    	m_uAttacker = null;		// discard current (old) attacker if not valid any more
    uOldAttacker = m_uAttacker;	// remember current attacker anyway (may be discarded here)
    GetAttackerEx (uTarget);	// get most recent attacker
    if (!m_uAttacker || (uOldAttacker == m_uAttacker) || ((uOldAttacker != null) && (!m_uAttacker.IsHelicopter() || uOldAttacker.IsHelicopter())))
    	{
/*Trace>>>
    	if (TraceMode (tmEscort))
    		{
	    	if (!m_uAttacker)
    			TraceD ("Escort: NONE\n");
	    	else if (uOldAttacker == m_uAttacker)
    			TraceD ("Escort: SAME\n");
    		else if ((uOldAttacker != null) && (!m_uAttacker.IsHelicopter() || uOldAttacker.IsHelicopter()))
    			TraceD ("Escort: KEEP\n");
    		else
    			TraceD ("Escort: ERROR!!!\n");
    		}
<<<Trace*/  
    	m_uAttacker = uOldAttacker;
	    return false;
	    }
/*Trace>>>
    if (TraceMode (tmEscort))
    	TraceD ("Escort: NEW.\n");
<<<Trace*/   
    return true;
    }
    //------------------------------------------------------- 
    function int GatherUnits ()
    {
    if ((m_nGatherGx >= 0) && ((GetLocationX() != m_nGatherGx) || (GetLocationY() != m_nGatherGy)))
    	{
		CallMoveToPoint (m_nGatherGx, m_nGatherGy, m_nGatherLz);
		return 1;
		}
	return 0;
	}

    //------------------------------------------------------- 
    function int ForceRetreat ()
    {
    	int nCurHP;
    	int nMaxHP;
    	
    if (retreatMode < rmHP66)
    	return false;
    nCurHP = GetHP();
    nMaxHP = GetMaxHP();
    if (retreatMode == rmHP25)
    	nCurHP = 4 * nCurHP;
    if (retreatMode == rmHP50)
    	nCurHP = 2 * nCurHP;
    else
    	nCurHP = (3 * nCurHP + 2) / 2;
    if (nCurHP > nMaxHP)
    	return false;
    m_nDamper = 0;
    if (m_nState != stIdle)
        SaveState ();
    if (m_nReturnToGx < 0)
        {
        m_nReturnToGx = GetLocationX();
        m_nReturnToGy = GetLocationX();
        }
    return true;
    }
    //********************************************************
    //************* S T A T E S ******************************
    //********************************************************
    
    
    //------------------------------------------------------- 
    
    state Idle
    {
        int bLand;
        
    if (!ForceRetreat ())
        bLand = 0;
    else if (!IsMoving() && (m_nGatherGx == GetLocationX()) && (m_nGatherGy == GetLocationY()))
        {
        bLand = 1;
        }
    else
        {
    	return Retreat;
    	}
    if (bLand)
        {
        if (IsOnGround ())
            return Idle;
        return Landing;
        }
    if ((m_nReturnToGx >= 0) && (m_nReturnToGy >= 0))   // return after repair
       	return RestoreState,5;
    if (movementMode == mmHoldPos)
    	return HoldPosition;
    if (CheckAmmo())
	    return MovingForGetSupply;
    FindBestTarget();
    if(!m_uTarget)
	    {
        SetTarget(GetAttacker());
        ClearAttacker();
	    }
    if (m_uTarget != null)
    	{
        StayAtCurPos ();
        m_nAttackPhase=apRally;
        return AutoAttacking;
    	}
    return Idle;
    }
    //----------------------------------------------------
    state HoldPosition
    {
    if(CheckAmmo())
    	return MovingForGetSupply;
    if(m_uTarget)
        { 
        if(!m_uTarget.IsLive() || !IsEnemy(m_uTarget))
            {
            StopCannonFire(-1);
            SetTarget(null);
            m_nAttackPhase=apRally;
            }
        else
            {
            if(TargetInRange())
                {
                CannonFireToTarget(-1, m_uTarget, -1);
                return HoldPosition;
                }
            else
                SetTarget(null);
            return HoldPosition,10;
            }
        }
    else
        {
        FindBestTarget();
        if(!m_uTarget)
            {
            SetTarget(GetAttacker());
            ClearAttacker();
            }
        }        
    return HoldPosition;
    }
    //----------------------------------------------------
    state AutoAttacking
    {
        int nDistance;
        
/*Trace>>>
    if (TraceMode (tmAttack))
       	TraceD("AutoAttacking\n");
<<<Trace*/   
        
    if(CheckAmmo())
      	return MovingForGetSupply;
        
        // pozostawaj w okolicach punktu
    nDistance = Distance(m_nStayGx,m_nStayGy,GetLocationX(),GetLocationY());
    if( nDistance > 18)
    	{
/*Trace>>>
	    if (TraceMode (tmAttack))
    	    TraceD("nDistance: > 12 !!!!! \n  ");
<<<Trace*/   
        SetTarget(null);
        m_nAttackPhase=apRally;
        CallMoveToPoint(m_nStayGx, m_nStayGy, m_nStayLz);
        return Moving;          
    	}
    
    if(!m_uTarget.IsLive() || !IsEnemy(m_uTarget))
	    {
        StopCannonFire(-1);
        SetTarget(null);
        m_nAttackPhase=apRally;
    	}
    
    if (m_uTarget)
    	{
    	SetAttackMode (m_uTarget);
        m_nTargetGx = m_uTarget.GetLocationX();
        m_nTargetGy = m_uTarget.GetLocationY();
        if(AttackRun(0))
	        {
/*Trace>>>
	    	if (TraceMode (tmAttack))
            	TraceD("AutoAttack: Fire!!! \n");
<<<Trace*/   
    	    CannonFireToTarget(-1, m_uTarget, 2);
        	}
        return AutoAttacking;
	    }
    else//target not exist
    	{
        FindBestTarget();
        if(!m_uTarget)
        	{
            SetTarget(GetAttacker());
            ClearAttacker();
        	}
        if (m_uTarget != null)
            return AutoAttacking;
        if( nDistance > 0)
	        {
            CallMoveToPoint(m_nStayGx, m_nStayGy, m_nStayLz);
            return Moving;          
    	    }
        if (IsMoving())
            CallStopMoving();
        GatherUnits ();
        return Idle;
        }
    }
    //--------------------------------------------------------------------------
    state AttackingPoint
    {
/*Trace>>>
    if (TraceMode (tmAttack))
       	TraceD("Attacking Point\n");
<<<Trace*/   
	if(CheckAmmo())
		return MovingForGetSupply;
    if(AttackRun(1))
    	{
/*Trace>>>
    	if (TraceMode (tmAttack))
    		TraceD ("AttackingPoint: Fire!!! \n");
<<<Trace*/   
        CannonFireGround(-1, m_nTargetGx, m_nTargetGy, 0, 2);
        }
    return AttackingPoint;
    }
    //----------------------------------------------------
    state Attacking
    {
/*Trace>>>
    if (TraceMode (tmAttack))
       	TraceD("Attacking\n");
<<<Trace*/   
    if(CheckAmmo())
    	return MovingForGetSupply;
    if (m_uTarget.IsLive())
        {
        m_nTargetGx = m_uTarget.GetLocationX();
        m_nTargetGy = m_uTarget.GetLocationY();
        if(AttackRun(0))
        	{
/*Trace>>>
        	if (TraceMode (tmAttack))
        		TraceD ("Attacking: Fire!!! \n");
<<<Trace*/   
            CannonFireToTarget(-1, m_uTarget, 2);
            }
        return Attacking;
        }
    else //target does not exist
        {
        SetTarget(null);
        m_nAttackPhase=apRally;
        if (IsMoving())
            {
            CallStopMoving();
            }
        EndState();
        return Idle;
        }
    }
    //--------------------------------------------------------------------------
    state StartMoving
    {
        return Moving, 20;
    }
    //--------------------------------------------------------------------------
    state Moving
    {
    if (IsMoving())
        return Moving;
   	EndState(); 
    return Idle;
    }
    //--------------------------------------------------------------------------
    state StartLanding
    {
        return Landing, 20;
    }
    //--------------------------------------------------------------------------
    state Landing
    {
    if (IsMoving())
        {
        if ((GetLocationX() == m_nStayGx) && (GetLocationY() == m_nStayGy) && (GetLocationZ() == m_nStayLz) && 
            !IsFreePoint(m_nStayGx, m_nStayGy, m_nStayLz))
            {
            if (!Land())
                {
                NextCommand(1);
                return Idle;
                }
            }
        return Landing;
        }
    else
        {
        if (!Land())
            {
            NextCommand(1);
            return Idle;
            }
        return Landing;
        }
    }
    //------------------------------------------------------- 
    state Retreat
    {
    	int		nAttackerGx;
    	int		nAttackerGy;
    	unit	uAttacker;
    	
    if(IsAllowingWithdraw())
    	AllowScriptWithdraw(true);
    if(!m_nDamper)
    	{
        SetTargetObject(null);
        uAttacker = FindClosestEnemy();
        m_nDamper = 1;
    	}
    else
    	{
        if(IsMoving())
            m_nDamper = (m_nDamper + 1) % cMaxDamper;
        else
            m_nDamper = 0;
    	}
    if(!uAttacker)
        SetTargetObject(null);
    if (GatherUnits())
    	if (IsMoving ())
    		return Moving;
    	else
	    	return StartMoving;
	if (!uAttacker)
		{
		if (IsMoving())
			CallStopMoving();
		return Idle;
		}
	m_nRetreatGx = GetLocationX();
	m_nRetreatGy = GetLocationY();
	nAttackerGx = uAttacker.GetLocationX();
	nAttackerGy = uAttacker.GetLocationY();
	if (m_nRetreatGx <= nAttackerGx)
		m_nRetreatGx = nAttackerGx - (cAttackerMaxDist + 1);
	else
		m_nRetreatGy = nAttackerGy + (cAttackerMaxDist + 1);
	if (m_nRetreatGy <= nAttackerGy)
		m_nRetreatGy = nAttackerGy - (cAttackerMaxDist + 1);
	else
		m_nRetreatGy = nAttackerGy + (cAttackerMaxDist + 1);
	if ((GetLocationX() != m_nRetreatGx) || (GetLocationY() != m_nRetreatGy))
		{
    	CallMoveToPoint(m_nRetreatGx, m_nRetreatGy, GetLocationZ());
    	return Retreat;
    	}
    m_nRetreatGx = -1;	// done retreating
    return Idle;
    }
    
    //--------------------------------------------------------------------------
	// new DM/231100
	state BeginPatrol
	{
    if (m_nPatrolPtCount < 2)
    	return Idle;
    CallMoveToPoint(m_nNextPatrolGx, m_nNextPatrolGy, m_nNextPatrolLz);
    return Patrol;
	}
    //--------------------------------------------------------------------------
    state Patrol
    {
    if(CheckAmmo())
    	{
    	return MovingForGetSupply;
    	}
    if(m_uTarget)
  		{
        if(!m_uTarget.IsLive() || !IsEnemy(m_uTarget))
    	    {
            StopCannonFire(-1);
            SetTarget(null);
            m_nAttackPhase=apRally;
    	    }
        else
    	    {
            m_nTargetGx = m_uTarget.GetLocationX();
            m_nTargetGy = m_uTarget.GetLocationY();
            if(AttackRun(0))
                CannonFireToTarget(-1, m_uTarget, -1);
            return Patrol;
    	    }
    	}
    else
    	{
        FindBestTarget();
    	}   
    
    if (!IsMoving())
    	{
    	if (!NextPatrolPt())
    		{
    		NextCommand (1);
    		return Idle;
    		}
       	CallMoveToPoint(m_nNextPatrolGx, m_nNextPatrolGy, m_nNextPatrolLz);
    	}
    return Patrol;
    }
    //--------------------------------------------------------------------------
    //modified DM/241100
    //changes escort behaviour as follows:
    //primarily attack attacker of escorted unit
    //if no attacker, find another target
    //if other target found, attack only if in range
    state Escort
    {
    	int	 nTgtDist;
    	int	 nEscortGx;
    	int  nEscortGy;
    	int  nEscortLz;
    	int  nDx;
    	int  nDy;
    	int	 nGunRange;
    	int	 nMaxSteps;
    	
    if(CheckAmmo())
    	{
/*Trace>>>
	    if (TraceMode (tmEscort))
    		TraceD("Escort: MovingForGetSupply\n");
<<<Trace*/   
    	return MovingForGetSupply;
    	}
    	
    // check escorted unit's state
   	GetEscortedUnit();
    if (!m_uEscorted)
    	{
/*Trace>>>
	    if (TraceMode (tmEscort))
    		TraceD("Escort: no escorted unit available\n");
<<<Trace*/   
    	m_uAttacker = null;
        if(IsMoving())
            CallStopMoving;
        EndState();
    	return Idle;
    	}
    	
    // check escorted unit's attacker with escort's current target
    TryForceNewAttacker (m_uEscorted);
/*Trace>>>
    if (TraceMode (tmEscort))
    	{
    	if (!m_uAttacker)
    		TraceD ("Escort: VOID.\n");
    	}
<<<Trace*/   
    if (!m_uTarget || ((m_uAttacker != null) && (m_uTarget != m_uAttacker)))
    	{
        StopCannonFire(-1);
        ResetAttack(null);
        }
    if (m_uAttacker)
    	m_uTarget = m_uAttacker;
    else if (!m_uTarget)
        FindBestTarget();
	SetTarget (m_uTarget);
	        
	m_nEscortedGx = m_uEscorted.GetLocationX();    
	m_nEscortedGy = m_uEscorted.GetLocationY();    
	nEscortGx = GetLocationX();    
	nEscortGy = GetLocationY();    
    // check distance to target
    if (m_uTarget)
    	{
    	if (m_uAttacker)	// attack regardless of distance
    		{
/*Trace>>>
		    if (TraceMode (tmEscort))
    			TraceD("\nEscort: FORCE\n");
<<<Trace*/   
    		nTgtDist = 0;
    		nGunRange = 1;
    		}
    	else	// attack only if in range
    		{
    	    m_nTargetGx = m_uTarget.GetLocationX();
	        m_nTargetGy = m_uTarget.GetLocationY();
			nTgtDist = Distance (m_nEscortedGx, m_nEscortedGy, nEscortGx, nEscortGy);
			nGunRange = GetGunRange () % 65536;
/*Trace>>>
		    if (TraceMode (tmEscort))
				{
    			TraceD ("\nEscort: COND ");
    			TraceD (nTgtDist);
    			TraceD (", rng=");
    			TraceD (nGunRange);
    			TraceD (" \n");
    			}
<<<Trace*/   
			}
        if (nTgtDist < nGunRange * 2)
        	{
/*Trace>>>
		    if (TraceMode (tmEscort))
    			TraceD("\nEscort: ACCEPT\n");
<<<Trace*/   
    		SetAttackMode (m_uTarget);
        	if (AttackRun (0))
        		{
/*Trace>>>
        		if (TraceMode (tmEscort))
        			TraceD ("\nEscort: ATTACK!!!\n");
<<<Trace*/   
           		CannonFireToTarget(-1, m_uTarget, -1);
           		}
            return Escort;
            }
        SetTarget (null);	// target too far away
        m_uTarget = null;
    	}

/*Trace>>>
    if (TraceMode (tmEscort))
		TraceD("Escort: STAY\n");
<<<Trace*/   
	nEscortLz = GetLocationZ();    
    if (nEscortGx < m_nEscortedGx - 1)
    	nEscortGx = m_nEscortedGx - 1;
    else if (nEscortGx > m_nEscortedGx + 1)
    	nEscortGx = m_nEscortedGx + 1;
   	else
   		nDx = 0;
    if (nEscortGy < m_nEscortedGy - 1)
    	nEscortGy = m_nEscortedGy - 1;
    else if (nEscortGy > m_nEscortedGy + 1)
    	nEscortGy = m_nEscortedGy + 1;
   	else
   		nDy = 0;
   	if ((nEscortGx != m_nEscortedGx) || (nEscortGy != m_nEscortedGy))
   		{
/*Trace>>>
    	if (TraceMode (tmEscort))
			TraceD("Escort: UPDATE\n");
<<<Trace*/   
        CallMoveToPoint(nEscortGx, nEscortGy, m_uEscorted.GetLocationZ());
        }
    else if(IsMoving())
        CallStopMoving();
    return Escort;
    }
    
    //------------------------------------------------------- 
    state Frozen
    {
        if (IsFroozen())
        {
            state Frozen;
        }
        else
        {
            //!!wrocic do tego co robilismy
            state Idle;
        }
    }
    
    //------------------------------------------------------- 
    //for aircraft
    state MovingForGetSupply
    {
    if (IsMoving())
    	{
        if ((GetLocationX() == m_nStayGx) && (GetLocationY() == m_nStayGy) && (GetLocationZ() == m_nStayLz))
        	{
            CallStopMoving();
            return MovingForGetSupply,5;
            }
        return MovingForGetSupply;
    	}
    else
    	{
        if ((GetLocationX() == m_nStayGx) && (GetLocationY() == m_nStayGy) && (GetLocationZ() == m_nStayLz))
        	{
            CallGetFlyingSupply();
            return GettingSupply;
        	}
        else
        	{
            //CallMoveAndLandToPointForce(m_nStayGx, m_nStayGy, m_nStayLz);
            CallMoveToPointForce(m_nStayGx, m_nStayGy, m_nStayLz);//dodane 25.01.2000
            return MovingForGetSupply;
        	}
    	}
    }
    
    //------------------------------------------------------- 
    state GettingSupply
    {
    if (IsGettingSupply())
        {
        return GettingSupply,5;
        }
    else
        {
        m_bNeedReload=false;
        if(m_nEscortedGx==GetLocationX() && m_nEscortedGy==GetLocationY())
        	m_nEscortedGx=m_nEscortedGx+5;
        if(!GetAmmoCount())
        	{
            m_nEscortedGx=GetLocationX()-5; 
            m_nEscortedGy=GetLocationY();
            }
        if(!m_nEscortedGx)
        	{
        	m_nEscortedGx=GetLocationX()+5;
        	m_nEscortedGy=GetLocationY();
        	}
        CallMoveToPoint(m_nEscortedGx,m_nEscortedGy,0);
        return MovingAfterReload;
        }
    }
    //-------------------------------------------------------
    // new DM/231100
    state RestoreState
    {
        int nState;
        
    if ((m_nReturnToGx >= 0) && (m_nReturnToGy >= 0))
    	{
    	CallMoveToPoint (m_nReturnToGx, m_nReturnToGy, GetLocationZ ());
    	m_nReturnToGx = -1;
   	    return RestoreState,2;
    	}
  	if (IsMoving ())
   	    return RestoreState,2;
    if (m_nState != stIdle)
        {
        nState = m_nState;
        m_nState = stIdle;
        if (nState == stAttackPoint)
        	return AttackingPoint,5;
        if (nState == stAttack)
        	return Attacking,5;
        if (nState == stMove)
          	return Moving;
        if (nState == stPatrol)
        	return Patrol,5;
        if (nState == stEscort)
        	return Escort,5;
        }
    EndState ();
    return Idle;
    }
    //--------------------------------------------------------------------------
    state MovingAfterReload
    {
    if (IsMoving())
        return MovingAfterReload;
    else
        return RestoreState;
    }
    //********************************************************
    //*********** E V E N T S ****************************
    //********************************************************
    //zwracaja true
    //false jak nie ma 
    event OnHit()
    {
    	unit uAttacker;
    	
    uAttacker = GetAttacker();
    if (!m_uTarget)
       	SetTarget(uAttacker);
    else if (m_uTarget != uAttacker)
    	{
        if (uAttacker.IsHelicopter() && !m_uTarget.IsHelicopter() && CanCannonFireToAircraft(-1))
        	SetTarget(uAttacker);
        else 
        	{
        	if (!FindBestTarget())
	        	SetTarget(uAttacker);
	        }
    	}
    if (m_uTarget)
     	CannonFireToTarget(-2, m_uTarget, -1);
    if (ForceRetreat ())
        state Retreat;
    true;
    }
    //------------------------------------------------------- 
    event OnCannonLowAmmo(int nCannonNum)
    {
        true;
    }
    //------------------------------------------------------- 
    event OnCannonNoAmmo(int nCannonNum)
    {
        m_bNeedReload=true;
        if(CheckAmmo())
        	state MovingForGetSupply;
        true;
    }
    //------------------------------------------------------- 
    event OnCannonFoundTarget(int nCannonNum, unit uTarget)
    {
        return false;//gdyby zwrocic true to dzialko nie strzeli
    }
    //------------------------------------------------------- 
    event OnCannonEndFire(int nCannonNum, int nEndStatus)//gdy zniszczony, poza zasiegiem lub brak ammunicji
    {
        false;
    }
    //------------------------------------------------------- 
    event OnFreezeForSupplyOrRepair(int nFreezeTicks)
    {
        CallFreeze(nFreezeTicks);
        state Frozen;
        true;
    }
    //------------------------------------------------------- 
    event OnTransportedToNewWorld()
    {
        StopCannonFire(-1);
        SetTarget(null);
        m_uEscorted = null;
    }
    //------------------------------------------------------- 
    event OnConvertedToNewPlayer()
    {
        StopCannonFire(-1);
        SetTarget(null);
        m_uEscorted = null;
        state Idle;
    }
    
    //********************************************************
    //*********** C O M M A N D S ****************************
    //********************************************************
    command Initialize()
	{
/*Trace>>>
    eTraceMode = 0;
<<<Trace*/
   	retreatMode = rmHP50;
    ResetPatrol ();
    movementMode=mmHoldPos;
    attackDistance = adCautious;
    SetCannonFireMode(-1, disableFire);
    m_nAttackGx = -1;
    m_nGatherGx = -1;
    m_bIncToggle = 0;
    if(!GetAmmoCount()) 
    	m_bNeedReload=true;
    else 
       m_bNeedReload=false;
	m_nDamper = 0;
    ResetState (stIdle, null);
    }
    //--------------------------------------------------------------------------
    command Uninitialize()
    {
        //wykasowac referencje
        SetTarget(null);
        m_uEscorted = null;
    }
    //--------------------------------------------------------------------------
    command SetLights(int nMode) button lights description "translateCommandStateLightsModeDescription" hotkey priority 204
    {
        if (nMode == -1)
        {
            lights = (lights + 1) % 3;
        }
        else
        {
            assert(nMode == 0);
            lights = nMode;
        }
        SetLightsMode(lights);
        NextCommand(0);
    }
    //--------------------------------------------------------------------------
    command SetMovementMode(int nMode) button movementMode description "translateCommandStateMovementDescription" priority 205
    {
    if (nMode == -1)
        movementMode = (movementMode + 1) % mmCount;
    else
        {
        assert(nMode == 0);
        movementMode = nMode % mmCount;
    	}
    NextCommand(0);
    }
    //--------------------------------------------------------------------------
    command SetAttackMode(int nMode) button attackMode description "translateCommandStateAttackModeDescription" priority 206
    {
    if (nMode == -1)
		attackMode = (attackMode + 1) % 2;
    else
        {
        assert(nMode == 0);
        attackMode = nMode;
        }
    NextCommand(0);
    }
    
    //--------------------------------------------------------------------------
    command Stop() button "translateCommandStop" description "translateCommandStopDescription" hotkey priority 20
    {
    ResetState (stIdle, null);
    if(state==GettingSupply)
        return;
    StayAtCurPos ();
    if(IsMoving())
        CallStopMoving();
    state Idle;
    }
    //--------------------------------------------------------------------------
    command HoldPosition() hidden button "translateCommandHoldPosition" description "translateCommandHoldPositionDescription" hotkey priority 20
    {
    ResetState (stIdle, null);
    if(state==GettingSupply && IsOnWorkingSupplyCenter())
        return;
    StayAtCurPos ();
    movementMode = mmHoldPos;
    if(IsMoving())
    	CallStopMoving();
    ChangedCommandValue();
    state HoldPosition;
    }
    
    //--------------------------------------------------------------------------
    command Move(int nGx, int nGy, int nLz) button "translateCommandMove" description "translateCommandMoveDescription" hotkey priority 21
    {
    ResetState (stMove, null);
    m_nStayGx = nGx;
    m_nStayGy = nGy;
    m_nStayLz = nLz;
    if (m_nGatherGx < 0)
    	{
	    m_nGatherGx = nGx;
	    m_nGatherGy = nGy;
	    m_nGatherLz = nLz;
	    }
    m_nState = 3;
    if (state==GettingSupply && IsOnWorkingSupplyCenter())
        return;
    CallMoveToPoint(nGx, nGy, nLz);
    state StartMoving;
    }
    //--------------------------------------------------------------------------
    command Attack(unit uTarget) button "translateCommandAttack" description "translateCommandAttackDescription" hotkey priority 22
    {
    ResetState (stAttack, uTarget);
    if(state==GettingSupply && IsOnWorkingSupplyCenter())
    	return;
    state Attacking;
    }
    
    //--------------------------------------------------------------------------
    command AttackOnPoint(int nX, int nY, int nZ) hidden button "translateCommandAttack" 
    {
    ResetState (stAttackPoint, null);
    m_nTargetGx = nX;
    m_nTargetGy = nY;
    m_nTargetLz = nZ;
    m_nAttackPhase = apRally;
    if(state==GettingSupply && IsOnWorkingSupplyCenter())
        return;
    state AttackingPoint;
    }
    
    //--------------------------------------------------------------------------
    command Patrol(int nGx, int nGy, int nLz) button "translateCommandPatrol" description "translateCommandPatrolDescription" hotkey priority 27
    {
    AddPatrolPt (nGx, nGy, nLz);
    ResetState (stPatrol, null);
    if(state==GettingSupply)
    	return;
    state BeginPatrol;
    }
    
    //--------------------------------------------------------------------------
    command UserNoParam0() button "translateCommandResetPatrol" description "translateCommandResetPatrolDescription" hotkey priority 28
    {
    ResetPatrol ();
    ResetState (stIdle, null);
    NextCommand (0);
    }
    
    //--------------------------------------------------------------------------
    command UserNoParam1() button "translateCommandRestartPatrol" description "translateCommandRestartPatrolDescription" hotkey priority 29
    {
    ResetState (stPatrol, null);
    if(state==GettingSupply)
    	return;
    state BeginPatrol;
    }
    
	//--------------------------------------------------------------------------
	command Escort(unit uUnit) button "translateCommandEscort" description "translateCommandEscortDescription" hotkey priority 31 
	{
    ResetState (stEscort, null);
	AddEscortedUnit (uUnit);
	if(state==GettingSupply)
		return;
	state Escort;
	}
    
    //--------------------------------------------------------------------------
    command Enter(unit uEntrance) hidden button "translateCommandEnter"
    {
    if(state==GettingSupply && IsOnWorkingSupplyCenter())
        return;
    CallMoveInsideObject(uEntrance);
    ResetState (stIdle, null);
    m_nTargetGx = GetEntranceX(uEntrance);
    m_nTargetGy = GetEntranceY(uEntrance);
    m_nTargetLz = GetEntranceZ(uEntrance);
    state StartMoving;
    }
    
    
	//--------------------------------------------------------------------------
    //for flyables
    command Land() button "translateCommandLand" description "translateCommandLandDescription" hotkey priority 31 
    {
    if(state==GettingSupply && IsOnWorkingSupplyCenter())
    	return;
    ResetState (stIdle, null);
    m_nLandCounter = 1;
    if (Land())
        {
        state StartLanding;
        }
    else
        {
        NextCommand(1);
        }
     }
    
	//--------------------------------------------------------------------------
    command FlyForSupply() button "translateCommandGetSupply" description "translateCommandGetSupplyDescription" hotkey priority 50 
    {
    if(state==GettingSupply && IsOnWorkingSupplyCenter())
    	return;
    ResetState (stIdle, m_uTarget);
    if (HaveCannonsMissingAmmo())
        {
        if (FindSupplyCenterPlace())
            {
            m_nEscortedGx = GetLocationX(); 
            m_nEscortedGy = GetLocationY();
            
            m_nStayGx = GetFoundSupplyCenterPlaceX();
            m_nStayGy = GetFoundSupplyCenterPlaceY();
            m_nStayLz = GetFoundSupplyCenterPlaceZ();
            //CallMoveAndLandToPointForce(m_nStayGx, m_nStayGy, m_nStayLz);//jak bylo Force to stawaly w slupku
                            CallMoveToPointForce(m_nStayGx, m_nStayGy, m_nStayLz);//dodane 25.01.2000
            state MovingForGetSupply;
            }
        else
            {
            NextCommand(0);
            }
        }
    else
        {
        NextCommand(0);
        }
    }
    //--------------------------------------------------------------------------
    command UserOneParam2(int nMode) button retreatMode description "translateCommandStateRetreatModeDescription" priority 51
    {
    if (nMode == -1)
        retreatMode = (retreatMode + 1) % rmNum;
    else
        {
        assert(nMode == 0);
        retreatMode = nMode;
        }
    }
    
    //--------------------------------------------------------------------------
    command UserOneParam3(int nMode) button attackDistance description "translateCommandStateAttackDistance" priority 207
    {
    if (nMode == -1)
        attackDistance = (attackDistance + 1) % adNum;
    else
        attackDistance = nMode % adNum;
    }
    
     //--------------------------------------------------------------------------
    command UserPoint9(int nGx, int nGy, int nLz) button "translateCommandSetGatherPoint" description "translateCommandSetGatherPointDescription" hotkey priority 52
    {
    m_nRetreatGx = -1;
    m_nGatherGx = nGx;
    m_nGatherGy = nGy;
    m_nGatherLz = nLz;
    NextCommand (1);
    }
    
    //--------------------------------------------------------------------------
    command UserNoParam2() button "translateCommandRetreat" description "translateCommandRetreatDescription" hotkey priority 52
    {
    m_nDamper = 0;
   	state Retreat;
    }
    
  //-------------------------------------------------------
    command SpecialChangeUnitsScript() button "translateCommandChangeScript" description "translateCommandChangeScriptDescription" hotkey priority 254 
    {
        //special command - no implementation
    }
     //--------------------------------------------------------------------------
	// toggle trace mode
/*Trace>>>
	command UserOneParam9(int nMode) button eTraceMode description "translateCommandExtTraceModeDescription" priority 255
    {
   	if (nMode == -1)
    	{
    	eTraceMode = (eTraceMode + 1) % tmNum;
    	}
    else
    	{
    	assert(nMode == 0);
    	eTraceMode = nMode % tmNum;
    	}
    TraceD ("trace mode is ");
    if (eTraceMode == tmAll)
    	TraceD ("ALL");
    else if (eTraceMode == tmPatrol)
    	TraceD ("PATROL");
    else if (eTraceMode == tmEscort)
    	TraceD ("ESCORT");
    else if (eTraceMode == tmAttack)
    	TraceD ("ATTACK");
    else
    	TraceD ("OFF");
    TraceD (" \n");
    }
<<<Trace*/   
   //--------------------------------------------------------------------------
    /*
    button "Attack"
    description "euhwfduihewuif"
    hotkey   // flaga ze ma reagowac na klawisz do tej komendy
    priority 7 
    */
}
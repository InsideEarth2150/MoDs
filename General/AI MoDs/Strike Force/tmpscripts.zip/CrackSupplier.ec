// changes by Dietfrid Mali (Diedel) 23 nov 2000
// Auto-assign to nearest supply facility
// Script name: "Versorger (Elite)"
// renamed state Nothing to state Idle

supplier "translateScriptNameCrackSupplyTransporterv13"
{

consts
	{
	// retreat modes        
    rmNone = 0;
    rmHP66 = 1;
    rmHP50 = 2;
    rmHP25 = 3;
    rmNum = 4;
    
    // states
    stIdle = 0;
    stMove = 1;
    stEscort = 2;
    stRetreat = 3;

    cAttackerMaxDist = 15;
    cMaxDamper = 4;
	}
	
    enum retreatMode
    {
        "translateCommandStateNoRetreat",
        "translateCommandStateRetreatHP66",
        "translateCommandStateRetreatHP50",
        "translateCommandStateRetreatHP25",
multi:
        "translateCommandStateRetreatMode"
    }
    
    enum lights
    {
        "translateCommandStateLightsAUTO",
        "translateCommandStateLightsON",
        "translateCommandStateLightsOFF",
multi:
        "translateCommandStateLightsMode"
    }
    
    enum traceMode
    {
        "translateCommandStateTraceOFF",
        "translateCommandStateTraceON",
multi:
        "translateCommandStateTraceMode"
    }
    int m_nMoveToX;
    int m_nMoveToY;
    int m_nMoveToZ;
    int m_nTargetGx;
    int m_nTargetGy;
    int m_nTargetLz;
    int m_nLandCounter;
    
    int  m_nEscortedGx; //Patrol point , escort
    int  m_nEscortedGy;
    int  m_nEscortedLz;
    unit m_uEscorted;
    unit m_uEscorted1;
    unit m_uEscorted2;
    unit m_uEscorted3;
    unit m_uEscorted4;
    unit m_uEscorted5;
    unit m_uEscorted6;
    unit m_uEscorted7;
    unit m_uEscorted8;
    int	 m_nCurEscorted;
    int  m_nNumEscorted;

    unit m_uSupplyCenter;
    
    int	 m_nGatherGx;
    int	 m_nGatherGy;
    int	 m_nGatherLz;
    
    int	 m_nRetreatGx;
    int	 m_nRetreatGy;
    int  m_nDamper;
    
    int  m_nReturnToGx;
    int  m_nReturnToGy;
    
    int  m_nState;
    
    //------------------------------------------------------- 
    state Initialize;
    state Idle;
    state RestoreState;
    state StartMoving;
    state Moving;
    state StartLanding;
    state Landing;
    state MovingToAssemblyPoint;
    state MovingToSupplyCenter;
    state MovingToObjectForSupply;
    state LoadingAmmo;
    state PuttingAmmo;
    state Escort;
	state Retreat;
    
    //--------------------------------------------------------------------------
    
    function int ResetEscort()
    {
    m_uEscorted = null;
    m_nCurEscorted = 0;
    m_nNumEscorted = 0;
    return 1;
    }
    
    //-------------------------------------------------------
    // new DM/231100
    function int ResetState (int nNewState)
    {
    m_nReturnToGx = -1;
    if (nNewState != stEscort)
        ResetEscort ();
    m_nState = nNewState;
    }
    //-------------------------------------------------------
    // new DM/231100
    function int SaveState ()
    {
    if(state==Moving)
        m_nState = stMove;
    else if(state==Escort)
        m_nState = stEscort;
    else
    	m_nState = stIdle;
    return m_nState;
    }
    //------------------------------------------------------- 
    function int ForceRetreat ()
    {
    	int nCurHP;
    	int nMaxHP;
    	
    if ((state == MovingToAssemblyPoint) || (state == MovingToSupplyCenter))
        return false;
    if (retreatMode < rmHP66)
    	return false;
    nCurHP = GetHP();
    nMaxHP = GetMaxHP();
    if (retreatMode == rmHP25)
    	nCurHP = 4 * nCurHP;
    else if (retreatMode == rmHP50)
    	nCurHP = 2 * nCurHP;
    else
    	nCurHP = (3 * nCurHP + 2) / 2;
    if (nCurHP > nMaxHP)
    	return false;
    m_nDamper = 0;
    if (m_nState != stIdle)
        SaveState;
    return true;
    }
    //------------------------------------------------------- 
    function int GatherUnits ()
    {
    if ((m_nGatherGx >= 0) && ((GetLocationX() != m_nGatherGx) || (GetLocationY() != m_nGatherGy)))
    	{
		CallMoveToPoint (m_nGatherGx, m_nGatherGy, m_nGatherLz);
		return 1;
		}
	return 0;
	}

    //------------------------------------------------------- 
    function int Land()
    {
        if (!IsOnGround())
        {
            m_nMoveToX = GetLocationX();
            m_nMoveToY = GetLocationY();
            m_nMoveToZ = GetLocationZ();
            if (!IsFreePoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ))
            {
                if (Rand(2))
                {
                    m_nMoveToX = m_nMoveToX + (Rand(m_nLandCounter) + 1);
                }
                else
                {
                    m_nMoveToX = m_nMoveToX - (Rand(m_nLandCounter) + 1);
                }
                if (Rand(2))
                {
                    m_nMoveToY = m_nMoveToY + (Rand(m_nLandCounter) + 1);
                }
                else
                {
                    m_nMoveToY = m_nMoveToY - (Rand(m_nLandCounter) + 1);
                }
                m_nLandCounter = m_nLandCounter + 1;
                if (IsFreePoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ))
                {
                    CallMoveAndLandToPoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                }
                else
                {
                    CallMoveLowToPoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                }
            }
            else
            {
                CallMoveAndLandToPoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
            }
            return true;
        }
        else
        {
            return false;
        }
    }
    //-------------------------------------------------------
    // new DM/231100
    function int AssignToSupplyCenter ()
    {
	//if (!GetPlayer (GetIFFNumber ()).GetNumberOfBuildings (buildingSupplyCenter))
    // 	return Idle;
    if (m_uSupplyCenter.IsLive() && !m_uSupplyCenter.IsDisabled())
    	return false;
	m_uSupplyCenter = FindSupplyCenter ();
    if (!m_uSupplyCenter)
    	return false;
    SetSupplyCenterBuilding (m_uSupplyCenter);
    m_nMoveToX = GetSupplyCenterAssemblyPositionX();
    m_nMoveToY = GetSupplyCenterAssemblyPositionY();
    m_nMoveToZ = GetSupplyCenterAssemblyPositionZ();
    return true;
    }
    //-------------------------------------------------------
    function int EndState()
    {
        NextCommand(1);
    }
    //--------------------------------------------------------------------------
    function int GetEscortedUnit ()
    {
    if (!m_uEscorted || !m_uEscorted.IsLive() || IsEnemy (m_uEscorted))
    	{
    	while (m_nNumEscorted && !m_uEscorted)
    		{
		    m_uEscorted = m_uEscorted1;
	    	m_uEscorted1 = m_uEscorted2;
	    	m_uEscorted2 = m_uEscorted3;
	    	m_uEscorted3 = m_uEscorted4;
	    	m_uEscorted4 = m_uEscorted5;
	    	m_uEscorted5 = m_uEscorted6;
	    	m_uEscorted6 = m_uEscorted7;
	    	m_uEscorted7 = m_uEscorted8;
	    	--m_nNumEscorted;
	    	}
	    }
    return (m_uEscorted != null);
    if (!m_uEscorted)
    	return false;
   	m_nEscortedGx = m_uEscorted.GetLocationX();
	m_nEscortedGy = m_uEscorted.GetLocationY();
	return true;
    }
    
    //--------------------------------------------------------------------------
    
    function int HaveEscortedUnit (unit uEscorted)
    {
    if (m_nNumEscorted < 1)
    	return false;
    if (uEscorted == m_uEscorted1)
    	return true;
    if (m_nNumEscorted < 2)
    	return false;
    if (uEscorted == m_uEscorted2)
    	return true;
    if (m_nNumEscorted < 3)
    	return false;
    if (uEscorted == m_uEscorted3)
    	return true;
    if (m_nNumEscorted < 4)
    	return false;
    if (uEscorted == m_uEscorted4)
    	return true;
    if (m_nNumEscorted < 5)
    	return false;
    if (uEscorted == m_uEscorted5)
    	return true;
    if (m_nNumEscorted < 6)
    	return false;
    if (uEscorted == m_uEscorted6)
    	return true;
    if (m_nNumEscorted < 7)
    	return false;
    if (uEscorted == m_uEscorted7)
    	return true;
    if (m_nNumEscorted < 8)
    	return false;
    if (uEscorted == m_uEscorted8)
    	return true;
    return false;
    }
    
    //--------------------------------------------------------------------------
    
    function int AddEscortedUnit (unit uEscorted)
    {
    if ((m_nNumEscorted >= 8) || HaveEscortedUnit (uEscorted))
    	return 0;
    ++m_nNumEscorted;
    if (m_nNumEscorted == 1)
    	m_uEscorted1 = uEscorted;
    else if (m_nNumEscorted == 2)
    	m_uEscorted2 = uEscorted;
    else if (m_nNumEscorted == 3)
    	m_uEscorted3 = uEscorted;
    else if (m_nNumEscorted == 4)
    	m_uEscorted4 = uEscorted;
    else if (m_nNumEscorted == 5)
    	m_uEscorted5 = uEscorted;
    else if (m_nNumEscorted == 6)
    	m_uEscorted6 = uEscorted;
    else if (m_nNumEscorted == 7)
    	m_uEscorted7 = uEscorted;
    else if (m_nNumEscorted == 8)
    	m_uEscorted8 = uEscorted;
    GetEscortedUnit();
    return 1;
    }

    //-------------------------------------------------------
    //modified DM/231100
	state Initialize
    {
    m_uSupplyCenter = null;
   	m_nRetreatGx = -1;
   	m_nGatherGx = -1;
   	m_nDamper = 0;
   	ResetState (stIdle);
   	retreatMode = rmHP50;
    if (!AssignToSupplyCenter ())
    	return Idle;
    CallMoveToPoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
    return MovingToAssemblyPoint;
    }
    
    //-------------------------------------------------------
    state Idle
    {
        int bIsEnd;
        
    AssignToSupplyCenter ();
    if (HaveObjectsForSupply())
        {
        //kontynujemy zaopatrzenie bo nie mozna zostawic zadnego obiektu
        bIsEnd = false;
        while (!bIsEnd && !CanCurrentObjectBeSupplied())
            {
            if (!NextObjectForSupply())
                bIsEnd = true;
            }
        if (!bIsEnd)
            {
            m_nMoveToX = GetCurrentPutSupplyPositionX();
            m_nMoveToY = GetCurrentPutSupplyPositionY();
            m_nMoveToZ = GetCurrentPutSupplyPositionZ();
            CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
            return MovingToObjectForSupply;
            }
        else
            return Idle;
        }
    else if (ForceRetreat ())
    	return Retreat;
	if (!IsMoving() && (m_nGatherGx == GetLocationX()) && (m_nGatherGy == GetLocationY()) && ForceRetreat())
		return Landing;
    if ((GetHP() == GetMaxHP()) && (m_nReturnToGx >= 0) && (m_nReturnToGy >= 0))   // return after repair
       	return RestoreState,2;
    return Idle;
    }
    
    //-------------------------------------------------------
    // new DM/231100
    state RestoreState
    {
        int nState;
        
    if ((m_nReturnToGx >= 0) && (m_nReturnToGy >= 0))
    	{
    	CallMoveToPoint (m_nReturnToGx, m_nReturnToGy, GetLocationZ ());
    	m_nReturnToGx = -1;
   	    return RestoreState,2;
    	}
  	if (IsMoving ())
   	    return RestoreState,2;
    if (m_nState != stIdle)
        {
        nState = m_nState;
        m_nState = stIdle;
        if (nState == stMove)
          	return Moving;
        if (nState == stEscort)
        	return Escort,5;
        }
    EndState ();
    return Idle;
    }
    //--------------------------------------------------------------------------
    state StartMoving
    {
    return Moving, 20;
    }
    //--------------------------------------------------------------------------
    state Moving
    {
        if (IsMoving())
        {
            return Moving;
        }
        else
        {
            NextCommand(1);
            return Idle;
        }
    }
    state StartLanding
    {
        return Landing, 20;
    }
    //--------------------------------------------------------------------------
    state Landing
    {
        if (IsMoving())
        {
            if ((GetLocationX() == m_nMoveToX) && (GetLocationY() == m_nMoveToY) && (GetLocationZ() == m_nMoveToZ) && 
                !IsFreePoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ))
            {
                if (!Land())
                {
                    NextCommand(1);
                    return Idle;
                }
            }
            return Landing;
        }
        else
        {
            if (!Land())
            {
                NextCommand(1);
                return Idle;
            }
            return Landing;
        }
    }
    //--------------------------------------------------------------------------
    
    state MovingToAssemblyPoint
    {
        if (IsMoving())
        {
            return MovingToAssemblyPoint;
        }
        else
        {
            return Idle;
        }
    }
    
    state MovingToSupplyCenter
    {
        int nPosX;
        int nPosY;
        int nPosZ;
        if (IsMoving())
        {
            nPosX = GetLocationX();
            nPosY = GetLocationY();
            nPosZ = GetLocationZ();
            if ((nPosX == m_nMoveToX) && (nPosY == m_nMoveToY) && (nPosZ == m_nMoveToZ))//added 25.01.2000
                            CallStopMoving();
            return MovingToSupplyCenter;
        }
        else
        {
            nPosX = GetLocationX();
            nPosY = GetLocationY();
            nPosZ = GetLocationZ();
            if ((nPosX == m_nMoveToX) && (nPosY == m_nMoveToY) && (nPosZ == m_nMoveToZ))
            {
                CallLoadAmmo();
                return LoadingAmmo;
            }
            else
            {
                //CallMoveAndLandToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                                CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);//dodane 09.03.2000
                return MovingToSupplyCenter;
            }
        }
    }
    
    state MovingToObjectForSupply
    {
        int nPosX;
        int nPosY;
        int nPosZ;
        int bIsEnd;
        if (IsMoving())
        {
            if (!CanCurrentObjectBeSupplied())
            {
                CallStopMoving();
                return MovingToObjectForSupply;
            }
            CheckCurrentPutSupplyLocation();
            if(m_nMoveToX != GetCurrentPutSupplyPositionX()||
                m_nMoveToY != GetCurrentPutSupplyPositionY())
            {
                m_nMoveToX = GetCurrentPutSupplyPositionX();
                m_nMoveToY = GetCurrentPutSupplyPositionY();
                m_nMoveToZ = GetCurrentPutSupplyPositionZ();
                CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
            }       
            
            //XXXMD zrobic gonienie czolgu
            return MovingToObjectForSupply;
        }
        else
        {
            if (IsInGoodCurrentPutSupplyLocation())
            {
                CallPutAmmo();
                return PuttingAmmo;
            }
            else
            {
                //nie jest w dobrym miejscu
                if (CanCurrentObjectBeSupplied())
                {
                    m_nMoveToX = GetCurrentPutSupplyPositionX();
                    m_nMoveToY = GetCurrentPutSupplyPositionY();
                    m_nMoveToZ = GetCurrentPutSupplyPositionZ();
                    CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                    return MovingToObjectForSupply;
                }
                else
                {
                    //nie mozna do niego dojechac (pod ziemia), lub zabity - biezemy nastepnego
                    bIsEnd = false;
                    do
                    {
                        if (!NextObjectForSupply())
                        {
                            bIsEnd = true;
                        }
                    }
                    while (!bIsEnd && !CanCurrentObjectBeSupplied());
                    if (!bIsEnd)
                    {
                        m_nMoveToX = GetCurrentPutSupplyPositionX();
                        m_nMoveToY = GetCurrentPutSupplyPositionY();
                        m_nMoveToZ = GetCurrentPutSupplyPositionZ();
                        CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                        return MovingToObjectForSupply;
                    }
                    else
                    {
                        //nie ma juz obiektow do zaopatrzenia - wracamy do punktu zbiorki
                        if (GetSupplyCenterBuilding() != null)
                        {
                            m_nMoveToX = GetSupplyCenterAssemblyPositionX();
                            m_nMoveToY = GetSupplyCenterAssemblyPositionY();
                            m_nMoveToZ = GetSupplyCenterAssemblyPositionZ();
                            CallMoveToPoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                            return MovingToAssemblyPoint;
                        }
                        else
                        {
                            return Idle;
                        }
                    }
                }
            }
        }
    }
    
    //--------------------------------------------------------------------------
    state LoadingAmmo
    {
        int bIsEnd;
        if (IsLoadingAmmo())
        {
            return LoadingAmmo;
        }
        else
        {
            if (HaveObjectsForSupply())
            {
                bIsEnd = false;
                while (!bIsEnd && !CanCurrentObjectBeSupplied())
                {
                    if (!NextObjectForSupply())
                    {
                        bIsEnd = true;
                    }
                }
                if (!bIsEnd)
                {
                    m_nMoveToX = GetCurrentPutSupplyPositionX();
                    m_nMoveToY = GetCurrentPutSupplyPositionY();
                    m_nMoveToZ = GetCurrentPutSupplyPositionZ();
                    CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                    return MovingToObjectForSupply;
                }
                else
                {
                    //nie ma obiektow do zaopatrzenia - wracamy do punktu zbiorki
                    if (GetSupplyCenterBuilding() != null)
                    {
                        m_nMoveToX = GetSupplyCenterAssemblyPositionX();
                        m_nMoveToY = GetSupplyCenterAssemblyPositionY();
                        m_nMoveToZ = GetSupplyCenterAssemblyPositionZ();
                        CallMoveToPoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                        return MovingToAssemblyPoint;
                    }
                    else
                    {
                        return Idle;
                    }
                }
            }
            else
            {
                //nie ma obiektow do zaopatrzenia - wracamy do punktu zbiorki
                if (GetSupplyCenterBuilding() != null)
                {
                    m_nMoveToX = GetSupplyCenterAssemblyPositionX();
                    m_nMoveToY = GetSupplyCenterAssemblyPositionY();
                    m_nMoveToZ = GetSupplyCenterAssemblyPositionZ();
                    CallMoveToPoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                    return MovingToAssemblyPoint;
                }
                else
                {
                    return Idle;
                }
            }
        }
    }
    
    //--------------------------------------------------------------------------
    state PuttingAmmo
    {
        int bIsEnd;
        if (IsPuttingAmmo())
        {
            return PuttingAmmo;
        }
        else
        {
            //sprawdzic czy wrzucono amunicje do biezacego obiektu
            if (WasCurrentObjectSupplied())
            {
                //ok jedziemy do nastepnego
                bIsEnd = false;
                do 
                {
                    if (!NextObjectForSupply())
                    {
                        bIsEnd = true;
                    }
                }
                while (!bIsEnd && !CanCurrentObjectBeSupplied());
                if (!bIsEnd)
                {
                    m_nMoveToX = GetCurrentPutSupplyPositionX();
                    m_nMoveToY = GetCurrentPutSupplyPositionY();
                    m_nMoveToZ = GetCurrentPutSupplyPositionZ();
                    CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                    return MovingToObjectForSupply;
                }
                else
                {
                    //nie ma juz obiektow do zaopatrzenia - wracamy do punktu zbiorki
                    if (GetSupplyCenterBuilding() != null)
                    {
                        m_nMoveToX = GetSupplyCenterAssemblyPositionX();
                        m_nMoveToY = GetSupplyCenterAssemblyPositionY();
                        m_nMoveToZ = GetSupplyCenterAssemblyPositionZ();
                        CallMoveToPoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                        return MovingToAssemblyPoint;
                    }
                    else
                    {
                        return Idle;
                    }
                }
            }
            else
            {
                //nie wrzucilismy zaopatrzenia do niego bo np. odjechal
                bIsEnd = false;
                while (!bIsEnd && !CanCurrentObjectBeSupplied())
                {
                    if (!NextObjectForSupply())
                    {
                        bIsEnd = true;
                    }
                }
                if (!bIsEnd)
                {
                    m_nMoveToX = GetCurrentPutSupplyPositionX();
                    m_nMoveToY = GetCurrentPutSupplyPositionY();
                    m_nMoveToZ = GetCurrentPutSupplyPositionZ();
                    CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                    return MovingToObjectForSupply;
                }
                else
                {
                    //nie ma obiektow do zaopatrzenia - wracamy do punktu zbiorki
                    if (GetSupplyCenterBuilding() != null)
                    {
                        m_nMoveToX = GetSupplyCenterAssemblyPositionX();
                        m_nMoveToY = GetSupplyCenterAssemblyPositionY();
                        m_nMoveToZ = GetSupplyCenterAssemblyPositionZ();
                        CallMoveToPoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                        return MovingToAssemblyPoint;
                    }
                    else
                    {
                        return Idle;
                    }
                }
            }
        }
    }
    
    //------------------------------------------------------- 
    state Frozen
    {
        if (IsFroozen())
        {
            state Frozen;
        }
        else
        {
            //!!wrocic do tego co robilismy
            state Idle;
        }
    }
    
    //--------------------------------------------------------------------------
    state Escort
    {
    	int	 nEscortGx;
    	int  nEscortGy;
    	int  nEscortLz;
    	int	 nDx;
    	int	 nDy;
    	
   	GetEscortedUnit();
    if (!m_uEscorted)
    if(!m_uEscorted)
        {
        if(IsMoving())
            {
            CallStopMoving();
            return Escort;
            }
        return Idle;
        }
        
	m_nEscortedGx = m_uEscorted.GetLocationX();    
	m_nEscortedGy = m_uEscorted.GetLocationY();    
	nEscortGx = GetLocationX();    
	nEscortGy = GetLocationY();    
	nEscortLz = GetLocationZ();    
    if (nEscortGx < m_nEscortedGx - 2)
    	nEscortGx = m_nEscortedGx - 2;
    else if (nEscortGx > m_nEscortedGx + 2)
    	nEscortGx = m_nEscortedGx + 2;
   	else
   		nDx = 0;
    if (nEscortGy < m_nEscortedGy - 2)
    	nEscortGy = m_nEscortedGy - 2;
    else if (nEscortGy > m_nEscortedGy + 2)
    	nEscortGy = m_nEscortedGy + 2;
   	else
   		nDy = 0;
   	if ((nEscortGx != m_nEscortedGx) || (nEscortGy != m_nEscortedGy))
        CallMoveToPoint(nEscortGx, nEscortGy, m_uEscorted.GetLocationZ());
    else if(IsMoving())
        CallStopMoving ();
    return Escort;
    }
    
    //------------------------------------------------------- 
    state Retreat
    {
    	unit	uAttacker;
    	int		nAttackerGx;
    	int		nAttackerGy;
    	
    if(IsAllowingWithdraw())
    	AllowScriptWithdraw(true);
    if (GatherUnits())
    	if (IsMoving ())
    		return Moving;
    	else
	    	return StartMoving;
    if (!m_nDamper)
    	{
		uAttacker = FindClosestEnemy();
		m_nDamper = 1;
		}
	else
		{
		if (IsMoving ())
			m_nDamper = (m_nDamper + 1) % cMaxDamper;
		else
			m_nDamper = 0;
		}
	if (!uAttacker)
		{
		if (IsMoving())
			CallStopMoving();
		return Idle;
		}
	m_nRetreatGx = GetLocationX();
	m_nRetreatGy = GetLocationY();
	nAttackerGx = uAttacker.GetLocationX();
	nAttackerGy = uAttacker.GetLocationY();
	if (m_nRetreatGx <= nAttackerGx)
		m_nRetreatGx = nAttackerGx - (cAttackerMaxDist + 1);
	else
		m_nRetreatGy = nAttackerGy + (cAttackerMaxDist + 1);
	if (m_nRetreatGy <= nAttackerGy)
		m_nRetreatGy = nAttackerGy - (cAttackerMaxDist + 1);
	else
		m_nRetreatGy = nAttackerGy + (cAttackerMaxDist + 1);
	if ((GetLocationX() != m_nRetreatGx) || (GetLocationY() != m_nRetreatGy))
		{
    	CallMoveToPoint(m_nRetreatGx, m_nRetreatGy, GetLocationZ());
    	return Retreat;
    	}
    m_nRetreatGx = -1;	// done retreating
    return Idle;
    }
    
    //--------------------------------------------------------------------------
    event OnFreezeForSupplyOrRepair(int nFreezeTicks)
    {
        CallFreeze(nFreezeTicks);
        state Frozen;
        true;
    }

    //--------------------------------------------------------------------------
    event OnKilledSupplyCenterBuilding()
    {
        unit uNewSupplyCenter;
        if(!GetSupplyCenterBuilding())//przeniesc do eventu
        {
            uNewSupplyCenter = FindSupplyCenter();        
            if ((uNewSupplyCenter != null) && SetSupplyCenterBuilding(uNewSupplyCenter))
            {
            	m_uSupplyCenter = uNewSupplyCenter;
                //pojechac do jego punktu zbiorki o ile nie rozwozimy zaopatrzenia
                m_nMoveToX = GetSupplyCenterAssemblyPositionX();
                m_nMoveToY = GetSupplyCenterAssemblyPositionY();
                m_nMoveToZ = GetSupplyCenterAssemblyPositionZ();
                CallMoveToPoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                return MovingToAssemblyPoint;
            }
        }
    }
    
    //------------------------------------------------------- 
    
    command Initialize()
    {
        false;
    }
    
    //------------------------------------------------------- 
    command Uninitialize()
    {
        //wykasowac referencje
        false;
    }
    
    //------------------------------------------------------- 
    command SetTransporterSupplyCenter(unit uSupplyCenter) hidden button "translateCommandSetSupplyCntr"
    {
        if (GetSupplyCenterBuilding() != uSupplyCenter)
        {
            if (SetSupplyCenterBuilding(uSupplyCenter))
            {
                //pojechac do jego punktu zbiorki o ile nie rozwozimy zaopatrzenia
                m_uSupplyCenter = uSupplyCenter;
                if (!HaveObjectsForSupply())
                {
                    m_nMoveToX = GetSupplyCenterAssemblyPositionX();
                    m_nMoveToY = GetSupplyCenterAssemblyPositionY();
                    m_nMoveToZ = GetSupplyCenterAssemblyPositionZ();
                    CallMoveToPoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                    state MovingToAssemblyPoint;
                }
                NextCommand(1);
            }
            else
            {
                NextCommand(0);
            }
        }
        else
        {
            if (!HaveObjectsForSupply() && (state != MovingToSupplyCenter))
            {
                m_nMoveToX = GetSupplyCenterAssemblyPositionX();
                m_nMoveToY = GetSupplyCenterAssemblyPositionY();
                m_nMoveToZ = GetSupplyCenterAssemblyPositionZ();
                CallMoveToPoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                state MovingToAssemblyPoint;
            }
            NextCommand(1);
        }
        true;
    }
    
    //komenda wydawana tylko przez budynek supplyCenter
    command MoveToSupplyCenterForLoading()
    {
        if (!HaveObjectsForSupply() && (state != LoadingAmmo))
        {
            m_nMoveToX = GetSupplyCenterLoadPositionX();
            m_nMoveToY = GetSupplyCenterLoadPositionY();
            m_nMoveToZ = GetSupplyCenterLoadPositionZ();
            //CallMoveAndLandToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                        CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);//dodane 09.03.2000
            state MovingToSupplyCenter;
        }
        //komenda wewnetrzna z budynku wiec nie wolamy NextCommand
        true;
    }
    
    //------------------------------------------------------- 
    command Move(int nGx, int nGy, int nLz) hidden button "translateCommandMove" description "translateCommandMoveDescription" hotkey priority 21
    {
    ResetState (stMove);
    m_nMoveToX = nGx;
    m_nMoveToY = nGy;
    m_nMoveToZ = nLz;
    if (m_nGatherGx < 0)
    	{
	    m_nGatherGx = nGx;
	    m_nGatherGy = nGy;
	    m_nGatherLz = nLz;
	    }
        CallMoveToPoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
        state StartMoving;
        true;
    }
    
    //------------------------------------------------------- 
    command Enter(unit uEntrance) hidden button "translateCommandEnter"
    {
    ResetState (stIdle);
    m_nMoveToX = GetEntranceX(uEntrance);
    m_nMoveToY = GetEntranceY(uEntrance);
    m_nMoveToZ = GetEntranceZ(uEntrance);
    CallMoveInsideObject(uEntrance);
    state StartMoving;
    true;
    }
    
    //------------------------------------------------------- 
    command Stop() hidden button "translateCommandStop" description "translateCommandStopDescription" hotkey priority 20
    {
    ResetState (stIdle);
    CallStopMoving();
    state Idle;
    true;
    }
    
    //------------------------------------------------------- 
    command Land() button "translateCommandLand" description "translateCommandLandDescription" hotkey priority 31 
    {
    ResetState (stIdle);
    m_nLandCounter = 1;
    if (Land())
        state StartLanding;
    else
        NextCommand(1);
    }
    
    //-------------------------------------------------------
    command SpecialChangeUnitsScript() button "translateCommandChangeScript" description "translateCommandChangeScriptDescription" hotkey priority 254 
    {
        //special command - no implementation
    }
    //-------------------------------------------------------
    command SetLights(int nMode) button lights description "translateCommandStateLightsModeDescription" hotkey priority 204
    {
    if (nMode == -1)
        lights = (lights + 1) % 3;
    else
        {
        assert(nMode == 0);
        lights = nMode;
        }
    SetLightsMode(lights);
    }
    
    //--------------------------------------------------------------------------
/*
    command UserOneParam9(int nMode) hidden button traceMode priority 255
    {
    if (nMode == -1)
	    traceMode = (traceMode + 1) % 2;
    else
	    {
	    assert(nMode == 0);
    	traceMode = nMode;
    	}
    }
*/
    //--------------------------------------------------------------------------
    command Escort(unit uUnit) button "translateCommandEscort" description "translateCommandEscortDescription" hotkey priority 31 
    {
    ResetState (stEscort);
    AddEscortedUnit (uUnit);
    state Escort;
    }
    
     //--------------------------------------------------------------------------
    command UserPoint9(int nGx, int nGy, int nLz) button "translateCommandSetGatherPoint" description "translateCommandSetGatherPointDescription" hotkey priority 52
    {
    m_nGatherGx = nGx;
    m_nGatherGy = nGy;
    m_nGatherLz = nLz;
    NextCommand (0);
    }
    
    //--------------------------------------------------------------------------
    command UserNoParam0() button "translateCommandRetreat" description "translateCommandRetreatDescription" hotkey priority 53
    {
    m_nDamper = 0;
   	state Retreat;
    }
    //--------------------------------------------------------------------------
    
    command UserOneParam0(int nMode) button retreatMode description "translateCommandStateRetreatModeDescription" priority 51
    {
    if (nMode == -1)
        retreatMode = (retreatMode + 1) % rmNum;
    else
        {
        assert(nMode == 0);
        retreatMode = nMode;
        }
    }
    
    
}

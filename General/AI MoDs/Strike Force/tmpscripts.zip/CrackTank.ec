// changes by Dietfrid Mali (Diedel) 28 nov 2000
// New movement modes
//		Generally unit stays as far away from target as possible
//		aggressive: get close enough to target to be able to attack with all mounted guns
// 		cautious: get close enough to target to be able to attack with farthest reaching gun
// Extended patrol mode
//		up to 10 patrol points per unit
//		restart patrol without having to set all patrol points again
//		delete all patrol points if a new patrol route is desired
// Script name: "Gefechtsfahrzeug (Elite)"
// new movement mode button labels "vorsichtig", "aggressiv"
// new patrol control buttons "Patr. starten", "weiter patr."
// renamed state Nothing to state Idle

tank "translateScriptNameCrackTankv16"
{
    consts
    {
        disableFire=0;
        enableFire=1;

		// movement modes
        mmFollowEnemy = 0;
        mmHoldArea = 1;
        mmHoldPos = 2;
        mmCount = 3;
		
        // attack distance        
        adStandard = 0;
        adCautious = 1;
        adAggressive = 2;
        adNum = 3;
        
		// attack modes
		amFireAtWill = 0;
		amReturnFire = 1;
		amHoldFire = 2;
		
	    m_nMaxPatrolPtCount = 10;

        // trace modes
        tmNone = 0;
        tmAll = 1;
        tmAttack = 2;
        tmPatrol = 3;
        tmEscort = 4;
        tmNum = 5;
        
		// retreat modes        
        rmNone = 0;
        rmAmmo = 1;
        rmHP66 = 2;
        rmHP50 = 3;
        rmHP25 = 4;
        rmNum = 5;
        
        // states
        stIdle = 0;
        stAttackPoint = 1;
        stAttack = 2;
        stMove = 3;
        stPatrol = 4;
        stEscort = 5;
        stRetreat = 6;

        cAttackerMaxDist = 15;
        cMaxDamper = 1;
    }
    
    int  m_nState;
	
    unit m_uTarget;
    int  m_nCannonsCount;
    int  m_nTargetGx;
    int  m_nTargetGy;
    int  m_nTargetLz;
    int  m_nDestGx;
    int  m_nDestGy;
    int  m_nDestLz;
    int  m_nSpecialGx; //Patrol point , escort
    int  m_nSpecialGy;
    int  m_nSpecialLz;
    
    int  m_nNextPatrolGx;
    int  m_nNextPatrolGy;
    int  m_nNextPatrolLz;
    int  m_nPatrolPt1Gx;
    int  m_nPatrolPt1Gy;
    int  m_nPatrolPt1Lz;
    int  m_nPatrolPt2Gx;
    int  m_nPatrolPt2Gy;
    int  m_nPatrolPt2Lz;
    int  m_nPatrolPt3Gx;
    int  m_nPatrolPt3Gy;
    int  m_nPatrolPt3Lz;
    int  m_nPatrolPt4Gx;
    int  m_nPatrolPt4Gy;
    int  m_nPatrolPt4Lz;
    int  m_nPatrolPt5Gx;
    int  m_nPatrolPt5Gy;
    int  m_nPatrolPt5Lz;
    int  m_nPatrolPt6Gx;
    int  m_nPatrolPt6Gy;
    int  m_nPatrolPt6Lz;
    int  m_nPatrolPt7Gx;
    int  m_nPatrolPt7Gy;
    int  m_nPatrolPt7Lz;
    int  m_nPatrolPt8Gx;
    int  m_nPatrolPt8Gy;
    int  m_nPatrolPt8Lz;
    int  m_nPatrolPt9Gx;
    int  m_nPatrolPt9Gy;
    int  m_nPatrolPt9Lz;
    int  m_nPatrolPt10Gx;
    int  m_nPatrolPt10Gy;
    int  m_nPatrolPt10Lz;
    int  m_nPatrolPtCount;
    int  m_nCurrentPatrolPt;
    
    int  m_nTgtRelPos;
    int	 m_nDestDist;
    
    int  m_nEscortedGx;
    int  m_nEscortedGy;
    int  m_nEscortedLz;
    unit m_uEscorted;
    unit m_uEscorted1;
    unit m_uEscorted2;
    unit m_uEscorted3;
    unit m_uEscorted4;
    unit m_uEscorted5;
    unit m_uEscorted6;
    unit m_uEscorted7;
    unit m_uEscorted8;
    int	 m_nCurEscorted;
    int  m_nNumEscorted;
    unit m_uAttacker;

    int	 m_nGatherGx;
    int	 m_nGatherGy;
    int	 m_nGatherLz;

    int	 m_nRetreatGx;
    int	 m_nRetreatGy;
    int  m_nReturnToGx;
    int  m_nReturnToGy;
    int	 m_nDamper;
	int  m_bIncToggle;
    
    int  bFirstShoot;
    unit m_uSpecialUnit;
    
    enum lights
    {
        "translateCommandStateLightsAUTO",
        "translateCommandStateLightsON",
        "translateCommandStateLightsOFF",
multi:
        "translateCommandStateLightsMode"
    }
    
    // modified DM/211100
    enum movementMode
    {
        "translateCommandStateFollowEnemy",
        "translateCommandStateHoldArea",
        "translateCommandStateHoldPosition",
            
multi:
        "translateCommandStateMovement"
    }

    // new DM/061200    
    enum attackDistance
    {
        "translateCommandStateADStandard",
        "translateCommandStateADCautious",
        "translateCommandStateADAggressive",
            
multi:
        "translateCommandStateAttackDistance"
    }
    
    // modified DM/211100
    enum attackMode
    {
        "translateCommandStateFireAtWill",
        "translateCommandStateReturnfire",
        "translateCommandStateHoldFire",
        "translateCommandStateFireAtTarget",
multi:
        "translateCommandStateFireMode"
    }
    
    enum searchMode
    {
        "translateCommandStateNearestTarget",
        "translateCommandStateWeakestTarget",
multi:
        "translateCommandStateTargeting"
    }
    
    enum retreatMode
    {
        "translateCommandStateNoRetreat",
        "translateCommandStateRetreatNoAmmo",
        "translateCommandStateRetreatHP66",
        "translateCommandStateRetreatHP50",
        "translateCommandStateRetreatHP25",
multi:
        "translateCommandStateRetreatMode"
    }
/*Trace>>>    
    enum eTraceMode
    {
        "translateCommandStateExtTraceOFF",
        "translateCommandStateExtTraceALL",
        "translateCommandStateExtTraceATTACK",
        "translateCommandStateExtTracePATROL",
        "translateCommandStateExtTraceESCORT",
multi:
        "translateCommandStateExtTraceMode"
    }
<<<Trace*/
    
    state Idle;
    state RestoreState;
    state HoldPosition;
    state StartMoving;
    state Moving;
    state AutoAttacking;
    state Attacking;
    state AttackingPoint;
    state BeginPatrol;
    state Patrol;
    state Escort;
    state InPlatoonState;
    state Retreat;
    //------------------------------------------------------- 
    //********************************************************
    //********* F U N C T I O N S ****************************
    //********************************************************
    //--------------------------------------------------------------------------
    
/*Trace>>>    
    function int TraceMode (int nTraceMode)
    {
    if ((nTraceMode == eTraceMode) || (eTraceMode == tmAll))
    	return true;
    return false;
    }
<<<Trace*/
    //------------------------------------------------------- 
    function int SetTarget(unit uTarget)
    {
        m_uTarget = uTarget;
        SetTargetObject(uTarget);
        return true;
    }
    //--------------------------------------------------------------------------
    
    function int ResetAttack(unit uTarget)
    {
	m_nReturnToGx = -1;
    SetTarget(uTarget);
    if (!uTarget)
        StopCannonFire(-1);
    return 1;
    }
    
    //--------------------------------------------------------------------------
    
    function int ResetEscort()
    {
    m_uEscorted = null;
    m_uAttacker = null;
    m_nCurEscorted = 0;
    m_nNumEscorted = 0;
    return 1;
    }
    
    //------------------------------------------------------- 
    // new DM/211100
    // Set current position as destination position
    function int SetDestToCurPos()
    {
    m_nDestGx = GetLocationX();
    m_nDestGy = GetLocationY();
    m_nDestLz = GetLocationZ();
    return 1;
     }
    //------------------------------------------------------- 
    
    function int MoveToDestination()
    {
    CallMoveToPoint(m_nDestGx, m_nDestGy, m_nDestLz);
    }
    
    //----------------------------------------------------
    function int AttackTargetValid()
    {
    if (!m_uTarget || !m_uTarget.IsLive() || ((GetCannonType(0) == cannonTypeIon) && m_uTarget.IsDisabled()))
    	{
    	return 0;
    	}
	return 1;
    }
    //------------------------------------------------------- 
    function int GoToPoint()
    {
        int nRangeMode;
        int nDx;
        int nDy;
        nRangeMode = IsPointInCannonRange(0,m_nTargetGx, m_nTargetGy, m_nTargetLz);
        
        if(nRangeMode == 0) //poza zasiegiem
        {
            CallMoveToPoint(m_nTargetGx, m_nTargetGy, m_nTargetLz);
            return true;
        }
        if (nRangeMode == 4) //in range
        {
            if (IsMoving())
                CallStopMoving();
            return false;
        }
        if(nRangeMode == 1) //w zasiegu ale trzeba odwrocic czolg 
        {
            if (IsMoving())
                CallStopMoving();
            else
                CallTurnToAngle(GetCannonAngleToPoint(0,m_nTargetGx, m_nTargetGy, m_nTargetLz));
            
            return true;
        }
        CallMoveToPoint(m_nTargetGx, m_nTargetGy, m_nTargetLz);
        return true;
    }
    //------------------------------------------------------- 
    // new DM/211100
    // Get firing range of lowest ranged gun on vehicle
    // returns firing range in low byte, gun with that range in high byte
    function int GetMinFiringRange ()
    {
    	int	h;
    	int	i;
    	int	nGun;
   		int	nRange;
    
    nRange = -1;	
    i = GetCannonsCount();
    while (i)
    	{
    	--i;
    	h = GetCannonShootRange (i);
    	if ((nRange < 0) || (h < nRange))
    		{
    		nRange = h;
    		nGun = i;
    		}
    	}
/*Trace>>>    
  	if (TraceMode (tmAttack))
  		{
  		TraceD ("min. firing range=");
  		TraceD (nRange);
  		TraceD (", gun=");
  		TraceD (nGun);
  		TraceD ("                                        \n");
  		}
<<<Trace*/
	return (nRange + (nGun * 65536));
    }
    
    //------------------------------------------------------- 
    // new DM/211100
    // Get firing range of highest ranged gun on vehicle
    // returns firing range in low byte, gun with that range in high byte
    function int GetMaxFiringRange ()
    {
    	int	h;
    	int	i;
    	int	nGun;
   		int	nRange;
    
    nRange = -1;	
    i = GetCannonsCount();
    while (i)
    	{
    	--i;
    	h = GetCannonShootRange (i);
    	if (h > nRange)
    		{
    		nRange = h;
    		nGun = i;
    		}
    	}
/*Trace>>>    
  	if (TraceMode (tmAttack))
  		{
  		TraceD ("max. firing range=");
  		TraceD (nRange);
  		TraceD (", gun=");
  		TraceD (nGun);
  		TraceD ("                                        \n");
  		}
<<<Trace*/
	return (nRange + (nGun * 65536));
    }
    
    //------------------------------------------------------- 
    // new DM/061200
    // determine firing range and gun with that range depending on attackDistance
    function int GetFiringRange ()
    {
    if (attackDistance == adCautious)
    	return GetMaxFiringRange ();
  	return GetMinFiringRange ();
    }
    
    //------------------------------------------------------- 
    // DM/071200
    function int AdjustAttackDistance (int nDestDist)
    {
        int x;
        int y;
        int xTgt;
        int yTgt;
        int	nDx;
        int	nDy;
        int	nDd;
        int	h;
        int hDx;
        int hDy;
        int hDx0;
        int hDy0;
        int nCurDist;
        int bForceInc;
        
	// the following code computes a destination position that brings the target
	// into firing range. Since there are no trigonometrical functions available in
	// Moon C, the distance is iterated until the unit is close enough.
	nDestDist = nDestDist - 1;
/*Trace>>>    
  	if (TraceMode (tmAttack))
		{
		TraceD ("adjusting attack dist to ");
		TraceD (nDestDist);
		TraceD ("\n");
		}
<<<Trace*/
	x = GetLocationX();
	y = GetLocationY();
	xTgt = m_uTarget.GetLocationX();
	yTgt = m_uTarget.GetLocationY();
	if (!xTgt && !yTgt) // catch Moon-C bug
	    {
	    xTgt = x;
	    yTgt = y;
	    }
	nCurDist = Distance (x,y,xTgt,yTgt);
	if ((attackDistance == adStandard) && (nCurDist <= nDestDist))
	    return 0;
	
	// set iteration direction for X axis
	if (x < xTgt)
		nDx = -1;
	else if (x > xTgt)
		nDx = 1;
	else
		nDx = 0;
	// set iteration direction for Y axis
	if (y < yTgt)
		nDy = -1;
	else if (y > yTgt)
		nDy = 1;
	else
		nDy = 0;
		
	hDx = x - xTgt;
	if (hDx < 0)
		hDx = -hDx;
	hDy = y - yTgt;
	if (hDy < 0)
		hDy = -hDy;
		
	hDx0 = hDx;
	hDy0 = hDy;
	h = nDestDist * nDestDist;
	if (!nDx && !nDy)
	    bForceInc = 1;
	else
	    bForceInc = 0;
/*Trace>>>    
	if (TraceMode (tmAttack))
		{
		TraceD ("---------------------------------------------------------------------\n");
		TraceD ("Adjusting. destDist=");
		TraceD (nDestDist);
		TraceD (", hDx,hDy=");
		TraceD (hDx);
		TraceD (",");
		TraceD (hDy);
		TraceD ("\n");
		}
<<<Trace*/
	while (hDx * hDx + hDy * hDy < h)
		{
		if (m_bIncToggle)
		    {
		    m_bIncToggle = 0;
    		if (nDx || bForceInc)
	    		++hDx;
	    	}
	    else
	        {
	        m_bIncToggle = 1;
		    if (nDy || bForceInc)
			    ++hDy;
			}
		}
	if (!m_bIncToggle)
	    m_bIncToggle = 1;
	else
	    m_bIncToggle = 0;
	while (hDx * hDx + hDy * hDy > h)
		{
		if (m_bIncToggle)
		    {
		    m_bIncToggle = 0;
    		if ((nDx || bForceInc) && hDx)
	    		--hDx;
	    	}
	    else
	        {
	        m_bIncToggle = 1;
		    if ((nDy || bForceInc) && hDy)
			    --hDy;
			}
		}
/*Trace>>>    
	if (TraceMode (tmAttack))
		{
		TraceD ("Done. destDist=");
		TraceD (nDestDist);
		TraceD (", hDx,hDy=");
		TraceD (hDx);
		TraceD (",");
		TraceD (hDy);
		TraceD ("\n");
		}
<<<Trace*/
	if ((hDx0 == hDx) && (hDy0 == hDy))
		return 0;
	x = xTgt + nDx * hDx;
	y = yTgt + nDy * hDy;
	if (nCurDist == Distance (x,y,xTgt,yTgt))
	    return 0;
/*Trace>>>    
  	if (TraceMode (tmAttack))
    	TraceD ("adjusting range to target\n");
<<<Trace*/
    CallMoveToPoint(x, y, m_uTarget.GetLocationZ());
	return 1;
    }
    
    //------------------------------------------------------- 
    // new DM/211100
    function int DistanceToTarget()
    {
    return DistanceTo(m_uTarget.GetLocationX(),m_uTarget.GetLocationY());
    }

    //------------------------------------------------------- 
    // new DM/211100
    // move unit around its target in 90 degree angle
    function int MoveAroundTarget (int nDestDist)
    {
	    int	xTgt;
	    int	yTgt;
	    int	zTgt;
    
    xTgt = m_uTarget.GetLocationX();
    yTgt = m_uTarget.GetLocationY();
    zTgt = m_uTarget.GetLocationZ();
    if (((m_nTgtRelPos % 2) == 1) && (nDestDist > 1))
    	nDestDist = nDestDist / 2;
    if (m_nTgtRelPos == 0)		// 12 o'clock
    	yTgt = yTgt + nDestDist;
    else if (m_nTgtRelPos == 1)	// 1:30
    	{
    	yTgt = yTgt + nDestDist;
    	xTgt = xTgt + nDestDist;
    	}
    else if (m_nTgtRelPos == 2)	// 3 o'clock
    	xTgt = xTgt + nDestDist;
    else if (m_nTgtRelPos == 3)	// 4:30
    	{
    	yTgt = yTgt - nDestDist;
    	xTgt = xTgt + nDestDist;
    	}
    else if (m_nTgtRelPos == 4)	// 6 o'clock
    	yTgt = yTgt - nDestDist;
    else if (m_nTgtRelPos == 5)	// 7:30
    	{
    	yTgt = yTgt - nDestDist;
    	xTgt = xTgt - nDestDist;
    	}
    else if (m_nTgtRelPos == 6)	// 9 o'clock
    	xTgt = xTgt - nDestDist;
    else if (m_nTgtRelPos == 7)	// 10:30
    	{
    	yTgt = yTgt + nDestDist;
    	xTgt = xTgt - nDestDist;
    	}
    if (xTgt < 0)
    	xTgt = 0;
    if (yTgt < 0)
    	yTgt = 0;
   	// first go through the even, then through the odd numbered positions
    if (m_nTgtRelPos == 6)
    	m_nTgtRelPos = 1;
    else if (m_nTgtRelPos == 7)
    	m_nTgtRelPos = 0;
    else
	    m_nTgtRelPos = m_nTgtRelPos + 2;
    	
  	CallMoveToPoint(xTgt, yTgt, zTgt);
    }
    
    //------------------------------------------------------- 
    // modified DM/211100
    // depending on movementMode (cautious/aggressive) GotoTarget will
    // move the unit close enough to its target to attack with its farthest
    // reaching gun (defensive) or with all guns (aggressive).
    
    function int GoToTarget()
    {
        int nRangeMode;
        int x;
        int y;
        int xTgt;
        int yTgt;
        int	nDx;
        int	nDy;
        int nCurDist;
        int	nDestDist;
        int	nMainGun;
        int bAdjust;
        int	h;

		h = GetFiringRange ();
		nDestDist = h % 65536;
    	nMainGun = h / 65536;        
/*Trace>>>    
	  	if (TraceMode (tmAttack))
			{
			TraceD ("nDestDist=");
			TraceD (nDestDist);
			TraceD (", nMainGun=");
			TraceD (nMainGun);
			TraceD ("\n");
			}
<<<Trace*/
        bAdjust = AdjustAttackDistance (nDestDist);
        nRangeMode = IsTargetInCannonRange(nMainGun, m_uTarget);
        nCurDist = DistanceToTarget();
        if (nRangeMode == notInRange)	// should be taken care of in first call to AdjustAttackDistance
        	{
	        return true;
        	}
        
        if (nRangeMode == inRangeGoodHit)
        	{
       		if (!bAdjust && IsMoving())
		        CallStopMoving();
            return false;
        	}
        
        if (nRangeMode == inRangeBadAngleAlpha) //bad horizontal turret/gun angle 
        	{
            if (IsMoving())
                CallStopMoving();
            else
                CallTurnToAngle(GetCannonAngleToTarget(0,m_uTarget));
            return true;
        	}
        
        if (nRangeMode == inRangeBadAngleBeta)	//bad elevation angle
        	{
            if(nCurDist < 3)	//very close, so move to opposite side of target
	        	{
	        	MoveAroundTarget (nDestDist);
	        	m_nDestDist = nDestDist;
	        	}
	        else	// move some closer
	        	{
	        	if ((m_nDestDist > nDestDist) || (m_nDestDist <= 0))
	        		m_nDestDist = nDestDist;
	        	m_nDestDist = nDestDist / 2;
	        	MoveAroundTarget (m_nDestDist);
	        	}
            return true;
        	}
        
        //obstacle between unit and target 
        if (nCurDist < 3)	//very close, so move to opposite side of target
        	{
           	MoveAroundTarget (nDestDist);
        	}
        else
        	{
        	AdjustAttackDistance (4);
        	}
        return true;
    }
    
    //------------------------------------------------------- 
    function int TargetInRange()
    {
        int nRangeMode;
        int nDx;
        int nDy;
        nRangeMode = IsTargetInCannonRange(0, m_uTarget);
        
        if (nRangeMode == inRangeGoodHit) 
        {
            return true;
        }
        if(nRangeMode == inRangeBadAngleAlpha) //w zasiegu ale trzeba odwrocic czolg 
        {
            if (IsMoving())
            {
                CallStopMoving();
            }
            else
            {
                CallTurnToAngle(GetCannonAngleToTarget(0,m_uTarget));
            }
            return true;
        }
        return false;
    }
    //-------------------------------------------------------
    function int EndState()
    {
        NextCommand(1);
    }
    //-------------------------------------------------------
    function int FindBestTarget()
    {
        int i;
        int nTargetsCount;
        unit newTarget;
        int nFindTarget;
        
        if(GetCannonType(0) != cannonTypeIon)
        {
            nFindTarget = 0;
            if (CanCannonFireToAircraft(-1))
            {
                nFindTarget = findTargetFlyingUnit;
            }
            if (CanCannonFireToGround(-1))
            {
                if (GetCannonType(0) == cannonTypeEarthquake)
                {
                    nFindTarget = nFindTarget | findTargetBuildingUnit;
                }
                else
                {
                    nFindTarget = nFindTarget | findTargetNormalUnit | findTargetWaterUnit | findTargetBuildingUnit;
                }
            }
            if(searchMode==1)//find weakest target
                SetTarget(FindTarget(nFindTarget, findEnemyUnit, findWeakestUnit, findDestinationAnyUnit));
            else //find closest target
                SetTarget(FindClosestEnemyUnitOrBuilding(nFindTarget));

            if(m_uTarget!=null && 
                movementMode==mmHoldPos && 
                (IsTargetInCannonRange(0, m_uTarget)!=inRangeGoodHit))
            {
                if(!CanCannonFireToAircraft(-1))
                    SetTarget(FindTarget(nFindTarget, findEnemyUnit, findNearestUnit, findDestinationAnyUnit));
                else
                    SetTarget(FindTarget(nFindTarget, findEnemyUnit, findNearestUnit, findDestinationAnyUnit));
            }
            return true;
        }
        SetTarget(null);
        BuildTargetsArray(findTargetWaterUnit|findTargetNormalUnit|findTargetBuildingUnit, findEnemyUnit,findDestinationAnyUnit);
        SortFoundTargetsArray();
        nTargetsCount=GetTargetsCount();
        if(nTargetsCount!=0)
        {
            StartEnumTargetsArray();
            for(i=0;i<nTargetsCount;i=i+1)
            {
                newTarget = GetNextTarget();
                if(!newTarget.IsDisabled())
                {
                    EndEnumTargetsArray();
                    SetTarget(newTarget);
                    return true;
                }
            }
            EndEnumTargetsArray();
            return false;
        }
        else
        {
            return false;
        }
    }
    //------------------------------------------------------- 
    function int GatherUnits ()
    {
    if ((m_nGatherGx >= 0) && ((GetLocationX() != m_nGatherGx) || (GetLocationY() != m_nGatherGy)))
    	{
		CallMoveToPoint (m_nGatherGx, m_nGatherGy, m_nGatherLz);
		return 1;
		}
	return 0;
	}
    //------------------------------------------------------- 
	// new DM/271100
	// check if attacker uAttacker is valid attacker for target uTarget.
	// if no attacker or attacker destroyed or attacker captured or attacker disabled
	// return false.
	// Otherwise check distance between attacker and target (since there is no way
	// to retrieve gun range of attacker or information about attacker's current targets)
	// and use that to determine if uAttacker still attacks uTarget.
	// if uTarget is null, uTarget is current unit (like C++'s *this).
	
    function int IsValidAttacker (unit uAttacker, unit uTarget, int bCheckDistance)
    {
    	int		nTargetGx;
    	int		nTargetGy;
    	
    if ((uAttacker == null) || !uAttacker.IsLive() || !IsEnemy(uAttacker) || uAttacker.IsDisabled())
    	return false;
    if (bCheckDistance)
    	{
	    if (!uTarget)	// if(!<unit>) is accepted as boolean expression, but if(<unit>) yields an error
	    	{			//  message. must use if (!<unit != null) instead ... ts ...
		   	nTargetGx = GetLocationX();	
	   		nTargetGy = GetLocationY();
	    	}
	    else
	    	{
		   	nTargetGx = uTarget.GetLocationX();	
	   		nTargetGy = uTarget.GetLocationY();
	   		}
	   	if (Distance(m_nTargetGx,m_nTargetGy,uAttacker.GetLocationX(),uAttacker.GetLocationY()) > cAttackerMaxDist)
			return false;
		}
	return true;
    }
    
    //------------------------------------------------------- 
    
    function int GetAttackerEx(unit uTarget)
    {
    	unit	uAttacker;
    	int		bCheckDistance;
    	
    if (uTarget)
    	m_uAttacker = uTarget.GetAttacker();
    else
    	m_uAttacker = GetAttacker();
    if (uTarget)
    	bCheckDistance = 1;
    else
    	bCheckDistance = 0;
	if (!IsValidAttacker (m_uAttacker, uTarget, bCheckDistance) || (!uTarget && !IsTargetInCannonRange(-1,m_uAttacker)))
    	m_uAttacker = null;
    if (!m_uAttacker)
    	{
    	if (uTarget)
    		uTarget.ClearAttacker();
    	else
    		ClearAttacker();
    	return false;
    	}
    return true;
    }
    
    //------------------------------------------------------- 
	// new DM/291100
	// Check whether an escort needs to switch its attack target.
	// Generally, escorts stick with a target once it is acquired until it is destroyed.
	// The escort should preferrably attack airplanes though since they pose a deadly threat
	// to ground units.
	// The following code first checks the escort's current attack target, then saves it
	// and acquires any potential new attack target with GetAttackerEx().
    function int TryForceNewAttacker (unit uTarget)
    {
    	unit	uOldAttacker;
    	
    if (!IsValidAttacker (m_uAttacker, uTarget, true))
    	m_uAttacker = null;		// discard current (old) attacker if not valid any more
    uOldAttacker = m_uAttacker;	// remember current attacker anyway (may be discarded here)
    GetAttackerEx (uTarget);	// get most recent attacker
    if (!m_uAttacker || (uOldAttacker == m_uAttacker) || ((uOldAttacker != null) && CanCannonFireToAircraft(-1) && (!m_uAttacker.IsHelicopter() || uOldAttacker.IsHelicopter())))
    	{
    	m_uAttacker = uOldAttacker;
	    return false;
	    }
	return true;
    }
    //-------------------------------------------------------
    // new DM/231100
    function int ResetState (int nNewState, unit uTarget)
    {
    ResetAttack (uTarget);
    if (nNewState != stEscort)
        ResetEscort ();
    m_nState = nNewState;
    }
    //-------------------------------------------------------
    // new DM/231100
    function int SaveState ()
    {
    if (state == AttackingPoint)
        m_nState = stAttackPoint;
    else if(state==Attacking)
        m_nState = stAttack;
    else if(state==Moving)
        m_nState = stMove;
    else if(state==Patrol)
        m_nState = stPatrol;
    else if(state==Escort)
        m_nState = stEscort;
    else
    	m_nState = stIdle;
    return m_nState;
    }
    //------------------------------------------------------- 
    function int ForceRetreat ()
    {
    	int nCurHP;
    	int nMaxHP;
    	
    if (retreatMode < rmHP66)
    	return false;
    nCurHP = GetHP();
    nMaxHP = GetMaxHP();
    if (retreatMode == rmHP25)
    	nCurHP = 4 * nCurHP;
    if (retreatMode == rmHP50)
    	nCurHP = 2 * nCurHP;
    else
    	nCurHP = (3 * nCurHP + 2) / 2;
    if (nCurHP > nMaxHP)
    	return false;
    m_nDamper = 0;
    if (m_nState != stIdle)
        SaveState ();
    if (m_nReturnToGx < 0)
        {
        m_nReturnToGx = GetLocationX();
        m_nReturnToGy = GetLocationX();
        }
    return true;
    }
    //********************************************************
    //************* S T A T E S ******************************
    //********************************************************
    state Retreat
    {
    	int		nAttackerGx;
    	int		nAttackerGy;
    	unit	uAttacker;
    	
    if(IsAllowingWithdraw())
    	AllowScriptWithdraw(true);
    if(!m_nDamper)
    	{
        SetTargetObject (null);
        uAttacker = FindClosestEnemy();
        m_nDamper = 1;
    	}
    else
    	{
        if(IsMoving())
            m_nDamper = (m_nDamper + 1) % cMaxDamper;
        else
            m_nDamper = 0;
    	}
    if(!uAttacker)
        SetTargetObject(null);
    if (GatherUnits())
    	{
    	if (IsMoving ())
    		return Moving;
    	else
	    	return StartMoving;
	    }
	if (!uAttacker)
		{
		if (IsMoving())
			CallStopMoving();
		return Idle;
		}
	m_nRetreatGx = GetLocationX();
	m_nRetreatGy = GetLocationY();
	nAttackerGx = uAttacker.GetLocationX();
	nAttackerGy = uAttacker.GetLocationY();
	if (m_nRetreatGx <= nAttackerGx)
		m_nRetreatGx = nAttackerGx - (cAttackerMaxDist + 1);
	else
		m_nRetreatGy = nAttackerGy + (cAttackerMaxDist + 1);
	if (m_nRetreatGy <= nAttackerGy)
		m_nRetreatGy = nAttackerGy - (cAttackerMaxDist + 1);
	else
		m_nRetreatGy = nAttackerGy + (cAttackerMaxDist + 1);
	if ((GetLocationX() != m_nRetreatGx) || (GetLocationY() != m_nRetreatGy))
		{
    	CallMoveToPoint(m_nRetreatGx, m_nRetreatGy, GetLocationZ());
    	return Retreat;
    	}
    m_nRetreatGx = -1;	// done retreating
    return Idle;
    }
    
    
    //------------------------------------------------------- 
    state InPlatoonState
    {
    if(!IsAllowingWithdraw())
    	AllowScriptWithdraw(true);
    if(!InPlatoon()) 
        {
        SetLightsMode(lights);
        SetCannonFireMode(-1, disableFire);
        return Idle;
        }
    return InPlatoonState;
    }
    //------------------------------------------------------- 
    
    state Idle
    {
    if(!IsAllowingWithdraw())
    	AllowScriptWithdraw(true);
    if(InPlatoon())
        {
        SetCannonFireMode(-1, enableFire);
        return InPlatoonState;
        }
    if (ForceRetreat())
    	return Retreat;
    if ((movementMode == mmFollowEnemy) && (GetHP() == GetMaxHP()) && (m_nReturnToGx >= 0) && (m_nReturnToGy >= 0))   // return after repair
        return RestoreState,20;
    if(GetCannonType(0)==cannonTypeBallisticRocket)
    	return Idle;
    if(movementMode==mmHoldPos)
    	return HoldPosition;
    if(attackMode==amHoldFire)//hold fire
    	{
//    	if (!IsMoving () && GatherUnits ())
//    		return StartMoving;
        return Idle;
        }
    if (attackMode == amFireAtWill)//Fire at will
        FindBestTarget();
    if(!m_uTarget)
        {
        SetTarget(GetAttacker());
        ClearAttacker();
        }
        
    if (m_uTarget != null)
        {
        SetDestToCurPos ();
        return AutoAttacking;
        }
//    if (!IsMoving () && GatherUnits())
//    	return StartMoving;
    return Idle;
    }
    //-------------------------------------------------------
    // new DM/231100
    state RestoreState
    {
        int nState;
        
    if ((m_nReturnToGx >= 0) && (m_nReturnToGy >= 0))
    	{
    	CallMoveToPoint (m_nReturnToGx, m_nReturnToGy, GetLocationZ ());
    	m_nReturnToGx = -1;
   	    return RestoreState,2;
    	}
  	if (IsMoving ())
   	    return RestoreState,2;
    if (m_nState != stIdle)
        {
        nState = m_nState;
        m_nState = stIdle;
        if (nState == stAttackPoint)
        	return AttackingPoint,20;
        if (nState == stAttack)
        	return Attacking,20;
        if (nState == stMove)
          	return Moving;
        if (nState == stPatrol)
        	return Patrol,20;
        if (nState == stEscort)
        	return Escort,20;
        }
    EndState ();
    return Idle;
    }
    //----------------------------------------------------
    state HoldPosition
    {
    if(IsAllowingWithdraw())
      	AllowScriptWithdraw(false);
    if(movementMode!=mmHoldPos) 
    	return Idle;
    if(m_uTarget)
        { 
		if (!AttackTargetValid())
            {
            StopCannonFire(-1);
            SetTarget(null);
            }
        else
            {
            if(TargetInRange())
                CannonFireToTarget(-2, m_uTarget, -1);
            else
                SetTarget(null);
            }
        }
    else
        {
        if(attackMode==amHoldFire)//hold fire
            return HoldPosition;   
        if (attackMode == amFireAtWill)//Fire at will
            FindBestTarget();
        if(!m_uTarget)
            {
            SetTarget(GetAttacker());
            ClearAttacker();
            }
        }        
    return HoldPosition;
    }
    //----------------------------------------------------
    state AutoAttacking
    {
        int nDistance;
        
        // pozostawaj w okolicach punktu
    nDistance = Distance(m_nDestGx,m_nDestGy,GetLocationX(),GetLocationY());
    if((movementMode==mmHoldArea) && (nDistance > 8))
        {
        SetTarget(null);
        MoveToDestination();
        if(attackMode==amFireAtWill)
        	SetCannonFireMode(-1, enableFire);
        return StartMoving;         
        }
        
	if (!AttackTargetValid())
        {
        StopCannonFire(-1);
        SetTarget(null);
        }
        
    if (m_uTarget)
        {
        if(!GoToTarget())
    	    {
            CannonFireToTarget(-2, m_uTarget, -1);
            return AutoAttacking;
	        }
        return AutoAttacking,2;
        }
        else//target does not exist
	        {
            if(attackMode==amFireAtWill)
                FindBestTarget();
            if(!m_uTarget && (attackMode==amReturnFire))
    	        {
                SetTarget(GetAttacker());
                ClearAttacker();
        	    }
            if (m_uTarget != null)
                return AutoAttacking;
            if( nDistance > 0 && movementMode==mmHoldArea)
	            {
                MoveToDestination();
                return StartMoving;                     
    	        }
            
            if (IsMoving())
                CallStopMoving();
            GatherUnits ();
            return Idle;
        }
    }
    //--------------------------------------------------------------------------
    state AttackingPoint
    {
/*Trace>>>    
	if (TraceMode (tmAttack))
       	TraceD("Attacking point                                   \n");
<<<Trace*/
    if(GoToPoint())
    	return AttackingPoint;
   	CannonFireGround(-1, m_nTargetGx, m_nTargetGy, m_nTargetLz, 1);
	return AttackingPoint;
    }
    //----------------------------------------------------
    state Attacking
    {
/*Trace>>>    
	if (TraceMode (tmAttack))
        TraceD("Attacking                                        \n");
<<<Trace*/
    if (AttackTargetValid() || bFirstShoot)
        {
        if(GoToTarget())
            return Attacking,2;
        else
            {
/*Trace>>>    
        	if (TraceMode (tmAttack))
                TraceD("Firing                                           \n");
<<<Trace*/
            bFirstShoot=false;
            CannonFireToTarget(-1, m_uTarget, -1);
            return Attacking;
            }
        }
    else //target not exist or is disabled
        {
        SetTarget(null);
        StopCannonFire(-1);
        if (IsMoving())
            {
            CallStopMoving();
            }
        EndState();
        return Idle;
        }
    }
    
    
    //--------------------------------------------------------------------------
    state StartMoving
    {
    if(attackMode==amFireAtWill)
       	SetCannonFireMode(-1, enableFire);
    return Moving,10;
    }
    //--------------------------------------------------------------------------
    state Moving
    {
     if (IsMoving())
        {
        if(GetAttacker()!=null && attackMode==amReturnFire)
            {
            SetTarget(GetAttacker());
            CannonFireToTarget(-2, m_uTarget, -1);
            ClearAttacker();
            m_uTarget=null;
            }
        return Moving;
        }
    else
        {
        EndState(); 
        return Idle;
        }
    }
    //--------------------------------------------------------------------------
    
    function int ResetPatrol()
    {
    m_nPatrolPtCount = 0;
    m_nCurrentPatrolPt = 0;
    return 1;
    }
    
    //--------------------------------------------------------------------------
    
    function int ResetState (unit uTarget, int bResetEscort)
    {
    ResetAttack (uTarget);
    if (bResetEscort)
        ResetEscort ();
    }
    
    //--------------------------------------------------------------------------
    
    function int SetNextPatrolPt(int x, int y, int z)
    {
    m_nNextPatrolGx = x;
    m_nNextPatrolGy = y;
    m_nNextPatrolLz = z;
    return 1;
    }
    //--------------------------------------------------------------------------
    
    function int NextPatrolPt()
    {
    if (m_nPatrolPtCount < 2)
      	return 0;
  m_nCurrentPatrolPt = (m_nCurrentPatrolPt + 1) % m_nPatrolPtCount;
    if (m_nCurrentPatrolPt == 0)
      	{
      	m_nNextPatrolGx = m_nPatrolPt1Gx;
      	m_nNextPatrolGy = m_nPatrolPt1Gy;
      	m_nNextPatrolLz = m_nPatrolPt1Lz;
      	}
    else if (m_nCurrentPatrolPt == 1)
		{
		m_nNextPatrolGx = m_nPatrolPt2Gx;
		m_nNextPatrolGy = m_nPatrolPt2Gy;
		m_nNextPatrolLz = m_nPatrolPt2Lz;
		}
    else if (m_nCurrentPatrolPt == 2)
		{
		m_nNextPatrolGx = m_nPatrolPt3Gx;
		m_nNextPatrolGy = m_nPatrolPt3Gy;
		m_nNextPatrolLz = m_nPatrolPt3Lz;
		}
    else if (m_nCurrentPatrolPt == 3)
		{
		m_nNextPatrolGx = m_nPatrolPt4Gx;
		m_nNextPatrolGy = m_nPatrolPt4Gy;
		m_nNextPatrolLz = m_nPatrolPt4Lz;
		}
    else if (m_nCurrentPatrolPt == 4)
		{
		m_nNextPatrolGx = m_nPatrolPt5Gx;
		m_nNextPatrolGy = m_nPatrolPt5Gy;
		m_nNextPatrolLz = m_nPatrolPt5Lz;
		}
    else if (m_nCurrentPatrolPt == 5)
		{
		m_nNextPatrolGx = m_nPatrolPt6Gx;
		m_nNextPatrolGy = m_nPatrolPt6Gy;
		m_nNextPatrolLz = m_nPatrolPt6Lz;
		}
    else if (m_nCurrentPatrolPt == 6)
		{
		m_nNextPatrolGx = m_nPatrolPt7Gx;
		m_nNextPatrolGy = m_nPatrolPt7Gy;
		m_nNextPatrolLz = m_nPatrolPt7Lz;
		}
    else if (m_nCurrentPatrolPt == 7)
		{
		m_nNextPatrolGx = m_nPatrolPt8Gx;
		m_nNextPatrolGy = m_nPatrolPt8Gy;
		m_nNextPatrolLz = m_nPatrolPt8Lz;
		}
    else if (m_nCurrentPatrolPt == 8)
		{
		m_nNextPatrolGx = m_nPatrolPt9Gx;
		m_nNextPatrolGy = m_nPatrolPt9Gy;
		m_nNextPatrolLz = m_nPatrolPt9Lz;
		}
    else if (m_nCurrentPatrolPt == 9)
		{
		m_nNextPatrolGx = m_nPatrolPt10Gx;
		m_nNextPatrolGy = m_nPatrolPt10Gy;
		m_nNextPatrolLz = m_nPatrolPt10Lz;
		}
/*Trace>>>    
	if (TraceMode (tmPatrol))
    	{
    	TraceD ("next patrol point #");
    	TraceD (m_nCurrentPatrolPt);
    	TraceD (" @");
    	TraceD (m_nNextPatrolGx);
    	TraceD (",");
    	TraceD (m_nNextPatrolGy);
    	TraceD ("\n");
    	}
<<<Trace*/
    return 1;
    }
    
    //--------------------------------------------------------------------------
	// new DM/231100
    function int AddPatrolPt (int nNewPatrolPtX, int nNewPatrolPtY, int nNewPatrolPtZ)
    {
    if (m_nPatrolPtCount == m_nMaxPatrolPtCount)
        {
/*Trace>>>
        if (TraceMode (tmPatrol))
            TraceD ("Max. # Patrouillenpunkte erreicht\n");        
<<<Trace*/
        return 0;
        }
    ++m_nPatrolPtCount;
    if (m_nPatrolPtCount == 1)
		{
		m_nPatrolPtCount = 2;
		m_nPatrolPt1Gx = GetLocationX();
		m_nPatrolPt1Gy = GetLocationY();
		m_nPatrolPt1Lz = GetLocationZ();
		m_nPatrolPt2Gx = nNewPatrolPtX;
		m_nPatrolPt2Gy = nNewPatrolPtY;
		m_nPatrolPt2Lz = nNewPatrolPtZ;
		m_nNextPatrolGx = m_nPatrolPt2Gx;
		m_nNextPatrolGy = m_nPatrolPt2Gy;
		m_nNextPatrolLz = m_nPatrolPt2Lz;
		m_nCurrentPatrolPt = 1;
/*Trace>>>    
		if (TraceMode (tmPatrol))
	    	{
	    	TraceD ("initial patrol point");
	    	TraceD (m_nPatrolPt1Gx);
	    	TraceD (",");
	    	TraceD (m_nPatrolPt1Gy);
	    	TraceD ("\n");
	    	}
<<<Trace*/
		}
    else if (m_nPatrolPtCount == 3)
		{
		m_nPatrolPt3Gx = nNewPatrolPtX;
		m_nPatrolPt3Gy = nNewPatrolPtY;
		m_nPatrolPt3Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 4)
		{
		m_nPatrolPt4Gx = nNewPatrolPtX;
		m_nPatrolPt4Gy = nNewPatrolPtY;
		m_nPatrolPt4Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 5)
		{
		m_nPatrolPt5Gx = nNewPatrolPtX;
		m_nPatrolPt5Gy = nNewPatrolPtY;
		m_nPatrolPt5Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 6)
		{
		m_nPatrolPt6Gx = nNewPatrolPtX;
		m_nPatrolPt6Gy = nNewPatrolPtY;
		m_nPatrolPt6Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 7)
		{
		m_nPatrolPt7Gx = nNewPatrolPtX;
		m_nPatrolPt7Gy = nNewPatrolPtY;
		m_nPatrolPt7Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 8)
		{
		m_nPatrolPt8Gx = nNewPatrolPtX;
		m_nPatrolPt8Gy = nNewPatrolPtY;
		m_nPatrolPt8Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 9)
		{
		m_nPatrolPt9Gx = nNewPatrolPtX;
		m_nPatrolPt9Gy = nNewPatrolPtY;
		m_nPatrolPt9Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 10)
		{
		m_nPatrolPt10Gx = nNewPatrolPtX;
		m_nPatrolPt10Gy = nNewPatrolPtY;
		m_nPatrolPt10Lz = nNewPatrolPtZ;
		}
/*Trace>>>    
	if (TraceMode (tmPatrol))
    	{
    	TraceD ("new patrol point #");
    	TraceD (m_nPatrolPtCount);
    	TraceD (" @");
    	TraceD (nNewPatrolPtX);
    	TraceD (",");
    	TraceD (nNewPatrolPtY);
    	TraceD (", current is #");
    	TraceD (m_nCurrentPatrolPt);
    	TraceD ("\n");
    	}
<<<Trace*/
    return 1;
    }
    
    //--------------------------------------------------------------------------
    function int GetEscortedUnit ()
    {
    if (!m_uEscorted || !m_uEscorted.IsLive() || IsEnemy (m_uEscorted))
    	{
    	while (m_nNumEscorted && !m_uEscorted)
    		{
		    m_uEscorted = m_uEscorted1;
	    	m_uEscorted1 = m_uEscorted2;
	    	m_uEscorted2 = m_uEscorted3;
	    	m_uEscorted3 = m_uEscorted4;
	    	m_uEscorted4 = m_uEscorted5;
	    	m_uEscorted5 = m_uEscorted6;
	    	m_uEscorted6 = m_uEscorted7;
	    	m_uEscorted7 = m_uEscorted8;
	    	--m_nNumEscorted;
	    	}
	    }
    return (m_uEscorted != null);
    if (!m_uEscorted)
    	return false;
   	m_nEscortedGx = m_uEscorted.GetLocationX();
	m_nEscortedGy = m_uEscorted.GetLocationY();
	return true;
    }
    
    //--------------------------------------------------------------------------
    
    function int HaveEscortedUnit (unit uEscorted)
    {
    if (m_nNumEscorted < 1)
    	return false;
    if (uEscorted == m_uEscorted1)
    	return true;
    if (m_nNumEscorted < 2)
    	return false;
    if (uEscorted == m_uEscorted2)
    	return true;
    if (m_nNumEscorted < 3)
    	return false;
    if (uEscorted == m_uEscorted3)
    	return true;
    if (m_nNumEscorted < 4)
    	return false;
    if (uEscorted == m_uEscorted4)
    	return true;
    if (m_nNumEscorted < 5)
    	return false;
    if (uEscorted == m_uEscorted5)
    	return true;
    if (m_nNumEscorted < 6)
    	return false;
    if (uEscorted == m_uEscorted6)
    	return true;
    if (m_nNumEscorted < 7)
    	return false;
    if (uEscorted == m_uEscorted7)
    	return true;
    if (m_nNumEscorted < 8)
    	return false;
    if (uEscorted == m_uEscorted8)
    	return true;
    return false;
    }
    
    //--------------------------------------------------------------------------
    
    function int AddEscortedUnit (unit uEscorted)
    {
    if ((m_nNumEscorted >= 8) || HaveEscortedUnit (uEscorted))
    	return 0;
    ++m_nNumEscorted;
    if (m_nNumEscorted == 1)
    	m_uEscorted1 = uEscorted;
    else if (m_nNumEscorted == 2)
    	m_uEscorted2 = uEscorted;
    else if (m_nNumEscorted == 3)
    	m_uEscorted3 = uEscorted;
    else if (m_nNumEscorted == 4)
    	m_uEscorted4 = uEscorted;
    else if (m_nNumEscorted == 5)
    	m_uEscorted5 = uEscorted;
    else if (m_nNumEscorted == 6)
    	m_uEscorted6 = uEscorted;
    else if (m_nNumEscorted == 7)
    	m_uEscorted7 = uEscorted;
    else if (m_nNumEscorted == 8)
    	m_uEscorted8 = uEscorted;
    m_uEscorted = m_uEscorted1;
    return 1;
    }

    //--------------------------------------------------------------------------
    function int NextEscortedUnit ()
    {
    m_uEscorted1 = null;
    if (m_nNumEscorted > 1)
    	m_uEscorted1 = m_uEscorted2;
    if (m_nNumEscorted > 2)
    	m_uEscorted2 = m_uEscorted3;
    if (m_nNumEscorted > 3)
    	m_uEscorted3 = m_uEscorted4;
    if (m_nNumEscorted > 4)
    	m_uEscorted4 = m_uEscorted5;
    if (m_nNumEscorted > 5)
    	m_uEscorted5 = m_uEscorted6;
    if (m_nNumEscorted > 6)
    	m_uEscorted6 = m_uEscorted7;
    if (m_nNumEscorted > 7)
    	m_uEscorted7 = m_uEscorted8;
    --m_nNumEscorted;
    m_uEscorted = m_uEscorted1;
    return (m_nNumEscorted > 0);
    }
    
    //--------------------------------------------------------------------------
	// new DM/231100
	state BeginPatrol
	{
    if (m_nPatrolPtCount < 2)
    	return Idle;
	m_nReturnToGx = -1;
    SetCannonFireMode(-1, disableFire);
    CallMoveToPoint(m_nNextPatrolGx, m_nNextPatrolGy, m_nNextPatrolLz);
    return Patrol;
	}
    //--------------------------------------------------------------------------
    state Patrol
    {
    if(m_uTarget)
	    {
		if (!AttackTargetValid())
	        {
	        StopCannonFire(-1);
	        SetTarget(null);
	        }
	    else
	    	{
	        if(GoToTarget())
	            return Patrol,2;
	        CannonFireToTarget(-2, m_uTarget, -1);
	        return Patrol;
	    	}
	    }
    else
        FindBestTarget();
    
    if (!IsMoving())
    	{
    	if (!NextPatrolPt ())
    		{
    		NextCommand (1);
    		return Idle;
    		}
       	CallMoveToPoint(m_nNextPatrolGx, m_nNextPatrolGy, m_nNextPatrolLz);
    	}
    return Patrol;
    }
    //--------------------------------------------------------------------------
    //modified DM/241100
    //changes escort behaviour as follows:
    //primarily attack attacker of escorted unit
    //if no attacker, find another target
    //if other target found, attack only if in range
    state Escort
    {
    	int	 nTgtDist;
//    	unit uAttacker;
    	int	 nEscortGx;
    	int  nEscortGy;
    	int  nEscortLz;
    	int  nDx;
    	int  nDy;
    	int	nFiringRange;
    	
    // check escorted unit's state
   	GetEscortedUnit();
    if (!m_uEscorted)
    	{
    	m_uAttacker = null;
        if(IsMoving())
        	{
            CallStopMoving;
            return Escort;
        	}
        EndState();
    	return Idle;
    	}
    	
    // check escorted unit's attacker with escort's current target
    TryForceNewAttacker (m_uEscorted);
    if (!m_uTarget || ((m_uAttacker != null) && (m_uTarget != m_uAttacker)))
        StopCannonFire(-1);
    if (m_uAttacker)
    	m_uTarget = m_uAttacker;
    else if (!m_uTarget)
        FindBestTarget();
	SetTarget (m_uTarget);
	        
	m_nEscortedGx = m_uEscorted.GetLocationX();    
	m_nEscortedGy = m_uEscorted.GetLocationY();    
	nEscortGx = GetLocationX();    
	nEscortGy = GetLocationY();    
    // check distance to target
    if (m_uTarget)
    	{
    	if (m_uAttacker)	// attack regardless of distance
    		{
    		nTgtDist = 0;
    		nFiringRange = 1;
    		}
    	else	// attack only if in range
    		{
    	    m_nTargetGx = m_uTarget.GetLocationX();
	        m_nTargetGy = m_uTarget.GetLocationY();
			nTgtDist = Distance (m_nEscortedGx, m_nEscortedGy, nEscortGx, nEscortGy);
			nFiringRange = GetFiringRange() % 65536;
			}
        if (nTgtDist <= nFiringRange * 2)
        	{
            if(GoToTarget())
                return Escort,2;
            else
                {
                CannonFireToTarget(-2, m_uTarget, -1);
                return Escort;
	            }
            }
        SetTarget (null);	// target too far away
        m_uTarget = null;
    	}

	nEscortLz = GetLocationZ();    
    if (nEscortGx < m_nEscortedGx - 2)
    	nEscortGx = m_nEscortedGx - 2;
    else if (nEscortGx > m_nEscortedGx + 2)
    	nEscortGx = m_nEscortedGx + 2;
   	else
   		nDx = 0;
    if (nEscortGy < m_nEscortedGy - 2)
    	nEscortGy = m_nEscortedGy - 2;
    else if (nEscortGy > m_nEscortedGy + 2)
    	nEscortGy = m_nEscortedGy + 2;
   	else
   		nDy = 0;
   	if ((nEscortGx != m_nEscortedGx) || (nEscortGy != m_nEscortedGy))
   		{
        CallMoveToPoint(nEscortGx, nEscortGy, m_uEscorted.GetLocationZ());
        }
    else if(IsMoving())
        CallStopMoving();
    return Escort;
    }
    
    //------------------------------------------------------- 
    state Frozen
    {
        if (IsFroozen() || IsMoving())
        {
            state Frozen;
        }
        else
        {
            //!!wrocic do tego co robilismy
            if(m_nState==1)
                return AttackingPoint;
            
            if(m_nState==2)
                return Attacking;
            
            if(m_nState==3)
            {
                if(attackMode==amFireAtWill) SetCannonFireMode(-1, enableFire);
                MoveToDestination();
                return StartMoving;
            }
            
            if(m_nState==4)
                return Patrol;
            
            if(m_nState==5)
                return Escort;
            
            if(m_nState==6)
                return InPlatoonState;
            
            state Idle;
        }
    }
    
    //********************************************************
    //*********** E V E N T S ****************************
    //********************************************************
    // zwracaja true
    // false jak nie ma 
    // modified DM/211100
    // OnHit will cause a unit which is set to "return fire" to return fire to its attacker, if
    // a) it currently has no target
    // b) the new attacker is an air unit, the unit's current target is not an air unit and the
    //    unit has anti-air weaponry.
    // OnHit will readjust the targets of an attacked unit which is set to "fire at will" to possibly
    // return fire by calling FindBestTarget().
    // This modification takes care of attacking aircraft (esp. heavy bombers) first, since they
    // are a deadly threat to any ground force.
    
    event OnHit()
	{
		unit uAttacker;
	
    uAttacker = GetAttacker();
    if (!m_uTarget)
       	SetTarget(uAttacker);
    else if (m_uTarget != uAttacker)
    	{
        if (attackMode != amHoldFire)	//fire at will
	        {
	        if (uAttacker.IsHelicopter() && !m_uTarget.IsHelicopter() && CanCannonFireToAircraft(-1))
	        	SetTarget(uAttacker);
	        else if (attackMode != amReturnFire)
	        	{
	        	if (!FindBestTarget())
    	        	SetTarget(uAttacker);
    	        }
    	    }
    	}
    if ((m_uTarget != null) && (attackMode != amHoldFire))
     	CannonFireToTarget(-2, m_uTarget, -1);
    if (ForceRetreat ())
        state Retreat;
    true;
    }
    //------------------------------------------------------- 
    event OnCannonLowAmmo(int nCannonNum)
    {
        SendSupplyRequest();
        true;
    }
    //------------------------------------------------------- 
    event OnCannonNoAmmo(int nCannonNum)
    {
    if(retreatMode == rmAmmo)
        {
        m_nDamper = 0;
        state Retreat;
        }
    true;
    }
    //------------------------------------------------------- 
    event OnCannonFoundTarget(int nCannonNum, unit uTarget)
    {
    if(GetCannonType(nCannonNum) == cannonTypeIon)
        if(uTarget.IsDisabled())
            return true;
    if(attackMode!=amFireAtWill)//hold fire | return fire
        return true;
    return false;//gdyby zwrocic true to dzialko nie strzeli
    }
    //------------------------------------------------------- 
    event OnCannonEndFire(int nCannonNum, int nEndStatus)//gdy zniszczony, poza zasiegiem lub brak ammunicji
    {
    false;
    }
    //------------------------------------------------------- 
    event OnFreezeForSupplyOrRepair(int nFreezeTicks)
    {
    if(state!=Frozen) m_nState = 0;
    if(state==AttackingPoint)
        m_nState=1;
    if(state==Attacking)
        m_nState=2;
    if((state==Moving) || (state==StartMoving))
        m_nState=3;
    if(state==Patrol)
        m_nState=4;
    if(state==Escort)
        m_nState=5;
    if(state==InPlatoonState)
        m_nState=6;
    CallFreeze(nFreezeTicks);
    state Frozen;
    true;
    }
    //------------------------------------------------------- 
    event OnTransportedToNewWorld()
    {
    ResetPatrol ();
    StopCannonFire(-1);
    SetCannonFireMode(-1, disableFire);
    SetTarget(null);
    m_uSpecialUnit = null;
    }
    //------------------------------------------------------- 
    event OnConvertedToNewPlayer()
    {
    ResetPatrol ();
    StopCannonFire(-1);
    SetCannonFireMode(-1, disableFire);
    SetTarget(null);
    m_uSpecialUnit = null;
    ClearAttacker();
    state Idle;
    }
    
    //--------------------------------------------------------------------------
    //********************************************************
    //*********** C O M M A N D S ****************************
    //********************************************************
    command Initialize()
    {
    m_nCannonsCount = GetCannonsCount();
	m_nTgtRelPos = 0;
/*Trace>>>
    eTraceMode = 0;
<<<Trace*/
    movementMode=mmHoldArea;
    attackDistance = adCautious;
    SetCannonFireMode(-1, disableFire);
    m_nGatherGx = -1;
    m_nRetreatGx = -1;
    m_nTgtRelPos = 0;
    m_bIncToggle = 0;
   	retreatMode = rmHP50;
	ResetState (stIdle, null);
    }
    //--------------------------------------------------------------------------
    command Uninitialize()
    {
    //wykasowac referencje
    SetTarget(null);
    m_uSpecialUnit = null;
    ResetPatrol();
    ResetAttack(null);
    ResetEscort();
    }
    //--------------------------------------------------------------------------
    command SetLights(int nMode) button lights description "translateCommandStateLightsModeDescription" hotkey priority 204
    {
    if (nMode == -1)
	    {
        lights = (lights + 1) % 3;
    	}
    else
    	{
        assert(nMode == 0);
        lights = nMode;
    	}
    SetLightsMode(lights);
    NextCommand(0);
    }
    //--------------------------------------------------------------------------
    command SetMovementMode(int nMode) button movementMode description "translateCommandStateMovementDescription"priority 205
    {
    if (nMode == -1)
	    {
        movementMode = (movementMode + 1) % mmCount;
    	}
    else
    	{
        assert(nMode == 0);
        movementMode = nMode % mmCount;
    	}
    NextCommand(0);
    }
    //--------------------------------------------------------------------------
    command SetAttackMode(int nMode) button attackMode description "translateCommandStateFireModeDescription" hotkey priority 6
    {
    if (nMode == -1)
    	{
        attackMode = (attackMode + 1) % 3;
    	}
    else
    	{
        assert(nMode == 0);
        attackMode = nMode % 3;
    	}
    if(attackMode!=0)
        {
        SetCannonFireMode(-1, disableFire);
        StopCannonFire(-1);
	    }
    }
    //--------------------------------------------------------------------------
    command UserOneParam1(int nMode) button searchMode description "translateCommandStateTargetingDescription" priority 8
    {
    if (nMode == -1)
    	{
        searchMode = (searchMode + 1) % 2;
    	}
    else
    	{
        assert(nMode == 0);
        searchMode = nMode;
    	}
    }
    //--------------------------------------------------------------------------
    command UserOneParam2(int nMode) button retreatMode description "translateCommandStateretreatModeDescription" priority 12
    {
    if (nMode == -1)
	    {
        retreatMode = (retreatMode + 1) % rmNum;
    	}
    else
	    {
        assert(nMode == 0);
        retreatMode = nMode;
	    }
    }
    
    //--------------------------------------------------------------------------
    command UserOneParam3(int nMode) button attackDistance description "translateCommandStateAttackDistance" priority 206
    {
    if (nMode == -1)
        attackDistance = (attackDistance + 1) % adNum;
    else
        attackDistance = nMode % adNum;
    }
    
    //--------------------------------------------------------------------------
    command Stop() button "translateCommandStop" description "translateCommandStopDescription" hotkey priority 20
    {
    ResetState (null, true);
    SetDestToCurPos ();
    if(IsMoving())
        CallStopMoving();
    SetCannonFireMode(-1, disableFire);
    state Idle;
    }
    //--------------------------------------------------------------------------
    command HoldPosition() hidden button "translateCommandHoldPosition" description "translateCommandStopDescription" hotkey priority 20
    {
    ResetState (null, true);
    SetDestToCurPos ();
    if(IsMoving())
        CallStopMoving();
    movementMode=mmHoldPos;
    SetCannonFireMode(-1, disableFire);
    ChangedCommandValue();
    state Idle;
    }
    //--------------------------------------------------------------------------
    command Move(int nGx, int nGy, int nLz) button "translateCommandMove" description "translateCommandMoveDescription" hotkey priority 21
    {
    ResetState (null, true);
    m_nDestGx = nGx;
    m_nDestGy = nGy;
    m_nDestLz = nLz;
    if (m_nGatherGx < 0)
    	{
	    m_nGatherGx = nGx;
	    m_nGatherGy = nGy;
	    m_nGatherLz = nLz;
	    }
    if(attackMode==0)
        SetCannonFireMode(-1, enableFire);
    MoveToDestination();
    state StartMoving;
    }
     //--------------------------------------------------------------------------
    command Attack(unit uTarget) button "translateCommandAttack" description "translateCommandAttackDescription" hotkey priority 22
    {
/*Trace>>>    
	if (TraceMode (tmAttack))
        TraceD("Receiving new attack target                      \n");
<<<Trace*/
    ResetState (uTarget, true);
    bFirstShoot=true;
    if ((attackMode==0) || (attackMode == 3))
        SetCannonFireMode(-1, enableFire);
    AllowScriptWithdraw(true);
    if(state==Frozen)
    	{
        m_nState = 2;
        }
     else
        {
        state Attacking;
        }
    }
    
     //--------------------------------------------------------------------------
    /*komenda nie wystawiana na zewnatrz*/
    command AttackOnPoint(int nX, int nY, int nZ) hidden button "translateCommandAttack" 
    {
    SetTarget(null);
    m_nTargetGx = nX;
    m_nTargetGy = nY;
    m_nTargetLz = nZ;
    AllowScriptWithdraw(true);
    SetCannonFireMode(-1, disableFire);
    if(state==Frozen)
    	{
        m_nState = 1;
        }
    else
    	{
        state AttackingPoint;
        }
    }
    //--------------------------------------------------------------------------
    command SendSupplyRequest() button "translateCommandSupply" description "translateCommandSupplyDescription" hotkey priority 26
    {
    SendSupplyRequest();
    }
    //--------------------------------------------------------------------------
    command Patrol(int nGx, int nGy, int nLz) button "translateCommandPatrol" description "translateCommandPatrolDescription" hotkey priority 27
    {
    ResetState (null, true);
	AddPatrolPt (nGx, nGy, nLz);
    state BeginPatrol;
    }
    
    //--------------------------------------------------------------------------
    command UserNoParam0() button "translateCommandResetPatrol" description "translateCommandResetPatrolDescription" hotkey priority 28
    {
    ResetPatrol ();
    NextCommand (1);
    }
    
    //--------------------------------------------------------------------------
    command UserNoParam1() button "translateCommandRestartPatrol" description "translateCommandRestartPatrolDescription" hotkey priority 29
    {
    ResetState (null, true);
    state BeginPatrol;
    }
    
     //--------------------------------------------------------------------------
    command UserPoint9(int nGx, int nGy, int nLz) button "translateCommandSetGatherPoint" description "translateCommandSetGatherPointDescription" hotkey priority 51
    {
    m_nGatherGx = nGx;
    m_nGatherGy = nGy;
    m_nGatherLz = nLz;
    NextCommand (1);
    }
    
    //--------------------------------------------------------------------------
    command UserNoParam2() button "translateCommandRetreat" description "translateCommandRetreatDescription" hotkey priority 25
    {
    ResetState (null, true);
    m_nDamper = 0;
    state Retreat;
    }
    
    //--------------------------------------------------------------------------
    command Escort(unit uUnit) button "translateCommandEscort" description "translateCommandEscortDescription" hotkey priority 31 
    {
    ResetState (null, false);
    AddEscortedUnit (uUnit);
    state Escort;
    }
    
    //--------------------------------------------------------------------------
    command Enter(unit uEntrance) hidden button "translateCommandEnter"
    {
    ResetState (null, true);
    CallMoveInsideObject(uEntrance);
    m_nTargetGx = GetEntranceX(uEntrance);
    m_nTargetGy = GetEntranceY(uEntrance);
    m_nTargetLz = GetEntranceZ(uEntrance);
    SetCannonFireMode(-1, disableFire);
    state StartMoving;
    }
    
    //-------------------------------------------------------
    command SpecialChangeUnitsScript() button "translateCommandChangeScript" description "translateCommandChangeScriptDescription" hotkey priority 254 
    {
        //special command - no implementation
    }
    //--------------------------------------------------------------------------
/*Trace>>>    
	// toggle trace mode
	command UserOneParam9(int nMode) button eTraceMode description "translateCommandExtTraceModeDescription" priority 255
    {
    if (nMode == -1)
 	   eTraceMode = (eTraceMode + 1) % tmNum;
    else
	    {
    	assert(nMode == 0);
    	eTraceMode = nMode % tmNum;
    	}
    TraceD ("trace mode is ");
    if (eTraceMode == tmAll)
    	TraceD ("ALL");
    else if (eTraceMode == tmPatrol)
    	TraceD ("PATROL");
    else if (eTraceMode == tmEscort)
    	TraceD ("ESCORT");
    else if (eTraceMode == tmAttack)
    	TraceD ("ATTACK");
    else
    	TraceD ("OFF");
    TraceD ("                                    \n");
    }
<<<Trace*/
    //--------------------------------------------------------------------------
}

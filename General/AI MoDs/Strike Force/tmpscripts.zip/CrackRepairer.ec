// changes by Dietfrid Mali (Diedel) 23 nov 2000
// Extended patrol mode
//		up to 10 patrol points per unit
//		restart patrol without having to set all patrol points again
//		delete all patrol points if a new patrol route is desired
// Escort mode
// Script name: "Instandsetzung (Elite)"
// new escort control button "Eskorte"
// renamed state Nothing to state Idle

repairer "translateScriptNameCrackRepairerv12"
{
    consts
    {
        // states
        stIdle = 0;
        stMove = 1;
        stPatrol = 2;
        stEscort = 3;
        stRetreat = 4;

        findTargetWaterUnit     = 1;
        findTargetFlyingUnit    = 2;
        findTargetNormalUnit    = 4;
        findTargetBuildingUnit  = 8;
        findTargetAnyUnit       = 15;
        
        //typ rasy (jakich IFF'ow szukamy
        findEnemyUnit       = 1;
        findAllyUnit        = 2;
        findNeutralUnit     = 4;
        findOurUnit         = 8;
        
        //kryterium szukania
        findDisabledUnit    = 8;
        findDamagedUnit     = 16;
        //typ szukanego obiektu
        findDestinationCivilUnit    = 1;
        findDestinationArmedUnit    = 2;
        findDestinationRepairerUnit = 4;
        findDestinationSupplyUnit   = 8;
        findDestinationAnyUnit      = 15;
        
        operationRepair = 0;
        operationCapture = 1;
        operationRepaint = 2;
        operationUpgrade = 3;

		// retreat modes        
        rmNone = 0;
        rmHP66 = 1;
        rmHP50 = 2;
        rmHP25 = 3;
        rmNum = 4;

	    cAttackerMaxDist = 15;
    }
    
    int  m_nMoveToX;
    int  m_nMoveToY;
    int  m_nMoveToZ;
    unit m_uTarget;
    int m_nCurrOperation;//0-repairing, 1-converting, 2-repainting, 3-upgrading
    int m_nRepaintSideColor;
    int  m_nStayX;
    int  m_nStayY;
    int  m_nStayZ;

    int	 m_nGatherGx;
    int	 m_nGatherGy;
    int	 m_nGatherLz;
    
    int	 m_nRetreatGx;
    int	 m_nRetreatGy;
    int  m_nDamper;
    
    int  m_nReturnToGx;
    int  m_nReturnToGy;
    
    int  m_nState;
    
    int  m_nNextPatrolGx;
    int  m_nNextPatrolGy;
    int  m_nNextPatrolLz;
    int  m_nPatrolPt1Gx;
    int  m_nPatrolPt1Gy;
    int  m_nPatrolPt1Lz;
    int  m_nPatrolPt2Gx;
    int  m_nPatrolPt2Gy;
    int  m_nPatrolPt2Lz;
    int  m_nPatrolPt3Gx;
    int  m_nPatrolPt3Gy;
    int  m_nPatrolPt3Lz;
    int  m_nPatrolPt4Gx;
    int  m_nPatrolPt4Gy;
    int  m_nPatrolPt4Lz;
    int  m_nPatrolPt5Gx;
    int  m_nPatrolPt5Gy;
    int  m_nPatrolPt5Lz;
    int  m_nPatrolPt6Gx;
    int  m_nPatrolPt6Gy;
    int  m_nPatrolPt6Lz;
    int  m_nPatrolPt7Gx;
    int  m_nPatrolPt7Gy;
    int  m_nPatrolPt7Lz;
    int  m_nPatrolPt8Gx;
    int  m_nPatrolPt8Gy;
    int  m_nPatrolPt8Lz;
    int  m_nPatrolPt9Gx;
    int  m_nPatrolPt9Gy;
    int  m_nPatrolPt9Lz;
    int  m_nPatrolPt10Gx;
    int  m_nPatrolPt10Gy;
    int  m_nPatrolPt10Lz;
    int  m_nPatrolPtCount;
    int  m_nMaxPatrolPtCount;
    int  m_nCurrentPatrolPt;
    int  m_bPatrolling;
    int  m_bEscorting;
    
    int  m_nEscortedGx;
    int  m_nEscortedGy;
    int  m_nEscortedLz;
    int  m_nTargetGx;
    int  m_nTargetGy;
    int  m_nTargetLz;
    
    unit m_uEscorted;
    unit m_uEscorted1;
    unit m_uEscorted2;
    unit m_uEscorted3;
    unit m_uEscorted4;
    unit m_uEscorted5;
    unit m_uEscorted6;
    unit m_uEscorted7;
    unit m_uEscorted8;
    int	 m_nCurEscorted;
    int  m_nNumEscorted;
    
    enum retreatMode
    {
        "translateCommandStateNoRetreat",
        "translateCommandStateRetreatHP66",
        "translateCommandStateRetreatHP50",
        "translateCommandStateRetreatHP25",
multi:
        "translateCommandStateRetreatMode"
    }
    
    enum lights
    {
        "translateCommandStateLightsAUTO",
        "translateCommandStateLightsON",
        "translateCommandStateLightsOFF",
multi:
        "translateCommandStateLightsMode"
    }
    
    enum traceMode
    {
        "translateCommandStateTraceOFF",
        "translateCommandStateTraceON",
multi:
        "translateCommandStateTraceMode"
    }        
    
    enum repairMode
    {
        "translateCommandStateDontRepair",
        "translateCommandStateAutoRepair",
multi:
        "translateCommandStateRepairMode"
    }
    enum captureMode
    {
        "translateCommandStateDontCapture",
        "translateCommandStateAutoCapture",
multi:
        "translateCommandStateCaptureMode"
    }
    enum upgradeWeaponsMode
    {
        "translateCommandStateUpgradeWeapons",
        "translateCommandStateDontUpgradeWeapons",
multi:
        "translateCommandStateUpgradeWeaponsMode"
    }
    enum upgradeChasisMode
    {
        "translateCommandStateUpgradeChasis",
        "translateCommandStateDontUpgradeChasis",
multi:
        "translateCommandStateUpgradeChasisMode"
    }
    enum upgradeShieldMode
    {
        "translateCommandStateUpgradeShield",
        "translateCommandStateDontUpgradeShield",
multi:
        "translateCommandStateUpgradeShieldMode"
    }
    
    state Initialize;
    state Idle;
    state RestoreState;
    state StartMoving;
    state Moving;
    state MovingToTarget;
    state Repairing;
    state Converting;
    state Repainting;
    state Upgrading;
    state BeginPatrol;
    state Patrol;
    state Escort;
    state Retreat;
        

    //********************************************************
    //********* F U N C T I O N S ****************************
    //********************************************************
    //--------------------------------------------------------------------------
    
    function int ResetEscort()
    {
    m_uEscorted = null;
    m_nCurEscorted = 0;
    m_nNumEscorted = 0;
    return 1;
    }
    
    //-------------------------------------------------------
    // new DM/231100
    function int ResetState (int nNewState)
    {
    m_nReturnToGx = -1;
    if (nNewState != stEscort)
        ResetEscort ();
    m_nState = nNewState;
    }
    //-------------------------------------------------------
    // new DM/231100
    function int SaveState ()
    {
    if(state==Moving)
        m_nState = stMove;
    else if(state==Patrol)
        m_nState = stPatrol;
    else if(state==Escort)
        m_nState = stEscort;
    else
    	m_nState = stIdle;
    return m_nState;
    }
    //-------------------------------------------------------
    function int GatherUnits ()
    {
    if ((m_nGatherGx >= 0) && ((GetLocationX() != m_nGatherGx) || (GetLocationY() != m_nGatherGy)))
    	{
		CallMoveToPoint (m_nGatherGx, m_nGatherGy, m_nGatherLz);
		return 1;
		}
	return 0;
	}

    //------------------------------------------------------- 
    function int SetCurrentTarget(unit uTarget)
    {
        m_uTarget = uTarget;
        SetTargetObject(m_uTarget);
        return true;
    }
    
    function int FindTargetToRepair()
    {
        int i;
        int nTargetsCount;
        unit newTarget;
        
        
        BuildTargetsArray(findTargetWaterUnit|findTargetNormalUnit|findTargetBuildingUnit, findAllyUnit|findOurUnit,findDestinationAnyUnit);
        SortFoundTargetsArray();
        nTargetsCount=GetTargetsCount();
        if(nTargetsCount!=0)
        {
            StartEnumTargetsArray();
            for(i=0;i<nTargetsCount;i=i+1)
            {
                newTarget = GetNextTarget();
                                
                if(!newTarget.IsFroozen() && 
                                    CanBeRepaired(newTarget) && 
                                    (DistanceTo(newTarget.GetLocationX(),newTarget.GetLocationY())<6))
                                {
                          m_nMoveToX = GetOperateOnTargetLocationX(newTarget);
                      m_nMoveToY = GetOperateOnTargetLocationY(newTarget);
                        m_nMoveToZ = GetOperateOnTargetLocationZ(newTarget);

                                    if(IsGoodPointForOperateOnTarget(newTarget,m_nMoveToX,m_nMoveToY,m_nMoveToZ))
                                    {
                                            EndEnumTargetsArray();
                                            SetCurrentTarget(newTarget);
                                            return true;
                                    }
                                }
            }
            EndEnumTargetsArray();
            return false;
        }
        else
        {
            return false;
        }
    }
    
    function int FindTargetToCapture()
    {
        int i;
        int nTargetsCount;
        unit newTarget;
        
        BuildTargetsArray(findTargetWaterUnit|findTargetNormalUnit|findTargetBuildingUnit, findEnemyUnit,findDestinationAnyUnit);
        SortFoundTargetsArray();
        nTargetsCount=GetTargetsCount();
        
        if(nTargetsCount!=0)
        {
            StartEnumTargetsArray();
            for(i=0;i<nTargetsCount;i=i+1)
            {
                newTarget = GetNextTarget();
                if(CanBeConverted(newTarget) && (DistanceTo(newTarget.GetLocationX(),newTarget.GetLocationY())<7))
                                {
                          m_nMoveToX = GetOperateOnTargetLocationX(newTarget);
                      m_nMoveToY = GetOperateOnTargetLocationY(newTarget);
                        m_nMoveToZ = GetOperateOnTargetLocationZ(newTarget);

                                    if(IsGoodPointForOperateOnTarget(newTarget,GetOperateOnTargetLocationX(newTarget),GetOperateOnTargetLocationY(newTarget),GetOperateOnTargetLocationZ(newTarget)))
                                    {
                                            EndEnumTargetsArray();
                                            SetCurrentTarget(newTarget);
                                            return true;
                                    }
                                }
            }
            EndEnumTargetsArray();
            return false;
        }
        else
        {
            return false;
        }
    }
    
    //--------------------------------------------------------------------------
    
    function int ResetPatrol()
    {
    m_nPatrolPtCount = 0;
    m_nCurrentPatrolPt = 0;
    m_bPatrolling = false;
    return 1;
    }
    
    //--------------------------------------------------------------------------
    state Initialize
    {
    ResetState (stIdle);
    ResetPatrol ();
	retreatMode = rmHP50;
	m_nRetreatGx = -1;
	m_nGatherGx = -1;
	m_nDamper = 0;
    return Idle;
    }
    
    //------------------------------------------------------- 
    function int ForceRetreat ()
    {
    	int nCurHP;
    	int nMaxHP;
    	
    if (retreatMode < rmHP66)
    	return false;
    nCurHP = GetHP();
    nMaxHP = GetMaxHP();
    if (retreatMode == rmHP25)
    	nCurHP = 4 * nCurHP;
    else if (retreatMode == rmHP50)
    	nCurHP = 2 * nCurHP;
    else
    	nCurHP = (3 * nCurHP + 2) / 2;
    if (nCurHP > nMaxHP)
    	return false;
    m_nDamper = 0;
    if (m_nState != stIdle)
        SaveState ();
    if (m_nReturnToGx < 0)
        {
        m_nReturnToGx = GetLocationX();
        m_nReturnToGy = GetLocationX();
        }
    return true;
    }
    //--------------------------------------------------------------------------
    function int GetEscortedUnit ()
    {
    if (!m_uEscorted || !m_uEscorted.IsLive() || IsEnemy (m_uEscorted))
    	{
    	while (m_nNumEscorted && !m_uEscorted)
    		{
		    m_uEscorted = m_uEscorted1;
	    	m_uEscorted1 = m_uEscorted2;
	    	m_uEscorted2 = m_uEscorted3;
	    	m_uEscorted3 = m_uEscorted4;
	    	m_uEscorted4 = m_uEscorted5;
	    	m_uEscorted5 = m_uEscorted6;
	    	m_uEscorted6 = m_uEscorted7;
	    	m_uEscorted7 = m_uEscorted8;
	    	--m_nNumEscorted;
	    	}
	    }
    return (m_uEscorted != null);
    if (!m_uEscorted)
    	return false;
   	m_nEscortedGx = m_uEscorted.GetLocationX();
	m_nEscortedGy = m_uEscorted.GetLocationY();
	return true;
    }
    
    //--------------------------------------------------------------------------
    
    function int HaveEscortedUnit (unit uEscorted)
    {
    if (m_nNumEscorted < 1)
    	return false;
    if (uEscorted == m_uEscorted1)
    	return true;
    if (m_nNumEscorted < 2)
    	return false;
    if (uEscorted == m_uEscorted2)
    	return true;
    if (m_nNumEscorted < 3)
    	return false;
    if (uEscorted == m_uEscorted3)
    	return true;
    if (m_nNumEscorted < 4)
    	return false;
    if (uEscorted == m_uEscorted4)
    	return true;
    if (m_nNumEscorted < 5)
    	return false;
    if (uEscorted == m_uEscorted5)
    	return true;
    if (m_nNumEscorted < 6)
    	return false;
    if (uEscorted == m_uEscorted6)
    	return true;
    if (m_nNumEscorted < 7)
    	return false;
    if (uEscorted == m_uEscorted7)
    	return true;
    if (m_nNumEscorted < 8)
    	return false;
    if (uEscorted == m_uEscorted8)
    	return true;
    return false;
    }
    
    //--------------------------------------------------------------------------
    
    function int AddEscortedUnit (unit uEscorted)
    {
    if ((m_nNumEscorted >= 8) || HaveEscortedUnit (uEscorted))
    	return 0;
    ++m_nNumEscorted;
    if (m_nNumEscorted == 1)
    	m_uEscorted1 = uEscorted;
    else if (m_nNumEscorted == 2)
    	m_uEscorted2 = uEscorted;
    else if (m_nNumEscorted == 3)
    	m_uEscorted3 = uEscorted;
    else if (m_nNumEscorted == 4)
    	m_uEscorted4 = uEscorted;
    else if (m_nNumEscorted == 5)
    	m_uEscorted5 = uEscorted;
    else if (m_nNumEscorted == 6)
    	m_uEscorted6 = uEscorted;
    else if (m_nNumEscorted == 7)
    	m_uEscorted7 = uEscorted;
    else if (m_nNumEscorted == 8)
    	m_uEscorted8 = uEscorted;
    GetEscortedUnit();
    return 1;
    }

    //--------------------------------------------------------------------------
    
    function int NextPatrolPt()
    {
    if (!m_nPatrolPtCount)
      	return 0;
    m_nCurrentPatrolPt = (m_nCurrentPatrolPt + 1) % m_nPatrolPtCount;
    if (m_nCurrentPatrolPt == 0)
      	{
      	m_nNextPatrolGx = m_nPatrolPt1Gx;
      	m_nNextPatrolGy = m_nPatrolPt1Gy;
      	m_nNextPatrolLz = m_nPatrolPt1Lz;
      	}
    else if (m_nCurrentPatrolPt == 1)
		{
		m_nNextPatrolGx = m_nPatrolPt2Gx;
		m_nNextPatrolGy = m_nPatrolPt2Gy;
		m_nNextPatrolLz = m_nPatrolPt2Lz;
		}
    else if (m_nCurrentPatrolPt == 2)
		{
		m_nNextPatrolGx = m_nPatrolPt3Gx;
		m_nNextPatrolGy = m_nPatrolPt3Gy;
		m_nNextPatrolLz = m_nPatrolPt3Lz;
		}
    else if (m_nCurrentPatrolPt == 3)
		{
		m_nNextPatrolGx = m_nPatrolPt4Gx;
		m_nNextPatrolGy = m_nPatrolPt4Gy;
		m_nNextPatrolLz = m_nPatrolPt4Lz;
		}
    else if (m_nCurrentPatrolPt == 4)
		{
		m_nNextPatrolGx = m_nPatrolPt5Gx;
		m_nNextPatrolGy = m_nPatrolPt5Gy;
		m_nNextPatrolLz = m_nPatrolPt5Lz;
		}
    else if (m_nCurrentPatrolPt == 5)
		{
		m_nNextPatrolGx = m_nPatrolPt6Gx;
		m_nNextPatrolGy = m_nPatrolPt6Gy;
		m_nNextPatrolLz = m_nPatrolPt6Lz;
		}
    else if (m_nCurrentPatrolPt == 6)
		{
		m_nNextPatrolGx = m_nPatrolPt7Gx;
		m_nNextPatrolGy = m_nPatrolPt7Gy;
		m_nNextPatrolLz = m_nPatrolPt7Lz;
		}
    else if (m_nCurrentPatrolPt == 7)
		{
		m_nNextPatrolGx = m_nPatrolPt8Gx;
		m_nNextPatrolGy = m_nPatrolPt8Gy;
		m_nNextPatrolLz = m_nPatrolPt8Lz;
		}
    else if (m_nCurrentPatrolPt == 8)
		{
		m_nNextPatrolGx = m_nPatrolPt9Gx;
		m_nNextPatrolGy = m_nPatrolPt9Gy;
		m_nNextPatrolLz = m_nPatrolPt9Lz;
		}
    else if (m_nCurrentPatrolPt == 9)
		{
		m_nNextPatrolGx = m_nPatrolPt10Gx;
		m_nNextPatrolGy = m_nPatrolPt10Gy;
		m_nNextPatrolLz = m_nPatrolPt10Lz;
		}
    return 1;
    }
    
    //--------------------------------------------------------------------------
	// new DM/231100
    function int AddPatrolPt (int nNewPatrolPtX, int nNewPatrolPtY, int nNewPatrolPtZ)
    {
    if (m_nPatrolPtCount == m_nMaxPatrolPtCount)
      return 0;
    ++m_nPatrolPtCount;
    if (m_nPatrolPtCount == 1)
		{
		m_nPatrolPtCount = 2;
		m_nPatrolPt1Gx = GetLocationX();
		m_nPatrolPt1Gy = GetLocationY();
		m_nPatrolPt1Lz = GetLocationZ();
		m_nPatrolPt2Gx = nNewPatrolPtX;
		m_nPatrolPt2Gy = nNewPatrolPtY;
		m_nPatrolPt2Lz = nNewPatrolPtZ;
		m_nNextPatrolGx = m_nPatrolPt2Gx;
		m_nNextPatrolGy = m_nPatrolPt2Gy;
		m_nNextPatrolLz = m_nPatrolPt2Lz;
		m_nCurrentPatrolPt = 1;
		}
    else if (m_nPatrolPtCount == 3)
		{
		m_nPatrolPt3Gx = nNewPatrolPtX;
		m_nPatrolPt3Gy = nNewPatrolPtY;
		m_nPatrolPt3Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 4)
		{
		m_nPatrolPt4Gx = nNewPatrolPtX;
		m_nPatrolPt4Gy = nNewPatrolPtY;
		m_nPatrolPt4Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 5)
		{
		m_nPatrolPt5Gx = nNewPatrolPtX;
		m_nPatrolPt5Gy = nNewPatrolPtY;
		m_nPatrolPt5Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 6)
		{
		m_nPatrolPt6Gx = nNewPatrolPtX;
		m_nPatrolPt6Gy = nNewPatrolPtY;
		m_nPatrolPt6Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 7)
		{
		m_nPatrolPt7Gx = nNewPatrolPtX;
		m_nPatrolPt7Gy = nNewPatrolPtY;
		m_nPatrolPt7Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 8)
		{
		m_nPatrolPt8Gx = nNewPatrolPtX;
		m_nPatrolPt8Gy = nNewPatrolPtY;
		m_nPatrolPt8Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 9)
		{
		m_nPatrolPt9Gx = nNewPatrolPtX;
		m_nPatrolPt9Gy = nNewPatrolPtY;
		m_nPatrolPt9Lz = nNewPatrolPtZ;
		}
    else if (m_nPatrolPtCount == 10)
		{
		m_nPatrolPt10Gx = nNewPatrolPtX;
		m_nPatrolPt10Gy = nNewPatrolPtY;
		m_nPatrolPt10Lz = nNewPatrolPtZ;
		}
    return 1;
    }
    
    //********************************************************
    //************* S T A T E S ******************************
    //********************************************************
    
    
    //--------------------------------------------------------------------------
    state Idle
    {
	if(InPlatoon())
        {
    	m_nStayX = GetLocationX();
        m_nStayY = GetLocationY();
        m_nStayZ = GetLocationZ();
        }
    if (ForceRetreat ())
    	return Retreat;
    if ((GetHP() == GetMaxHP()) && (m_nReturnToGx >= 0) && (m_nReturnToGy >= 0))   // return after repair
       	return RestoreState,20;
	if(repairMode)
        {
    	if(FindTargetToRepair())
            {
			m_nCurrOperation = operationRepair;
             CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
			return MovingToTarget;
            }
        }
        
    if(captureMode)
        {
        if(FindTargetToCapture())
            {
            m_nCurrOperation = operationCapture;
            CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
            return MovingToTarget;
	        }
    	}
    	
	if(InPlatoon())
    	{
        return Idle;    
    	}
                
	if(m_nStayX && (GetLocationX()!=m_nStayX || GetLocationY()!=m_nStayY ||GetLocationZ()!=m_nStayZ))
		{
        SetCurrentTarget(null);
        m_nMoveToX = m_nStayX;
        m_nMoveToY = m_nStayY;
        m_nMoveToZ = m_nStayZ;
        CallMoveToPoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
        return StartMoving;
        }
     
     if (m_bEscorting)
     	return Escort;
     	
     if (m_bPatrolling)
     	return Patrol;
     	
//    if (!IsMoving() && GatherUnits ())
//    	return StartMoving;
     return Idle;
	 }
    
    //-------------------------------------------------------
    // new DM/231100
    state RestoreState
    {
        int nState;
        
    if ((m_nReturnToGx >= 0) && (m_nReturnToGy >= 0))
    	{
    	CallMoveToPoint (m_nReturnToGx, m_nReturnToGy, GetLocationZ ());
    	m_nReturnToGx = -1;
   	    return RestoreState,2;
    	}
  	if (IsMoving ())
   	    return RestoreState,2;
    if (m_nState != stIdle)
        {
        nState = m_nState;
        m_nState = stIdle;
        if (nState == stMove)
          	return Moving;
        if (nState == stPatrol)
        	return Patrol,20;
        if (nState == stEscort)
        	return Escort,20;
        }
    NextCommand (1);
    return Idle;
    }
    //--------------------------------------------------------------------------
	// new DM/231100
	state BeginPatrol
	{
    if (m_nPatrolPtCount < 2)
    	return Idle;
    m_bPatrolling = true;
    CallMoveToPoint(m_nNextPatrolGx, m_nNextPatrolGy, m_nNextPatrolLz);
    return Patrol;
	}
    //--------------------------------------------------------------------------
    state Patrol
    {
    ResetEscort ();
    if (!IsMoving())
    	{
    		{
    		NextCommand (1);
    		return Idle;
    		}
       	CallMoveToPoint(m_nNextPatrolGx, m_nNextPatrolGy, m_nNextPatrolLz);
    	}
    return Idle;
    }
    //--------------------------------------------------------------------------
    state StartMoving
    {
        return Moving, 20;
    }
    //--------------------------------------------------------------------------
    state Moving
    {
        if (IsMoving())
        {
            return Moving;
        }
        else
        {
            NextCommand(1);
            return Idle;
        }
    }
    
    state MovingToTarget
    {
        
        if (IsMoving())
        {
            //!!sprawdzanie czy cel jeszcze mozna naprawic/zdisablowac i czy sie ruszyl (wtedy trzeba zmienic kierunek jazdy)


            if (!m_uTarget.IsFroozen() && 
                                ((m_nCurrOperation == operationRepair) && CanBeRepaired(m_uTarget)) || 
                ((m_nCurrOperation == operationCapture) && CanBeConverted(m_uTarget)) ||
                ((m_nCurrOperation == operationRepaint) && CanBeRepainted(m_uTarget)) ||
                ((m_nCurrOperation == operationUpgrade) && CanBeUpgraded(m_uTarget)))
            {
                                if(!IsGoodPointForOperateOnTarget(m_uTarget,m_nMoveToX,m_nMoveToY,m_nMoveToZ))            
                                {//target has moved
                                        m_nMoveToX = GetOperateOnTargetLocationX(m_uTarget);
                                        m_nMoveToY = GetOperateOnTargetLocationY(m_uTarget);
                                        m_nMoveToZ = GetOperateOnTargetLocationZ(m_uTarget);
                                        if(IsGoodPointForOperateOnTarget(m_uTarget,m_nMoveToX,m_nMoveToY,m_nMoveToZ))            
                                        {
                                            CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                                            return MovingToTarget;
                                        }
                                        else
                                        {//unable to find operation point for target
                                            m_nCurrOperation = operationRepair;
                                            CallStopMoving();
                                            SetCurrentTarget(null);
                                            NextCommand(1);
                                            return Idle;
                                        }
                                }
            }
            else
            {
                m_nCurrOperation = operationRepair;
                CallStopMoving();
                SetCurrentTarget(null);
                                NextCommand(1);
                return Idle;
            }
            return MovingToTarget;
        }
        else
        {
            //sprawdzic czy w punkcie w ktorym jestesmy mozemy zaczac naprawe
            if (IsInGoodPointForOperateOnTarget(m_uTarget))
            {
                if (m_nCurrOperation == operationRepair)
                {
                    if (CanBeRepaired(m_uTarget))
                    {
                        CallRepair(m_uTarget);
                        return Repairing;
                    }
                    else
                    {
                        SetCurrentTarget(null);
                        NextCommand(1);
                        return Idle;
                    }
                }
                else if (m_nCurrOperation == operationCapture)
                {
                    if (CanBeConverted(m_uTarget))
                    {
                        CallConvert(m_uTarget);
                        return Converting;
                    }
                    else
                    {
                        SetCurrentTarget(null);
                        NextCommand(1);
                        return Idle;
                    }
                }
                else if (m_nCurrOperation == operationRepaint)
                {
                    if (CanBeRepainted(m_uTarget))
                    {
                        CallRepaint(m_uTarget, m_nRepaintSideColor);
                        return Repainting;
                    }
                    else
                    {
                        SetCurrentTarget(null);
                        NextCommand(1);
                        return Idle;
                    }
                }
                else
                {
                    assert m_nCurrOperation == operationUpgrade;
                    if (CanBeUpgraded(m_uTarget))
                    {
                        CallUpgrade(m_uTarget);
                        return Upgrading;
                    }
                    else
                    {
                        SetCurrentTarget(null);
                        NextCommand(1);
                        return Idle;
                    }
                }
            }
            else
            {
                m_nMoveToX = GetOperateOnTargetLocationX(m_uTarget);
                m_nMoveToY = GetOperateOnTargetLocationY(m_uTarget);
                m_nMoveToZ = GetOperateOnTargetLocationZ(m_uTarget);
                                if(IsGoodPointForOperateOnTarget(m_uTarget,m_nMoveToX,m_nMoveToY,m_nMoveToZ))            
                                {
                                            CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                                            return MovingToTarget;
                                }
                                else
                                {//unable to find operation point for target
                                    m_nCurrOperation = operationRepair;
                                    CallStopMoving();
                                    SetCurrentTarget(null);
                                    NextCommand(1);
                                    return Idle;
                                }
            }
            /*
            }
            else
            {
            SetCurrentTarget(null);
            NextCommand(1);
            return Idle;
            }
            */
        }
    }
    
    state Repairing
    {
        if (IsRepairing())
        {
            return Repairing,5;
        }
        else
        {
            if (CanBeRepaired(m_uTarget))
            {
                //z jakiegos powodu jeszcze go nie naprawilismy - odjechal ?
                m_nMoveToX = GetOperateOnTargetLocationX(m_uTarget);
                m_nMoveToY = GetOperateOnTargetLocationY(m_uTarget);
                m_nMoveToZ = GetOperateOnTargetLocationZ(m_uTarget);
                CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                return MovingToTarget;
            }
            else
            {
                SetCurrentTarget(null);
                NextCommand(1);
                return Idle;
            }
        }
    }
    
    state Converting
    {
        if (IsConverting())
        {
            return Converting,5;
        }
        else
        {
            if (CanBeConverted(m_uTarget))
            {
                //z jakiegos powodu jeszcze go nie skonvertowali�my - odjechal ?
                m_nMoveToX = GetOperateOnTargetLocationX(m_uTarget);
                m_nMoveToY = GetOperateOnTargetLocationY(m_uTarget);
                m_nMoveToZ = GetOperateOnTargetLocationZ(m_uTarget);
                CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                return MovingToTarget;
            }
            else
            {
                SetCurrentTarget(null);
                NextCommand(1);
                return Idle;
            }
        }
    }
    
    state Repainting
    {
        if (IsRepainting())
        {
            return Repainting,5;
        }
        else
        {
            if (m_uTarget.IsLive() && (m_uTarget.GetSideColor() != m_nRepaintSideColor))
            {
                //z jakiegos powodu jeszcze go nie pomalowalismy - odjechal ?
                m_nMoveToX = GetOperateOnTargetLocationX(m_uTarget);
                m_nMoveToY = GetOperateOnTargetLocationY(m_uTarget);
                m_nMoveToZ = GetOperateOnTargetLocationZ(m_uTarget);
                CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                return MovingToTarget;
            }
            else
            {
                SetCurrentTarget(null);
                NextCommand(1);
                return Idle;
            }
        }
    }
    
    state Upgrading
    {
        if (IsUpgrading())
        {
            return Upgrading,5;
        }
        else
        {
            if (m_uTarget.IsLive() && CanBeUpgraded(m_uTarget))
            {
                //z jakiegos powodu jeszcze go nie zubgradeowalismy - odjechal ?
                m_nMoveToX = GetOperateOnTargetLocationX(m_uTarget);
                m_nMoveToY = GetOperateOnTargetLocationY(m_uTarget);
                m_nMoveToZ = GetOperateOnTargetLocationZ(m_uTarget);
                CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
                return MovingToTarget;
            }
            else
            {
                SetCurrentTarget(null);
                NextCommand(1);
                return Idle;
            }
        }
    }
    
    //------------------------------------------------------- 
    state Frozen
    {
        if (IsFroozen())
        {
            return Frozen;
        }
        else
        {
            //!!wrocic do tego co robilismy
            return Idle;
        }
    }
    //--------------------------------------------------------------------------
    state Escort
    {
    	int	 nEscortGx;
    	int  nEscortGy;
    	int  nEscortLz;
    	int	 nDx;
    	int	 nDy;
    	
   	GetEscortedUnit();
    if (!m_uEscorted)
    if(!m_uEscorted)
        {
        if(IsMoving())
            {
            CallStopMoving();
            return Escort;
            }
        return Idle;
        }
        
	m_nEscortedGx = m_uEscorted.GetLocationX();    
	m_nEscortedGy = m_uEscorted.GetLocationY();    
	nEscortGx = GetLocationX();    
	nEscortGy = GetLocationY();    
	nEscortLz = GetLocationZ();    
    if (nEscortGx < m_nEscortedGx - 2)
    	nEscortGx = m_nEscortedGx - 2;
    else if (nEscortGx > m_nEscortedGx + 2)
    	nEscortGx = m_nEscortedGx + 2;
   	else
   		nDx = 0;
    if (nEscortGy < m_nEscortedGy - 2)
    	nEscortGy = m_nEscortedGy - 2;
    else if (nEscortGy > m_nEscortedGy + 2)
    	nEscortGy = m_nEscortedGy + 2;
   	else
   		nDy = 0;
   	if ((nEscortGx != m_nEscortedGx) || (nEscortGy != m_nEscortedGy))
        CallMoveToPoint(nEscortGx, nEscortGy, m_uEscorted.GetLocationZ());
    else if(IsMoving())
        CallStopMoving ();
    return Escort;
    }
    
    //------------------------------------------------------- 
    state Retreat
    {
    	unit	uAttacker;
    	int		nAttackerGx;
    	int		nAttackerGy;
    	
    if(IsAllowingWithdraw())
    	AllowScriptWithdraw(true);
    if(!m_uTarget)
        SetTargetObject(null);
    if (GatherUnits())
    	if (IsMoving ())
    		return Moving;
    	else
	    	return StartMoving;
    if (!m_nDamper)
    	{
		uAttacker = FindClosestEnemy();
		m_nDamper = 1;
		}
	else
		{
		if (IsMoving ())
			m_nDamper = (m_nDamper + 1) % 16;
		else
			m_nDamper = 0;
		}
	if (!uAttacker)
		{
		if (IsMoving())
			CallStopMoving();
		return Idle;
		}
	m_nRetreatGx = GetLocationX();
	m_nRetreatGy = GetLocationY();
	nAttackerGx = uAttacker.GetLocationX();
	nAttackerGy = uAttacker.GetLocationY();
	if (m_nRetreatGx <= nAttackerGx)
		m_nRetreatGx = nAttackerGx - (cAttackerMaxDist + 1);
	else
		m_nRetreatGy = nAttackerGy + (cAttackerMaxDist + 1);
	if (m_nRetreatGy <= nAttackerGy)
		m_nRetreatGy = nAttackerGy - (cAttackerMaxDist + 1);
	else
		m_nRetreatGy = nAttackerGy + (cAttackerMaxDist + 1);
	if ((GetLocationX() != m_nRetreatGx) || (GetLocationY() != m_nRetreatGy))
		{
    	CallMoveToPoint(m_nRetreatGx, m_nRetreatGy, GetLocationZ());
    	return Retreat;
    	}
    m_nRetreatGx = -1;	// done retreating
    return Idle;
    }
    
    //=================================================================================
    
    event OnFreezeForSupplyOrRepair(int nFreezeTicks)
    {
        CallFreeze(nFreezeTicks);
        state Frozen;
        true;
    }
    //------------------------------------------------------- 
    
    command Initialize()
    {
        int nColor;
        int nMaxColor;
        nMaxColor = GetMaxSideColor();
        m_nRepaintSideColor = GetSideColor();
        for (nColor = m_nRepaintSideColor + 1; nColor <= nMaxColor; nColor = nColor + 1)
        {
            if (IsPlayer(nColor))
            {
                m_nRepaintSideColor = nColor;
                break;
            }
        }
        if (nColor > nMaxColor)
        {
            for (nColor = 0; nColor < m_nRepaintSideColor; nColor = nColor + 1)
            {
                if (IsPlayer(nColor))
                {
                    m_nRepaintSideColor = nColor;
                    break;
                }
            }
        }
        SetRepaintSideColor(m_nRepaintSideColor);
        repairMode = 1;
        captureMode = 1;
        false;
    }
    
    command Uninitialize()
    {
        //wykasowac referencje
        SetCurrentTarget(null);
        false;
    }
    
    /*bez nazwy - wywolywany przez kursor*/
    command Repair(unit uTarget) hidden button "translateCommandRepair"
    {
        if (CanBeRepaired(uTarget))
        {
            m_nCurrOperation = operationRepair;
            SetCurrentTarget(uTarget);
            m_nMoveToX = GetOperateOnTargetLocationX(m_uTarget);
            m_nMoveToY = GetOperateOnTargetLocationY(m_uTarget);
            m_nMoveToZ = GetOperateOnTargetLocationZ(m_uTarget);
            CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
            state MovingToTarget;
        }
        else
        {
            NextCommand(0);
        }
        true;
    }
    //-------------------------------------------------------    
    /*bez nazwy - wywolywany przez kursor*/
    command Convert(unit uTarget) hidden button "translateCommandCapture"
    {
        if (CanBeConverted(uTarget))
        {
            m_nCurrOperation = operationCapture;
            SetCurrentTarget(uTarget);
            m_nMoveToX = GetOperateOnTargetLocationX(m_uTarget);
            m_nMoveToY = GetOperateOnTargetLocationY(m_uTarget);
            m_nMoveToZ = GetOperateOnTargetLocationZ(m_uTarget);
            CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
            state MovingToTarget;
        }
        else
        {
            NextCommand(0);
        }
        true;
    }
    //-------------------------------------------------------
    command Repaint(unit uTarget) button "translateCommandRepaint" description "translateCommandRepaintDescription" hotkey priority 100
    {
        if (CanBeRepainted(uTarget))
        {
            m_nCurrOperation = operationRepaint;
            SetCurrentTarget(uTarget);
            m_nMoveToX = GetOperateOnTargetLocationX(m_uTarget);
            m_nMoveToY = GetOperateOnTargetLocationY(m_uTarget);
            m_nMoveToZ = GetOperateOnTargetLocationZ(m_uTarget);
            CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
            state MovingToTarget;
        }
        else
        {
            NextCommand(0);
        }
        true;
    }
    //-------------------------------------------------------
    command Upgrade(unit uTarget) button "translateCommandUpgrade" description "translateCommandUpgradeDescription" hotkey priority 99
    {
        if (CanBeUpgraded(uTarget))
        {
            m_nCurrOperation = operationUpgrade;
            SetCurrentTarget(uTarget);
            m_nMoveToX = GetOperateOnTargetLocationX(m_uTarget);
            m_nMoveToY = GetOperateOnTargetLocationY(m_uTarget);
            m_nMoveToZ = GetOperateOnTargetLocationZ(m_uTarget);
            CallMoveToPointForce(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
            state MovingToTarget;
        }
        else
        {
            NextCommand(0);
        }
        true;
    }
    //-------------------------------------------------------
    command SetUpgradeWeapons(int nMode) hidden button upgradeWeaponsMode priority 98
    {
        if (nMode == -1)
        {
            upgradeWeaponsMode = (upgradeWeaponsMode + 1) % 2;
        }
        else
        {
            assert(nMode == 0);
            upgradeWeaponsMode = nMode;
        }
        SetUpgradeWeapons(upgradeWeaponsMode);
        NextCommand(0);
        true;
    }
    //-------------------------------------------------------
    command SetUpgradeChasis(int nMode) hidden button upgradeChasisMode priority 97
    {
        if (nMode == -1)
        {
            upgradeChasisMode = (upgradeChasisMode + 1) % 2;
        }
        else
        {
            assert(nMode == 0);
            upgradeChasisMode = nMode;
        }
        SetUpgradeChasis(upgradeChasisMode);
        NextCommand(0);
        true;
    }
    //-------------------------------------------------------
    command SetUpgradeShield(int nMode) hidden button upgradeShieldMode priority 96
    {
        if (nMode == -1)
        {
            upgradeShieldMode = (upgradeShieldMode + 1) % 2;
        }
        else
        {
            assert(nMode == 0);
            upgradeShieldMode = nMode;
        }
        SetUpgradeShield(upgradeShieldMode);
        NextCommand(0);
        true;
    }
    //-------------------------------------------------------
    command SetRepaintSideColor(int nNewSideColor) hidden button "translateCommandSetColor" 
    {
        m_nRepaintSideColor = nNewSideColor;
        SetRepaintSideColor(m_nRepaintSideColor);
        NextCommand(1);
        true;
    }
    //-------------------------------------------------------
    command SpecialSetRepaintSideColorDialog() button "translateCommandSetColor" description "translateCommandSetColorDescription" hotkey priority 101
    {
        //specjalna komenda obslugiwana przez dialog
    }
    //-------------------------------------------------------
    command Move(int nGx, int nGy, int nLz) button "translateCommandMove" description "translateCommandMoveDescription" hotkey priority 21
    {
    SetCurrentTarget(null);
    m_nMoveToX = nGx;
    m_nMoveToY = nGy;
    m_nMoveToZ = nLz;
    m_nStayX = nGx;
    m_nStayY = nGy;
    m_nStayZ = nLz;
    if (m_nGatherGx < 0)
    	{
	    m_nGatherGx = nGx;
	    m_nGatherGy = nGy;
	    m_nGatherLz = nLz;
	    }
    CallMoveToPoint(m_nMoveToX, m_nMoveToY, m_nMoveToZ);
    state StartMoving;
    true;
    }
    //-------------------------------------------------------
    command Enter(unit uEntrance) hidden button "translateCommandEnter"
    {
        SetCurrentTarget(null);
        m_nMoveToX = GetEntranceX(uEntrance);
        m_nMoveToY = GetEntranceY(uEntrance);
        m_nMoveToZ = GetEntranceZ(uEntrance);
        CallMoveInsideObject(uEntrance);
        state StartMoving;
        true;
    }
    //-------------------------------------------------------
    command Stop() button "translateCommandStop" description "translateCommandStopDescription" hotkey priority 20
    {
    SetCurrentTarget(null);
    m_bPatrolling = false;
    CallStopMoving();
    state Idle;
    true;
    }
    
    //-------------------------------------------------------
    command SetRepairMode(int nMode) button repairMode description "translateCommandStateRepairModeDescription"priority 190
    {
        if (nMode == -1)
        {
            repairMode = (repairMode + 1) % 2;
        }
        else
        {
            assert(nMode == 0);
            repairMode = nMode;
        }
    }
    //-------------------------------------------------------
    command SetConvertMode(int nMode) button captureMode description "translateCommandStateCaptureModeDescription" priority 190
    {
        if (nMode == -1)
        {
            captureMode = (captureMode + 1) % 2;
        }
        else
        {
            assert(nMode == 0);
            captureMode = nMode;
        }
    }
    
    //-------------------------------------------------------
    command SetLights(int nMode) button lights description "translateCommandStateLightsModeDescription" hotkey priority 204
    {
        if (nMode == -1)
        {
            lights = (lights + 1) % 3;
        }
        else
        {
            assert(nMode == 0);
            lights = nMode;
        }
        SetLightsMode(lights);
    }
    //--------------------------------------------------------------------------
    command UserPoint0(int nGx, int nGy, int nLz) button "translateCommandPatrol" description "translateCommandPatrolDescription" hotkey priority 27
    {
	AddPatrolPt (nGx, nGy, nLz);
    state BeginPatrol;
    }
    
    //--------------------------------------------------------------------------
    command UserNoParam0() button "translateCommandResetPatrol" description "translateCommandResetPatrolDescription" hotkey priority 28
    {
    ResetPatrol ();
    NextCommand (0);
    }
    
    //--------------------------------------------------------------------------
    command UserNoParam1() button "translateCommandRestartPatrol" description "translateCommandRestartPatrolDescription" hotkey priority 29
    {
    state BeginPatrol;
    }
    
    //--------------------------------------------------------------------------
    command UserOneParam2(int nMode) button retreatMode description "translateCommandStateRetreatModeDescription" priority 51
    {
    if (nMode == -1)
        retreatMode = (retreatMode + 1) % rmNum;
    else
        {
        assert(nMode == 0);
        retreatMode = nMode;
        }
    }
    
     //--------------------------------------------------------------------------
    command UserPoint1(int nGx, int nGy, int nLz) button "translateCommandSetGatherPoint" description "translateCommandSetGatherPointDescription" hotkey priority 52
    {
    m_nGatherGx = nGx;
    m_nGatherGy = nGy;
    m_nGatherLz = nLz;
    NextCommand (0);
    }
    
    //--------------------------------------------------------------------------
    command UserNoParam2() button "translateCommandRetreat" description "translateCommandRetreatDescription" hotkey priority 53
    {
    m_nDamper = 0;
   	state Retreat;
    }
    
	//--------------------------------------------------------------------------
    command UserObject0(unit uUnit) button "translateCommandEscort" description "translateCommandEscortDescription" hotkey priority 31 
    {
    AddEscortedUnit (uUnit);
    state Escort;
    }
    
    //-------------------------------------------------------
    command SpecialChangeUnitsScript() button "translateCommandChangeScript" description "translateCommandChangeScriptDescription" hotkey priority 254 
    {
        //special command - no implementation
    }
    //--------------------------------------------------------------------------
/*
    command UserOneParam9(int nMode) button traceMode priority 255
    {
    if (nMode == -1)
    	{
        traceMode = (traceMode + 1) % 2;
        }
    else
    	{
        assert(nMode == 0);
        traceMode = nMode;
        }
    }
*/    
}
    

                    
                             
                                  Earth 2150 : Operation X 

                                       Public Beta II


                           Copyright (c) 2003 Operation X Team, Inc.

            
                
                  _______________________________________________________________ 
                  | Aktuelle Hinweise zum Entwicklungsstand, zu Probleml�sungen |
                  | und Links zu Updates sind zu finden auf www.insideearth.de. |
                  _______________________________________________________________  



Inhalt
=========

1. Changelog
2. Allgemeine Hinweise
3. Inhalt der Beta
4. Installation
5. Deinstallation
6. Bekannte Probleme
7. Bugreports
 



1. Changelog
==============


�nderungen von Public Beta I zu Public Beta II:

- spielbar auf dem offiziellen EarthNet server (netserver.earth2150.com)
- station�re Artillerie hat 3 Sch�sse, bevor sie nachgeladen werden muss
- station�re Artillerie ist resistenter gegen Hitzeschaden (Laser)
- neue Waffeneffekte f�r Artillerie
- SDI l�dt geringf�gig schneller
- ED station�re Artillerie Parameter�nderungen und Angleichung an UCS, um den angezeigten Schaden zu korrigieren
- ED Zytomir (Jagdpanzer) hat weniger HP
- ED Pamir-Kanone + 100 Credits
- ED/UCS mobile Artillerien schie�en schneller und haben mehr Munition
- LC Sunlight erzeugt Staub beim Aufsetzen auf dem Boden
- LC Sunlight regeneriert nun auch
- LC Xylit-Kraftwerk hat keine Stromreichweitenbegrenzung mehr
- LC leichtes Elektro macht geringf�gig weniger Schaden
- UCS mobile Plasma-Artillerie hat nun Movements Sounds des Mammoth
- UCS Salamander hat nun Movement Sounds des Mammoth
- UCS neue Parameterwerte f�r Gatling-Munition
- UCS Tarantel hat weniger HP
- UCS neue Tarantel-Animationen



2. Allgemeine Hinweise
=========================


Betreffend Public Beta II:

Die Resonanz gegen�ber unserer ersten Beta ist insgesamt eher m��ig ausgefallen. Abgesehen von der Zeit direkt nach Release war der ETWAS Server g�hnend leer, weil die Leute zum Standard-TMP zur�ckgekehrt sind. Nur wenige Leute haben uns geholfen, bestehende Bugs und Balancing-Probleme ausfindig zu machen. Wenn die Community lieber das originale TMP/LS spielen m�chte, ist das ok f�r uns, wir wollen niemanden zwingen, OpX zu spielen. Dann allerdings werden wir das Projekt auch einstellen.
Falls doch Interesse besteht, dann bitten wir darum, dass der Mod auch weiter gespielt wird und das Interesse �ber hilfreiche Eintr�ge in unsere Bugdatenbank kundgetan wird (s. weiter unten in dieser Readme). 
Mit diesem Release wird die OpX Public Beta auf dem normalen Earthnet Server spielbar, der E.T.W.A.S. Server wird derweil vom Netz genommen.


Generell:

Das OperationX Team ver�ffentlicht diese Betaversion in der Hoffnung, dass sie allen am Betatest teilnehmenden Personen Spa�, Freude und neue Herausforderungen bringen m�ge. Durch die Klassifizierung als Beta-Version sei darauf hingewiesen, dass die OperationX-Modifikation weder komplett noch garantiert frei von Fehlern oder Unstimmigkeiten in der Spielbalance ist. Es ist das erkl�rte Ziel des OperationX Teams, diese Fehler und Unstimmigkeiten mithilfe der teilnehmenden Tester zu finden und zu beseitigen.
Die OperationX-Mitarbeiter k�nnen f�r durch die Installation und Nutzung dieser Beta-Version entstande Fehler und Sch�den nicht verantwortlich gemacht werden, die Benutzung geschieht auf eigene Gefahr.



3. Inhalt der Beta
=====================


Zum aktuellen Stand der Beta sind folgende �nderungen/Hinzuf�gungen gegen�ber dem Originalspiel integriert:

- neue Chassis- und Waffentypen f�r alle drei Rassen
- neu gestaltetes Balancing
- neue neutrale Mapobjekte f�r atmosph�rischere Gestaltungsm�glichkeiten neuer Maps
- zwei neue Gametypes: "{OpX} Destroy Structures" (Beta) und "{OpX} TechWar"


Bislang nicht implementiert, aber f�r die finale Version geplant:

- Implementierung von ausbalancierten, nutzbaren Schiffen
- Erweiterung der neutralen Mapobjekte
- eigene Singleplayer-Kampagne mit einer Prequel-Story zu Lost Souls
- Ersetzung s�mtlicher Einheitenskripte durch OpX-eigene Versionen
- Ersetzung s�mtlicher Gametype-Skripte durch OpX-eigene Versionen
- Ersetzung s�mtlicher KI-Skripte durch OpX-eigene, forderndere Versionen
- Modkontrollsystem f�r das einfache Ab- und Anschalten von Mods wie etwa OpX
- M.O.O.S. (Moon Omnipresent Observation System) Software, ein Standalone Chatclient f�r EarthNet Server
- OperationX Map Index System, f�r mehr �bersicht bei den Custom-Made Maps und das Aussortieren von Cheat- und Fake-Maps



4. Installation
==================


HINWEIS: Wir empfehlen dringend, die Public Beta I zu deinstallieren, bevor die Beta II installiert wird!

Earth 2150 : Operation X ist eine Spielmodifikation f�r Earth 2150: The Moon Project oder Earth 2150: Lost Souls. Der Besitz eines der beiden Spiele ist Voraussetzung f�r die Installation der Public Beta. Ebenfalls m�ssen die minimalen Systemanforderungen des jeweiligen Spieles erf�llt werden. 
Wir empfehlen allerdings eine folgende Systemkonfiguration f�r optimales Spielen:

- Pentium III oder Athlon mit 1000MHZ, Celeron oder Duron mit 1300MHZ
- 256(+) MB Arbeitsspeicher
- Grafikkarte Geforce 3, Radeon 8500, Parhelia oder besser
- ISDN oder ADSL Internetverbindung (f�r Multiplayer)


Der Installer f�r die OpX Public Beta II kann auf www.insideearth.de heruntergeladen werden. Ausf�hren und den Anweisungen am Bildschirm folgen. Es muss die richtige Sprachversion und der richtige Spieltyp (Moon Project oder Lost Souls) gew�hlt werden. Beide Sprachversionen funktionieren auch mit nichtenglischen und nichtdeutschen Versionen von Moon Project und Lost Souls. 

Hinweis: F�r die Nutzung der Beta ist es irrelevant, ob Moon Project oder Lost Souls verwendet wird. Beide Spiele k�nnen mit installierter OpX Beta miteinander ohne Einschr�nkungen im Multiplayer spielen.



5. Deinstallation
====================


Die Deinstallation ist denkbar einfach: Einfach den mitgelieferten Uninstaller verwenden.




6. Bekannte Probleme
=====================


- Das Laden von Savegames anderer Spielversionen f�hrt zu unvorhersehbaren Ereignissen oder zum Absturz des Spiels
- Das Laden von mit Operation X Objekten ausgestatteten Maps unter �lteren Versionen kann zu Abst�rzen f�hren
- Nach einem Multiplayerspiel und anschlie�endem Beenden des Spiels tritt gelegentlich eine in ihrer Ursache bislang ungekl�rte Fehlermeldung auf, die aber ignoriert werden kann
- die Original-Kampagnen von TMP/LS werden aufgrund des ge�nderten Balancings quasi unspielbar
- Der UCS Flammenwerferturm kann eigene Einheiten "verschlingen", wenn er gebaut wird
- Das ED Silo �ffnet sich nicht, wenn eine Rakete abgefeuert wird
- Die Animationen f�r UCS Flammenwerfer und ED Shockwave sind derzeit nur Behelfsl�sungen und werden ersetzt werden
- UCS Sammler II sieht aus wie der originale UCS Sammler (ohne Upgrade)
- Einheitenkonstruktionen, die ohne OpX gespeichert wurden, k�nnen in OpX immer noch gebaut werden, obwohl sie nicht gebaut werden d�rften (Taiga + Waffe z. B.).




7. Bugreports
================


Das erkl�rte Ziel dieser Public Beta ist, wie bereits erw�hnt, das Finden und Ausmerzen jedweder Form von Bugs sowie Unstimmigkeiten im Balancing. Daher bitten wir alle Spieler dieser Beta, uns bei diesem Ziel dadurch zu helfen, dass sie gefundene Bugs und Probleme in Balancing oder anderen Teilen der OpX Beta an weiter unten genannter Stelle mit m�glichst detaillierter Beschreibung melden oder bereits eingetragene Bugs best�tigen (falls zutreffend).
Zu diesem Zweck hat das OperationX Team auf http://www.insideearth.de zwei Listen angelegt, eine f�r Bugs/Probleme/Unstimmigkeiten und eine f�r sonstige W�nsche oder Verbesserungsvorschl�ge. Wir appellieren dabei an den gesunden Menschenverstand aller teilnehmenden Tester, zwischen tats�chlichen Bugs und Unstimmigkeiten im Balancing (die durch mehrere Testspiele mit verschiedenen Spielern und Bedingungen belegt sein sollten) und eigenen Wunschvorstellungen unterscheiden zu k�nnen.
Wir bitten darum, nur diese daf�r vorgesehenen Listen zu benutzen und sich zu vergewissern, dass eine Eintragung nicht bereits existiert, so dass wir nicht die �bersicht verlieren. Nach M�glichkeit sollten Reports in Englisch verfasst sein, um es allen Teilnehmern zu erm�glichen, die Reports zu lesen und zu kommentieren. Deutsch ist noch akzeptabel, von anderen Sprachen bitten wir aber abzusehen, da sie nicht von allen OpX-Teammitgliedern verstanden werden k�nnen.

Direktlinks zu den Eintragungslisten:

- Bugs/Probleme/Unstimmigkeiten: => http://www.insideearth.de/ins/wishlist/default.asp?entry=8
- Vorschl�ge/W�nsche/Verbesserungen: => http://www.insideearth.de/ins/wishlist/default.asp?entry=9






                      ----------------------------------------------------------
                      |  DAS OPERATIONX-TEAM W�NSCHT VIEL SPASS BEIM SPIELEN!  |
                      ----------------------------------------------------------

P.S.: Und bitte nicht vergessen, dass Fehler und frustrierende �berm�chtige Einheiten durch Balancing-Unstimmigkeiten Teil dieser Beta-Phase sein k�nnen und mit entsprechender Gelassenheit getragen werden sollten. Je mehr konstruktives Feedback wir erhalten, desto eher k�nnen diese Dinge eliminiert werden und die OperationX-Modifikation sich einer finalen Version n�hern.